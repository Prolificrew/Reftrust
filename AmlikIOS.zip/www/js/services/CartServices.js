﻿angular.module('myApp').factory('CartService', function ($http, $q, AuthService, baseUrl) {
    var token = AuthService.GetAccessToken();
    return {
        getCartList: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/GetCartItems',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        deleteCart: function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/RemoveFromCart/' + id,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        addCart: function (id) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/Buyout/' + id,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        updateCart: function (data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'Postadd/UpdateCartItem',
                data:data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        SaveAddress: function (data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'Postadd/SaveAddress',
                data: data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getAddress: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/GetAddress',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getConfirmList: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/ConfirmationList',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getCityList: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/PostaddLocationsList',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getCartCount: function () {
            var deferred = $q.defer();
            token = AuthService.GetAccessToken();
            $http({
                method: 'GET',
                url: baseUrl + 'Postadd/GetCartItemsCount',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        }

    }
})