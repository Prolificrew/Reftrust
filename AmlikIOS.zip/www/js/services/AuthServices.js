﻿angular.module('myApp').factory('AuthService', function ($http, $translate, $q, baseUrlforToken, ngAuthSetting) {
    var returnObject = {};
    var _login = function (data) {
        //var _data = "grant_type=password&username=egemen.ulucay@windowslive.com&password=123456";
        //var _data = "grant_type=password&username=" + data.username + "&password=" + data.password;
        var _data = $.param({ grant_type: 'password', username: data.username, password: data.password })
        var deferred = $q.defer();
        
        $http({
            method: 'POST',
            url: baseUrlforToken + '/token',
            data: _data,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }
        }).success(function (response) {
            localStorage.setItem("AuthData", JSON.stringify(response));
            deferred.resolve(response);
        }).error(function (response) {
            deferred.reject(response);
        })
        return deferred.promise;
    }

    var _loginWithFaceBook = function (data)
    {
        var deferred = $q.defer();
        $http({
            method: 'POST',
            url: baseUrlforToken + '/api/Account/ExternalLogin',
            data:data
        }).success(function (response) {
            localStorage.setItem("AuthData", JSON.stringify(response));
            deferred.resolve(response);
        }).error(function (response) {
            deferred.reject(response);
        })
        return deferred.promise;
    }

    
    var _getAuthToken = function () {

        var token = JSON.parse(localStorage.getItem("AuthData"));
        if (token) {
            if (new Date() <= new Date(token[".expires"])) {
                return token
            } else {
                _logout();
                return null;
            }
        }
        
        //debugger;
        return token;
    }
    var _register = function (data) {
        var deferred = $q.defer();

        $http({
            method: 'POST',
            url: baseUrlforToken + '/api/Account/Register',
            data: data,
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        }).success(function (response) {
            deferred.resolve(response);
        }).error(function (response) {
            deferred.reject(response);
        })
        return deferred.promise;
    }
    var _logout=function(){
        localStorage.removeItem("AuthData")
    }
    returnObject.Login = _login;
    returnObject.LoginWithFacebook = _loginWithFaceBook;
    returnObject.GetAccessToken = _getAuthToken;
    returnObject.Register = _register;
    returnObject.logout = _logout;
    return returnObject
}).service('UserService', function () {
    // For the purpose of this example I will store user data on ionic local storage but you should save it on a database
    var setUser = function (user_data) {
        window.localStorage.starter_facebook_user = JSON.stringify(user_data);
    };

    var getUser = function () {
        return JSON.parse(window.localStorage.starter_facebook_user || '{}');
    };

    return {
        getUser: getUser,
        setUser: setUser
    };
});