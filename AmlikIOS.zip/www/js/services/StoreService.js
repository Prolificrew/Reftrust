﻿angular.module('myApp').factory('StoreService', function ($http, $translate, baseUrl) {
    var storeData = [];
    //var baseURL = "https://www.amlik.com/api/api/homepages/HomeAllAdvs/";
    //var baseURL = "https://www.amlik.com/api/api/";
    //var baseURL = "http://131.72.139.186:10143/api/";

    return {
        getStore: function (pageNo) {

            return $http.get(baseUrl + "homepages/HomeAllAdvs/" + pageNo).then(function (response) {
                storeData = response;
                return storeData;
            });
        },
        getSearched: function (obj) {
            return $http.post(baseUrl + "Search/SearchPageDataList", obj).then(function (response) {
                storeData = response;
                return storeData;
            });
        },

        getURLbasedData: function (url, pageno) {
            return $http.get(baseUrl + "Search/GetkategoriUrlData/" + url + "/" + pageno).then(function (response) {
                storeData = response;
                return storeData;
            });
        },

        productDetail: function (id) {
            return $http.get(baseUrl + "AdvDetail/DetailPageDataByid/" + id).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        storeDetail: function (url) {
            return $http.get(baseUrl + "Store/StoreDetail/" + url).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getStoreList: function (url, pageno) {
            return $http.get(baseUrl + "Store/StorePageData/" + url + "/" + pageno).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getStoreDetail: function (storeId, userId, pageno) {
            return $http.get(baseUrl + "AdvDetail/DetailPageDataBYID/" + storeId + "/" + userId + "/" + pageno).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getFilterDetail: function (filterObj) {
            return $http.post(baseUrl + "Search/SearchPageAlltagsdata", filterObj).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getAllLocations: function (locationObj) {
            return $http.post(baseUrl + "Search/SearchPageDataListMap", locationObj).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getFilteredData: function (filterObjData) {
            return $http.post(baseUrl + "Search/SearchFilterData", filterObjData).then(function (response) {
                storeData = response;
                return storeData;
            });

        }
    };
});