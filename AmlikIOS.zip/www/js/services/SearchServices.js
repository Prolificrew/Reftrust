﻿
angular.module('myApp').factory('Search', function ($http, $translate, baseUrl) {
    var data = [];
    //var baseURL = "http://131.72.139.186:10143/api/";
    //var baseURL = "https://www.amlik.com/api/api/";
   

    return {
        realStateSubMenus: function () {

            return $http.get(baseUrl + "Navigations/menu/" + "5").then(function (response) {
                data = response;
                return data;
            });
        },
        vehicleMenus: function () {

            return $http.get(baseUrl + "Navigations/menu/" + "1").then(function (response) {
                data = response;
                return data;
            });
        },
        commonMenu: function (id) {

            return $http.get(baseUrl + "Navigations/menu/" + id).then(function (response) {
                data = response;
                return data;
            });
        },
        resSubMenus: function (id) {

            return $http.get(baseUrl + "Navigations/menu/" + id).then(function (response) {
                data = response;
                return data;
            });
        },
        estateOtherSubMenus: function (id) {
            return $http.get(baseUrl + "Navigations/menu/" + id).then(function (response) {
                data = response;
                return data;
            });
        },
        getAllMenu: function () {
            return $http.get(baseUrl + "Navigations/menu/0").then(function (response) {
                data = response;
                return data;
            });
        },
        getChildMenuCount: function () {
            //return $http.get(menuURL).then(function (response) {
            //    data = response;
            //    return data;
            //});
        },
        getSearch: function (searchtext, Culture) {
            return $http.get(baseUrl + "Search/GetSearchPopupData" + "/" + searchtext + "/" + Culture).then(function (response) {
                data = response;
                return data;
            });
        },
        searchByText: function (searchtext, Culture) {
            return $http.get(baseUrl + "Search/PostAddSearchCategory/" + searchtext + "/" + Culture).then(function (response) {
                data = response;
                return data;
            });
        }
    };
})