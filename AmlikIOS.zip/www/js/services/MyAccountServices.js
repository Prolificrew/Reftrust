﻿angular.module('myApp').factory('MyAccountServices', function ($http, $q, AuthService, baseUrl) {
    var token = AuthService.GetAccessToken();
    return {
        getNonPublishedAds: function (nonPubAdsPageNo, orderType) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/NonPublishedAdds/' + nonPubAdsPageNo+"/"+orderType,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getNonPublishedAdsByText: function (nonPubAdsPageNo, stringText) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/NonPublishedAddsByText/' + nonPubAdsPageNo + "/" + stringText,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getPublishedAds: function (pubAdsPageNo) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/PublishedAdds/' + pubAdsPageNo,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getFavoriteAds: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetFavoriteAds',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getInboxMessages: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetInboxMessages',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getMessagesDetail: function (SenderId, RecipientUserId, Adid) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetMessageDetails/' + SenderId + "/" + RecipientUserId + "/" + Adid,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getSentMessages: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetOutboxMessages',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        SendMessage: function (_data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'UserAccount/SendMessage',
                data: _data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetAccountPurchaseTransactions: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetAccountTransactions',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetAccountSoldTransactions: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetEcommerceTransactions',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        ChangePassword: function (_data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'UserAccount/ChangePassword',
                data: _data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetPaytabInfo: function (addressId, ipAddress) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'UserAccount/GetPayTabInfo',
                data: { userIpAddress: ipAddress, addressId: addressId },
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        UpdatePayTabStatus: function (paytabId, orderId) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/UpdatePayTabStatus/' + paytabId + '/' + orderId,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
    }
})