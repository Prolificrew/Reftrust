﻿angular.module('myApp', [])

        /**
         * A simple example service that returns some data.
         */
        .factory('Friends', function ($http, $translate) {
            //            // Might use a resource here that returns a JSON array
            //
            //            // Some fake testing data
            var friends = [];
            return {
                all: function () {
                    var lists = [];
                    $http.get('assets/friendlist.json').success(
                            function (data) {
                                friends = data;
                                for (var i = 0; i < friends.length; i++) {
                                    if (friends[i].lang === $translate.use()) {
                                        lists.push(friends[i]);
                                    }
                                }
                            }
                    );
                    return lists;
                },
                get: function (friendId) {
                    // Simple index lookup
                    return friends[friendId - 1];
                }
            };

        })
        .factory('Search', function ($http, $translate) {
            var searchedData = [];
            return {
                //Searching data
                all: function (query, curlang) {
                    var lists = [];
                    //$http.get('assets/friendlist.json').success(
                    //        function(data) {
                    //            searchedData = data;
                    //            for (var i = 0; i < searchedData.length; i++) {
                    //                if (searchedData[i].lang === $translate.use()) {
                    //                    lists.push(searchedData[i]);
                    //                }
                    //            }
                    //        }
                    //);
                    return lists;
                }
            };
        })
        .factory('Search', function ($http, $translate) {
            var realStateMenu = [];
            var baseURL = "http://131.72.139.186:10143/api/Navigations/menu/";
            var menuURL = "http://131.72.139.186:10143/api/Navigations/menu/0";
            //var baseURL = "http://192.168.1.114:10142/api/Navigations/menu/";
            return {
                realStateSubMenus: function () {

                    return $http.get(baseURL + "5").then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                vehicleMenus: function () {

                    return $http.get(baseURL + "1").then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                commonMenu: function (id) {

                    return $http.get(baseURL + id).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                resSubMenus: function (id) {

                    return $http.get(baseURL + id).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                estateOtherSubMenus: function (id) {
                    return $http.get(baseURL + id).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                getAllMenu: function () {
                    return $http.get(menuURL).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                }
            };
        });
