﻿//For Testing
var baseUrlforToken = 'https://www.amlik.com/apitest';
var baseUrl = 'https://www.amlik.com/apitest/api/';

//Live
//var baseUrlforToken = 'https://www.amlik.com/api';
//var baseUrl = 'https://www.amlik.com/api/api/';

//Local
//var baseUrl = "http://131.72.139.186:10143/api/";
//var baseUrlforToken = 'http://131.72.139.186:10143';
angular.module('myApp', ['ionic', 'pascalprecht.translate', 'ngCordova', 'ionic.contrib.drawer', 'ngCordovaOauth', 'ngAnimate', 'toaster', 'ngSanitize'])
    .config(function ($translateProvider) {
        $translateProvider.translations('en', translations_en);
        $translateProvider.translations('ar', translations_ar);
        $translateProvider.preferredLanguage('en');
        if (localStorage.getItem('UserLanguage')) {
            $translateProvider.preferredLanguage(localStorage.getItem('UserLanguage'));
        }

        // console.log("$translateProvider initialized");
    })
    .config(function ($httpProvider) {
        //$httpProvider.interceptors.push('authInterceptorService');
        $httpProvider.interceptors.push(function ($rootScope, $injector, $q, toaster, $translate) {
            return {
                request: function (config) {
                    if ($rootScope.online) {
                        $rootScope.$broadcast('loading:show');
                        return config
                    } else {
                        config.timeout = 1;
                        $("#toast-container").removeClass('toast-top-right');
                        toaster.clear();
                        toaster.wait({ title: "", body: $translate.instant('NoInternetConnection'),timeout: 5000 });
                        return config;
                    }
                },
                response: function (response) {
                    var $http = $http || $injector.get('$http');
                    if ($http.pendingRequests.length < 1) {

                    }
                    return response;
                },
                requestError: function (rejectReason) {

                    return $q.reject(rejectReason);
                },
                responseError: function (rejectReason) {

                    return $q.reject(rejectReason);
                }
            }
        });
    })
    .config(function ($ionicConfigProvider) {
        $ionicConfigProvider.views.maxCache(1);
        $ionicConfigProvider.views.swipeBackEnabled(false);
    }).constant('paytab', {
        merchant_email: 'i.alsanousi@amlik.com',
        secret_key: 'd0IVxPhyeZzE8S3pv3S0aqxBhn26cywpzek64CFiCeXL60bC43Cfu9RMxUTJsp92Eu8I7O1K2Yv9ZGL4Kojeyb155UPxkZzYuIHB'
    })
.run(function ($ionicPlatform, $cordovaSQLite, $rootScope, $location, $window, $rootScope, toaster, $translate) {
    $ionicPlatform.ready(function () {
        var isloadData = false;
        //navigator.splashscreen.hide();
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        }
        if (window.StatusBar) {
            StatusBar.styleDefault();
        }
      
        if (Connection) {
            if (navigator.network.connection.type == Connection.NONE) {
                isloadData = true;
                $rootScope.online = false;
                $("#toast-container").removeClass('toast-top-right');
                toaster.clear();
                toaster.wait({ title: "", body: $translate.instant('NoInternetConnection'), timeout: 5000 });
            }
        }
    })


    $rootScope.online = navigator.onLine;
    $window.addEventListener("offline", function () {
        $rootScope.$apply(function () {
            $rootScope.online = false;
            $("#toast-container").removeClass('toast-top-right');
            toaster.wait({ title: "", body: $translate.instant('NoInternetConnection'), timeout: 5000 });
        });
    }, false);

    $window.addEventListener("online", function () {
        $rootScope.$apply(function () {
            $rootScope.online = true;
            toaster.clear();
        });
    }, false);

    $rootScope.$on('$locationChangeSuccess', function (e, current, pre) {
        $rootScope.actualLocation = $location.path();
    });

    $rootScope.$watch(function () {
        return $location.path()
    }, function (newLocation, oldLocation, current) {
        if (newLocation === '/tab/dash' || newLocation === '/search/data') {
            $rootScope.isLogoShown = true;
            $rootScope.isbackButton = false;
        }
        if (oldLocation === '/tab/dash' && newLocation !== '/tab/search') {
            $rootScope.isLogoShown = false;
            $rootScope.isbackButton = true;
        }
    });
}).constant('baseUrl', baseUrl).constant('baseUrlforToken', baseUrlforToken).constant('ngAuthSetting', { clientId: 'Amlik' })
.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('product-detail', {
            url: '/product-detail/:url/:ilan_resim/:logo/:id',
            templateUrl: 'templates/tab-product-detail.html',
            controller: 'ProductDetailCtrl'

        })
        .state('tab', {
            url: '/tab',
            abstract: true,
            templateUrl: 'tabs.html'
        })
        .state('tab.dash', {
            url: '/dash',
            views: {
                'tab-dash': {
                    templateUrl: 'templates/tab-dash.html',
                    controller: 'DashCtrl'
                }
            }
        })
        .state('tab.issue-detail', {
            url: '/issues/:id/:title/:kat_liste',
            views: {
                'tab-issues': {
                    templateUrl: 'templates/subMenus.html',
                    controller: 'CommonMenuController'
                }
            }
        })
        .state('tab.search-data', {
            url: '/issues/:query/:categoryId/:kat_liste',
            cache:false,
            views: {
                'tab-issues': {
                    templateUrl: 'templates/searchData.html',
                    controller: 'SearchDataController',
                }
            }
        })

        .state('tab.search-url', {
            url: '/issues/:url',
            views: {
                'tab-issues': {
                    templateUrl: 'templates/searchData.html',
                    controller: 'SearchDataController'
                }
            }
        })
        .state('tab.store-detail', {
            url: '/store-detail/:url/:ilan_resim/:logo/:id',
            views: {
                'tab-dash': {
                    templateUrl: 'templates/tab-store-detail.html',
                    controller: 'StoreDetailCtrl'
                }
            }
        })


        .state('tab.store-follow', {
            url: '/store-follow/:url',
            views: {
                'tab-dash': {
                    templateUrl: 'templates/tab-store-follow.html',
                    controller: 'StoreDetailCtrl'
                }
            }
        })

        .state('tab.search', {
            url: '/search',
            views: {
                'tab-issues': {
                    templateUrl: 'templates/search.html',
                    controller: 'SearchCtrl'
                }
            }
        })
        .state('postAd', {
            url: "/postAd/:redirectState/:params/:previousState/:fromParams",
            templateUrl: 'templates/tab-postAd.html',
            controller: 'PostAdCtrl'

        })


        .state('postAdupload', {
            url: '/postAdupload',
            templateUrl: 'templates/postAd.html',
            controller: 'PostAdController',
            data: {
                required: true
            },
            //resolve: load(['js/controllers/PostAdController.js'])
        })
        //.state('postDetail', {
        //    url: '/postDetail/:categoryId/:kat_Id',
        //    templateUrl: 'templates/postDetail.html',
        //    controller: 'postDetailController'
        //})
         .state('postDetail', {
             url: '/postDetail/:categoryId/:kat_Id/:adID',
             templateUrl: 'templates/postDetail.html',
             controller: 'postDetailController'
         })
        .state('uploadImages', {
            url: '/uploadImages',
            templateUrl: 'templates/uploadImages.html',
            controller: 'uploadImagesCtrl'
        })
        .state('mapViewDetail', {
            url: '/mapViewDetail',
            templateUrl: 'templates/mapViewDetail.html',
            controller: 'mapViewDetailCtrl'
        })

        .state('tab.specialMe', {
            url: '/specialMe',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-specialMe.html',
                    controller: 'SpecialMeCtrl'
                }
            }
        })

        .state('tab.publishedAds', {
            url: '/publishedAds',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-publishedAds.html',
                    controller: 'PublishedAdsCtrl'
                }
            }
        })

        .state('tab.nonPublishedAds', {
            url: '/nonPublishedAds',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-nonPublishedAds.html',
                    controller: 'NonPublishedAdsCtrl'
                }
            }
        })
        .state('tab.myMessages', {
            url: '/myMessages',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-myMessages.html',
                    controller: 'MyMessagesAdsCtrl'
                }
            }
        })
        .state('tab.purchaseTransactions', {
            url: '/purchaseTransactions',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-purchasedTransactions.html',
                    controller: 'PurchaseTransactionController'
                }
            }
        })
        .state('tab.soldTransactions', {
            url: '/soldTransactions',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-soldTransaction.html',
                    controller: 'SoldTransactionController'
                }
            }
        })
        .state('tab.SentMessages', {
            url: '/SentMessages',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-SentMessages.html',
                    controller: 'MySentMessagesCtrl'
                }
            }
        })
        .state('tab.message-detail', {
            url: '/message-detail/:senderId/:recipientUserId/:adId',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-messageDetail.html',
                    controller: 'MyMessageDetailCtrl'
                }
            }
        })
        .state('tab.Inbox', {
            url: '/Inbox',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-Inbox.html',
                    controller: 'MyMessagesInboxCtrl'
                }
            }
        })
        .state('tab.myFavoriteAds', {
            url: '/myFavoriteAds',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-myFavoriteAds.html',
                    controller: 'MyFavoriteAdsCtrl'
                }
            }
        })
        .state('tab.myFavoriteSellers', {
            url: '/myFavoriteSellers',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-myFavoriteSellers.html',
                    controller: 'MyFavoriteSellersCtrl'
                }
            }
        })

        .state('tab.changePassword', {
            url: '/changePassword',
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: 'templates/tab-changePassword.html',
                    controller: 'ChangePasswordCtrl'
                }
            }
        })

        .state('eCommerce', {
            url: '/eCommerce',
            data: {
                required: true
            },
            templateUrl: 'templates/e-commerce.html',
            controller: 'PostAdEcommerceCtrl'
        })
        .state('tab.other', {
            url: '/other',
            cache:false,
            reload:true,
            views: {
                'tab-other': {
                    templateUrl: 'templates/tab-account.html',
                    controller: 'AccountCtrl'
                }
            }
        }).state('tab.cart', {
            url: "/cart/:id",
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: "templates/tab-cartdetail.html",
                    controller: 'CartDetailCtrl'
                }
            }
        }).state('tab.cartAddress', {
            url: "/cartAddress",
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: "templates/tab-cartAddress.html",
                    controller: 'CartAddressCtrl'
                }
            }
        }).state('tab.cartConfirmation', {
            url: "/cartConfirmation",
            data: {
                required: true
            },
            views: {
                'tab-specialMe': {
                    templateUrl: "templates/tab-cartConfirmationList.html",
                    controller: 'CartConfirmationCtrl'
                }
            }
        });
    $urlRouterProvider.otherwise('/tab/search');
}).run(function ($rootScope, AuthService, $state, $ionicNavBarDelegate, CartService, $window, toaster) {
    $rootScope.closePostAdDetail = function () {
        $rootScope.ClosePostAd = false;
        $rootScope.isMainMenuContainer = true;
        $rootScope.isSubMenuContainer = false;
        $rootScope.isLogoShown = true;
        $rootScope.selectedMenusSubMenusId.length = 0;
        $state.go('tab.search', {});

    }
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        //if (!$rootScope.online) {            
        //    $("#toast-container").removeClass('toast-top-right');
        //    toaster.clear();
        //    toaster.wait({ title: "", body: $translate.instant('NoInternetConnection'), timeout: 5000 });
        //    event.preventDefault();
        //}
        //else {
        $rootScope.ClosePostAd = false;
        $rootScope.ProductDetailHomeButton = false;
        if (toState.data) {
            if (toState.data.required) {
                var token = AuthService.GetAccessToken()
                if (token == null) {
                    event.preventDefault();
                    $state.transitionTo('postAd', { redirectState: toState.name, params: JSON.stringify(toParams), previousState: fromState.name, fromParams: JSON.stringify(fromParams) });
                }
            }
        }
        var token = AuthService.GetAccessToken()
        if (toState.name == 'postAd') {
            $rootScope.ClosePostAd = true;
            if (token != null) {
                event.preventDefault();
                $state.transitionTo('postAdupload');
            }
        }
        if (token) {
            $rootScope.fullName = token.fullName;
            $rootScope.userId = token.userId;
            CartService.getCartCount().then(function (response) {
                //console.log(response)
                $rootScope.isAuthorizedUser = true;
                $rootScope.CartCount = response.cartItemsCount;
            }, function (error) { })
        }
        if (toState.name == 'tab.search-data') {
            $rootScope.isCountShow = true;
            $rootScope.isShownMapButton = true;
        }
        else {
            $rootScope.isShownOkButton = false;
            $rootScope.isShownMapButton = false;
            $rootScope.isCountShow = false;
        }

        if (toState.name == 'postAd' || toState.name == 'postAdupload') {
            $rootScope.ClosePostAd = true;
            $rootScope.MainMenuCategories = true;
            $rootScope.isFooterBarShown = false;
            //$rootScope.isMainMenuContainer = true;
            //$rootScope.isSubMenuContainer = false;
            $rootScope.isMainBackButtonShow = false;
        } else {
            $rootScope.isMainBackButtonShow = true;
            $rootScope.isCustomBackButton = false;
        }
        if (toState.name == 'tab.store-detail' || toState.name == 'product-detail') {
            $rootScope.isMainBackButtonShow = true;
            $rootScope.isLogoShown = false;
            $rootScope.isShownMapButton = false;
            $rootScope.isFooterBarShown = false;
            var button = angular.element(document.getElementsByClassName("MainBackButton"))
            if (button.hasClass('hide')) {
                button.removeClass('hide')
            }
        } else if (toState.name == 'tab.dash' || toState.name == 'tab.search') {
            $rootScope.isMainBackButtonShow = false;
            $rootScope.isFooterBarShown = false;
            var button = angular.element(document.getElementsByClassName("MainBackButton"));
            button.addClass('hide')
        }

        if (toState.name == 'tab.store-follow') {
            $rootScope.isShownMapButton = false;
        }
        if (toState.name == 'tab.other') {
            $rootScope.isMainBackButtonShow = false;
        }
        if (toState.name == 'postDetail' || toState.name == 'mapViewDetail' || toState.name == 'uploadImages') {
            $rootScope.ClosePostAd = true;
            if (toState.name == 'postDetail') {
                //$rootScope.currentStep = '1';
                //$('.bar-footer').find('.progress-bar').width('25%')
            }
            if (toState.name == 'mapViewDetail') {
                //$rootScope.currentStep = '2';
                // $('.bar-footer').find('.progress-bar').width('50%')
            }
            if (toState.name == 'uploadImages') {
                //$rootScope.currentStep = '3';
                // $('.bar-footer').find('.progress-bar').width('50%')
            }
            if ($rootScope.totalSteps == 4) {
                var staticWidth = 25;
                var setWidth = ($rootScope.currentStep * staticWidth);
                $('.bar-footer').find('.progress-bar').width(setWidth + '%')

            }
            if ($rootScope.totalSteps == 3) {
                var staticWidth = 33.33;
                var setWidth = ($rootScope.currentStep * staticWidth);
                $('.bar-footer').find('.progress-bar').width(setWidth + '%')

            }
            $rootScope.isFooterBarShown = true;
        }
        if (toState.name == "tab.cart" || toState.name == "tab.cartAddress" || toState.name == 'tab.cartConfirmation') {
            $rootScope.isLogoShown = false;
        }
        if (toState.name == "tab.dash" || toState.name == "tab.search" || toState.name == 'tab.other') {
            $rootScope.isLogoShown = true;
        }
        if (toState.name == "tab.issue-detail") {
            $rootScope.isMainBackButtonShow = true;
            $rootScope.isShownMapButton = false;
            var button = angular.element(document.getElementsByClassName("MainBackButton"))
            if (button.hasClass('hide')) {
                button.removeClass('hide')
            }
        }
        if (toState.name == 'tab.search-data') {
            $rootScope.isShownMapButton = true;
            $rootScope.isCountShow = true;
            $rootScope.isMainBackButtonShow = true;
        }
        if (toState.name == 'product-detail') {
            if (toParams.id == $rootScope.PostInsertedId) {
                $rootScope.ProductDetailHomeButton = true;
            }

        }
        //}
    })
    $rootScope.$on('$ionicView.afterEnter', function (event, data) {
        //$ionicNavBarDelegate.showBackButton(true);
        if ($state.current.name == "product-detail" || $state.current.name == "tab.store-follow" || $state.current.name == "postDetail") {
            setTimeout(function () {
                var button = angular.element(document.getElementsByClassName("MainBackButton"))
                angular.forEach(button, function (obj) {
                    if (angular.element(obj).hasClass('hide')) {
                        angular.element(obj).removeClass('hide');
                    }
                })
            }, 100)
        }

        if ($state.current.name == "tab.search-data") {
            setTimeout(function () {
                var button = angular.element(document.getElementsByClassName("MainBackButton"))
                angular.forEach(button, function (obj) {
                    if (angular.element(obj).hasClass('hide')) {
                        angular.element(obj).removeClass('hide');
                    }
                })
                $rootScope.isShownMapButton = true;
                $rootScope.isCountShow = true;
                $rootScope.isMainBackButtonShow = true;
            }, 200)
        }

    })
});

