﻿angular.module('myApp').controller('CartAddressCtrl', function ($scope, $rootScope, $state, CartService, $ionicLoading, $ionicModal, $ionicHistory, $translate, $ionicPlatform) {
    $scope.AddressList = [];
    $scope.isAddAdressShow = false;
    $scope.cityList = [];
    var markersArray = [];

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }

    $scope.newAddress = {
        address: '',
        cityID: 0,
        title: '',
        LngLat: '',
        phone: '',
    }
    function getAddress() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.getAddress().then(function (response) {
            //console.log(response);
            $scope.AddressList = response;
            $ionicLoading.hide();
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    };
    function getCityList() {
        CartService.getCityList().then(function (response) {
            //console.log(response);
            $scope.cityList = response;
            $scope.newAddress.cityID = response[0].id;
        }, function (error) {
            console.log(error)
        });
    };
    $scope.add = function () {
        $scope.newAddress.LngLat = $scope.locationLatLng;
        CartService.SaveAddress($scope.newAddress).then(function (response) {
            $rootScope.SelectedAddressID = response;
            $state.go('tab.cartConfirmation');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        })
    }
    $scope.SelectAddress = function (address) {
        $rootScope.SelectedAddressID = address.id;
        $state.go('tab.cartConfirmation');
    }
    $scope.AddNewAddress = function () {
        $scope.isAddAdressShow = true;
        setTimeout(function () {
            initMap();
        }, 500);
    }
    $scope.addAddressCancel = function () {
        $scope.isAddAdressShow = false;
    }
    function initMap() {
        $("#mapdiv").removeAttr("style");
        $("#mapdiv").innerHTML = '';
        var mapDiv = angular.element(document.getElementById("mapdiv"));
        if (mapDiv[0].innerHTML == "") {
            var latlng = new google.maps.LatLng(24.266906, 45.1078489);
            var myOptions = {
                zoom: 4,
                center: latlng,
                mapTypeControl: true,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById("mapdiv"), myOptions);

            //add a click event handler to the map object
            google.maps.event.addListener(map, "click", function (event) {
                // place a marker
                placeMarker(event.latLng);

                $scope.locationLatLng = event.latLng.lat() + "," + event.latLng.lng();
                //// display the lat/lng in your form's lat/lng fields
                //document.getElementById("latFld").value = event.latLng.lat();
                //document.getElementById("lngFld").value = event.latLng.lng();
            });
        }
    }
    function placeMarker(location) {
        // first remove all markers if there are any
        deleteOverlays();

        var marker = new google.maps.Marker({
            position: location,
            map: map
        });

        // add marker in markers array
        markersArray.push(marker);
    }

    // Deletes all markers in the array by removing references to them
    function deleteOverlays() {
        if (markersArray) {
            for (i in markersArray) {
                markersArray[i].setMap(null);
            }
            markersArray.length = 0;
        }
    }

    $ionicPlatform.ready(function () {
        getAddress();
        getCityList();
    });
});