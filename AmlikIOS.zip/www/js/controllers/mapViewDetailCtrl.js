﻿angular.module('myApp').controller('mapViewDetailCtrl', function ($scope, $translate, $rootScope, $ionicHistory, PostDetailServices, $stateParams, $ionicLoading, $ionicPopup, $state, $ionicPlatform) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isFooterBarShown = true;
    $rootScope.currentStep++;
    //$('.bar-footer').find('.progress-bar').width('50%')
    var map;
    var markersArray = [];
    $rootScope.locationLatLng = '';

    function initMap() {
        var latlng = null;
        if ($rootScope.userLocationLatLng) {
            var lat = $rootScope.userLocationLatLng.split(",")[0];
            var long = $rootScope.userLocationLatLng.split(",")[1];
            latlng = new google.maps.LatLng(lat, long);
            //latlng = new google.maps.LatLng($rootScope.userLocationLatLng);


        } else {
            latlng = new google.maps.LatLng(24.266906, 45.1078489);
        }
        var myOptions = {
            zoom: 14,
            center: latlng,
            mapTypeControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("mapViewDetail"), myOptions);

        // add a click event handler to the map object
        google.maps.event.addListener(map, "click", function (event) {
            // place a marker
            placeMarker(event.latLng);

            $rootScope.locationLatLng = event.latLng.lat() + "," + event.latLng.lng();
            //// display the lat/lng in your form's lat/lng fields
            //document.getElementById("latFld").value = event.latLng.lat();
            //document.getElementById("lngFld").value = event.latLng.lng();
        });

        if ($rootScope.userLocationLatLng) {
            var lat = $rootScope.userLocationLatLng.split(",")[0];
            var long = $rootScope.userLocationLatLng.split(",")[1];
            latlng = new google.maps.LatLng(lat, long);
            $rootScope.locationLatLng = $rootScope.userLocationLatLng;
            placeMarker(latlng);
        }

    }
    function placeMarker(location) {
        // first remove all markers if there are any
        deleteOverlays();

        var marker = new google.maps.Marker({
            position: location,
            map: map
        });

        // add marker in markers array
        markersArray.push(marker);
    }



    // Deletes all markers in the array by removing references to them
    function deleteOverlays() {
        if (markersArray) {
            for (i in markersArray) {
                markersArray[i].setMap(null);
            }
            markersArray.length = 0;
        }
    }
    $ionicPlatform.ready(function () {
        initMap();

        if ($rootScope.totalSteps == 3 && $rootScope.currentStep == 2) {
            $('.bar-footer').find('.progress-bar').width('66.66%')
        }       
        else if ($rootScope.totalSteps == 4 && $rootScope.currentStep == 2) {
            $('.bar-footer').find('.progress-bar').width('50%')
        }
        else if ($rootScope.totalSteps == 2 && $rootScope.currentStep == 2) {
            $('.bar-footer').find('.progress-bar').width('100%')
        }
        else {
            //$('.bar-footer').find('.progress-bar').width('66.66%')
        }

    });

    function showAlertPopup() {
        var alertPopup = $ionicPopup.alert({
            title: 'Location',
            template: 'Please select your location'
        });
        alertPopup.then(function (res) {

        });
    }

    $scope.PostLocationLatlng = function () {
        if ($rootScope.locationLatLng == '') {
            showAlertPopup();
        }
        else {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            PostDetailServices.postAdLocation($rootScope.locationLatLng, $rootScope.PostInsertedId).then(function (res) {
                $ionicLoading.hide();
                if (res.data == true) {
                    $state.go('uploadImages', {});
                }
            }, function (error) {
                console.log(error)
                $ionicLoading.hide();
            });
        }
    }

});