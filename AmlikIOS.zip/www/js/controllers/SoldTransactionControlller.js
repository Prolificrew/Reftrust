﻿angular.module('myApp').controller('SoldTransactionController', function ($scope, $translate, $rootScope, MyAccountServices, $ionicLoading, $ionicHistory) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }


    $scope.SoldTransactionList = [];
    function getAccountSoldTransactions() {
        $scope.isResponse = false;
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.GetAccountSoldTransactions().then(function (response) {
            $ionicLoading.hide();
            $scope.isResponse = true;
            $scope.SoldTransactionList = response;
        }, function (error) { $ionicLoading.hide(); console.log(error); $scope.isResponse = true; })
    }
    getAccountSoldTransactions();
})