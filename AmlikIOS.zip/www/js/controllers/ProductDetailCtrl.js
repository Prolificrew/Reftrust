﻿
angular.module('myApp').controller('ProductDetailCtrl', function ($scope, $translate, $rootScope, $stateParams, $ionicHistory, StoreService, $ionicLoading, $timeout, $ionicSlideBoxDelegate, $ionicModal, $ionicActionSheet, $state, $sce) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $scope.locationMapView = '';
    $scope.ProductDetail = [];
    $scope.location_longlat = '';
    $rootScope.isbackButton = true;
    $scope.isEcommerce = 0;
    $scope.dataloaded = false;
    $scope.ProductIamgeURL = "https://www.amlik.com/img_post/xl/";

    $scope.trustAsHtml = function (string) {
        return $sce.trustAsHtml(string);
    };

    $rootScope.myGoBack = function () {

        $scope.$emit('$locationChangeSuccess', {});
        $ionicHistory.goBack(-1);
        if ($state.current.name == 'tab.issue-detail' || $state.current.name == 'tab.search-data') {
            if ($rootScope.getAllMenuProducts != undefined) {
                var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 1];
                var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
                $rootScope.selectedMenus = last_element;
                $rootScope.selectedMenusId = last_elementId;
                // $rootScope.selectedMenusSubMenus.splice(-1, 1);
                $rootScope.getAllMenuProducts = undefined;

            }
            else {

                var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 2];
                var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
                $rootScope.selectedMenus = last_element;
                $rootScope.selectedMenusId = last_elementId;
                $rootScope.selectedMenusSubMenus.splice(-1, 1);
                //}
            }
            if ($state.current.name == 'product-detail') {
                $rootScope.isShownMapButton = true;
                $rootScope.isCountShow = true;
                $rootScope.isMainBackButtonShow = true;
            }
        }
    };
    $scope.$on("BindMap", function (event, data) {
        var city = '';
        if ($translate.use() == 'en') {
            city = $scope.adDetail.city_en
        }
        else {
            city = $scope.adDetail.city_ar
        }
        var lat = $scope.location_longlat.split(",")[0];
        var long = $scope.location_longlat.split(",")[1];
        var latlng = new google.maps.LatLng(lat, long);
        var map = new google.maps.Map(document.getElementById('MapDetail'),
            {
                zoom: 12,
                center: latlng,
                mapTypeControl: false,
                streetViewControl: false,
                panControl: false,
                mapTypeControlOptions: { mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style'] },

            });
        var infowindow = new google.maps.InfoWindow({
            content: city
        });

        var marker = new google.maps.Marker({
            position: latlng,
            map: map
        });

        var mkID = document.getElementById('MapDetail');

        google.maps.event.addListener(marker, 'click', (function (marker, infowindow, mkID) {
            return function () {
                if (infowindow) {
                    infowindow.close();
                }
                infowindow.open(map, marker);
                infoWindowAjax(mkID, function (data) {
                    infowindow.setContent(data);
                });
            };
        })(marker, infowindow, mkID));

        infowindow.open(map, marker);
    });

    $scope.getProductDetail = function (productId) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        StoreService.productDetail(productId).then(function (res) {
            $scope.isEcommerce = res.data.adDetail.ecom;
            $scope.breadcrumbs = res.data.breadcrumb;
            $scope.location_longlat = res.data.adDetail.location_longlat;
            $scope.adDetail = res.data.adDetail;
            $scope.addetailstore = res.data.addetailstore;
            $scope.ProductContactNumber = res.data.adDetail.gsm;
            $scope.productDetailMainProperties = res.data.detailPageHeaderValues;
            $scope.productDetailproperties = res.data.productDetailproperties;
            $ionicSlideBoxDelegate.update();
            $scope.ProductDetail = res.data;
            $scope.dataloaded = true;
            $ionicLoading.hide();
            //$scope.ShowDetailMapLocation();
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.followSeller = function (addetailstore, adDetail) {
        if (addetailstore != null) {
            $state.go('tab.store-follow', { url: addetailstore.url });
        }
    }

    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openModal = function (index) {
        $ionicSlideBoxDelegate.slide(index);
        $scope.modal.show();
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hide', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });
    $scope.$on('modal.shown', function () {
        console.log('Modal is shown!');
    });

    // Call this functions if you need to manually control the slides
    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.goToSlide = function (index) {
        $scope.modal.show();
        $ionicSlideBoxDelegate.slide(index);
    }

    $scope.pagerClick = function (index) {
        $ionicSlideBoxDelegate.slide(index);
    }

    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
    };

    function generateActionSheetButton() {
        var buttons = [];
        var button = {};
        var text = "";
        if ($translate.use() == 'en') {
            for (var i = 0; i < $scope.breadcrumbs.length; i++) {
                button = {
                    text: $scope.breadcrumbs[i].ad_en
                }
                buttons.push(button);
            }
        }
        else {
            for (var i = 0; i < $scope.breadcrumbs.length; i++) {
                button = {
                    text: $scope.breadcrumbs[i].ad_ar
                }
                buttons.push(button);
            }
        }
        return buttons;
    }

    $scope.showbreadcrumbsActionsheet = function () {
        var title = '';
        var cancelButton = '';
        if ($translate.use() == 'en') {
            title = translations_en.PickCategory;
            cancelButton = translations_en.Cancel;
        }
        else {
            title = translations_ar.PickCategory;
            cancelButton = translations_ar.Cancel;
        }
        $ionicActionSheet.show({
            titleText: title,
            buttons: generateActionSheetButton(),
            cancelText: cancelButton,
            cancel: function () {
                console.log('CANCELLED');
            },
            buttonClicked: function (index) {
                console.log('BUTTON CLICKED', index);
                var kat_id = "";
                $rootScope.selectedMenusSubMenus = [];
                if ($rootScope.language == "en") {
                    for (var i = 0; i <= index; i++) {
                        kat_id += $scope.breadcrumbs[i].id + ".";
                        $rootScope.selectedMenusSubMenus.push($scope.breadcrumbs[i].ad_en);
                    }
                }
                else {
                    for (var i = 0; i <= index; i++) {
                        kat_id += $scope.breadcrumbs[i].id + ".";
                        $rootScope.selectedMenusSubMenus.push($scope.breadcrumbs[i].ad_ar);
                    }
                }
                var buttonData = $scope.breadcrumbs[index];
                if ($scope.breadcrumbs.length - 1 != index) {
                    if ($rootScope.language == "en") {
                        $rootScope.mainMenuSelected = $scope.breadcrumbs[0].ad_en;
                        $rootScope.menuMainTitle = $scope.breadcrumbs[0].ad_en;
                        $rootScope.selectedMenus = buttonData.ad_en;
                        $state.go("tab.issue-detail", { id: buttonData.id, title: buttonData.ad_en, kat_liste: kat_id })
                    }
                    else {
                        $rootScope.mainMenuSelected = $scope.breadcrumbs[0].ad_ar;
                        $rootScope.menuMainTitle = $scope.breadcrumbs[0].ad_ar;
                        $rootScope.selectedMenus = buttonData.ad_ar;
                        $state.go("tab.issue-detail", { id: buttonData.id, title: buttonData.ad_ar, kat_liste: kat_id })
                    }
                }
                else {
                    $state.go('tab.search-data', { query: "", categoryId: buttonData.id, kat_liste: kat_id });
                }

                //$state.go('tab.search-data', { query: "", categoryId: selectedId, kat_liste: $rootScope.selectedMenuskat_liste });
                return true;
            }
        });
    };


    $scope.showActionsheet = function () {
        var title = '';
        var cancelButton = '';
        if ($translate.use() == 'en') {
            title = translations_en.CallNow;
            cancelButton = translations_en.Cancel;
        }
        else {
            title = translations_ar.CallNow;
            cancelButton = translations_ar.Cancel;
        }
        $ionicActionSheet.show({
            titleText: title,
            buttons: [
              { text: '<a href=tel:"' + $scope.ProductContactNumber + '"><i class="fa fa-phone" aria-hidden="true"></i> ' + $scope.ProductContactNumber + '</a>' },
              //{ text: '<i class="icon ion-arrow-move"></i> Move' },
            ],
            cancelText: cancelButton,
            cancel: function () {
                console.log('CANCELLED');
            },
            buttonClicked: function (index) {
                window.open('tel:' + $scope.ProductContactNumber, '_system');
            }
        });
    }

    //$scope.showLoginPopUp = function () {
    //    $scope.Loginmodal.show();
    //}

    //$ionicModal.fromTemplateUrl('Loginmodal.html', {
    //    scope: $scope,
    //    animation: 'slide-in-up'
    //}).then(function (modal) {
    //    $scope.Loginmodal = modal;
    //});


    //$scope.openLoginmodal = function () {
    //    $scope.Loginmodal.show();
    //};
    //$scope.closeLoginmodal = function () {
    //    $scope.Loginmodal.hide();
    //};

    $scope.getProductDetail($stateParams.id);

})