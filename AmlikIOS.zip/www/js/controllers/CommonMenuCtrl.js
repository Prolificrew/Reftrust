﻿angular.module('myApp').controller('CommonMenuController', ['$scope', '$rootScope', '$stateParams', '$state', '$location', '$ionicLoading', 'Search', '$ionicHistory', '$cordovaSQLite', function ($scope, $rootScope, $stateParams, $state, $location, $ionicLoading, Search, $ionicHistory, $cordovaSQLite) {
    $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
    $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS Tbl_Menu (id integer, ad_en text, ad_ar text, ads integer, selectedId integer, kat_liste float)");
    $rootScope.isLogoShown = false;
    //debugger
    $rootScope.selectedMenusSubMenusId.push($stateParams.id);
    $rootScope.selectedMenusId = $stateParams.id;
    $rootScope.selectedMenuskat_liste = $stateParams.kat_liste;
    $rootScope.myGoBack = function () {
        //var index = $rootScope.selectedMenusSubMenus.indexOf($rootScope.selectedMenusSubMenus);
        var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 2];
        var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
        $rootScope.selectedMenus = last_element;
        $rootScope.selectedMenusId = last_elementId;
        $rootScope.selectedMenusSubMenus.splice(-1, 1);
        if ($rootScope.selectedMenusSubMenus.length == 0) {
            $rootScope.isLogoShown = true;
        }
        $ionicHistory.goBack();
    };

    $scope.setTitle = function (id, title, kat_Id) {
        $rootScope.isLogoShown = false;
        setTimeout(function () {
            $rootScope.selectedMenusSubMenus.push(title);
            $rootScope.selectedMenus = title;
        }, 100);
        $scope.selectCount(id, title, kat_Id);
    }

    $scope.getAllProducts = function (query, id, kat_Id) {
        $rootScope.getAllMenuProducts = true;
        $rootScope.filterObjData = undefined;
        $state.go('tab.search-data', { query: query, categoryId: id, kat_liste: kat_Id });
    }

    $scope.getNewCommonSubMainMenu = function (selectedId, title, kat_Id) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        Search.commonMenu(selectedId).then(function (res) {
            try {
                if (res.data.length > 0) {
                    $scope.insert(selectedId, res.data);
                    //submenu
                    setTimeout(function () {
                        $ionicLoading.hide();
                        $rootScope.isShownMapButton = false;
                        $rootScope.filterObjData = undefined;
                        $state.go('tab.issue-detail', { id: selectedId, title: title, kat_liste: kat_Id });
                    }, 2000);
                }
                else {
                    $rootScope.isShownMapButton = true;
                    $rootScope.isShownMapsButton = true;
                    $ionicLoading.hide();
                    $rootScope.filterObjData = undefined;
                    $state.go('tab.search-data', { query: "", categoryId: selectedId, kat_liste: kat_Id });
                }
            }
            catch (e) {
                console.log(e.message);
            }
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.selectCount = function (selectedId, title, kat_Id) {
        $rootScope.MenuSelectedId = selectedId;
        try {
            var query = "SELECT id, ad_en, ad_ar, ads, kat_liste FROM Tbl_Menu WHERE selectedId = ?";
            $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {
                if (res.rows.length > 0) {                    //submenu 
                    $state.go('tab.issue-detail', { id: selectedId, title: title, kat_liste: kat_Id });
                    //setTimeout(function () {
                    //$rootScope.selectedMenusSubMenus.push(title);
                    //$rootScope.selectedMenus = title;
                    //}, 100);
                } else {
                    $scope.getNewCommonSubMainMenu(selectedId, title, kat_Id);
                }
            }, function (err) {
                //alert(err);
                console.log(err);
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }


    $scope.selectedMenuAndSubMenu_en = [];
    $scope.selectedMenuAndSubMenu_ar = [];

    if ($scope.selectedMenuAndSubMenu_en.length == 0) {
        if ($rootScope.selectedMenuAndSubMenuData_en == undefined) {
            $rootScope.selectedMenuAndSubMenuData_en = [];
            $rootScope.mainMenuSelected = $stateParams.title_en;
            $rootScope.selectedMenuAndSubMenuData_en.push({ 'selected ': $stateParams.title_en });
        }
        //else {
        //    $rootScope.selectedMenuAndSubMenuData_en.push({ 'selected': $stateParams.title_en });
        //}
    }

    $scope.getCommonSubMainMenu = function () {
        $scope.results = [];
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        Search.commonMenu($stateParams.id).then(function (res) {
            //debugger
            try {
                if (res.data.length > 0) {
                    //$scope.results = res.data;                   
                    $rootScope.locations = res.data;
                    $scope.insert($stateParams.id, res.data);
                    $scope.results = res.data;
                    setTimeout(function () {
                        $scope.select($stateParams.id);
                    }, 500);
                }
                else {
                    //$state.go('tab.search-data', { query: "", categoryId: $stateParams.id });
                    $scope.getNewCommonSubMainMenu($stateParams.id, $stateParams.title_en, $rootScope.selectedMenuskat_liste);
                    // $state.go('tab.search-data', { query: "", categoryId: $stateParams.id, kat_liste: $rootScope.selectedMenuskat_liste });
                }
                $ionicLoading.hide();
            }
            catch (e) {
                console.log(e.message);
            }

        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }
    $scope.deleteData = function (selectedId) {
        $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
        var query = "DELETE FROM Tbl_Menu where selectedId=?";
        $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {
            console.log(res);
        }, function (err) {
            console.log(err);
        });
    }
    //$scope.deletetable = function () {
    //    $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
    //    var query = "DELETE from Menu";
    //    $cordovaSQLite.execute($rootScope.db, query).then(function (res) {
    //        console.log(res);
    //    }, function (err) {
    //        console.log(err);
    //    });
    //}
    //$scope.deletetable();
    $scope.select = function (selectedId) {
        $rootScope.MenuSelectedId = selectedId;
        try {
            var query = "SELECT id, ad_en, ad_ar, ads, kat_liste FROM Tbl_Menu WHERE selectedId = ?";
            $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {
                $scope.results = [];
                if (res.rows.length > 0) {
                    for (var i = 0; i < res.rows.length; i++) {
                        $scope.results.push(res.rows.item(i));
                    }
                } else {
                    $scope.getCommonSubMainMenu();
                }
            }, function (err) {
                //alert(err);
                console.log(err);
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }
    $scope.select($stateParams.id);

    $scope.reloadData = function () {
        Search.commonMenu($stateParams.id).then(function (res) {
            try {
                ////debugger
                $scope.results = [];
                if (res.data.length > 0) {
                    $scope.results = res.data;

                    $scope.insert($stateParams.id, res.data);
                    $scope.$broadcast('scroll.refreshComplete');
                }
                $ionicLoading.hide();
            }
            catch (e) {
                console.log(e.message);
            }
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.doRefresh = function () {
        $scope.deleteData($stateParams.id);
        $scope.reloadData();
    };

    $scope.insert = function (selectedId, menuList) {
        try {
            angular.forEach(menuList, function (value, index) {
                if (value.ads > 0) {
                    var query = "INSERT INTO Tbl_Menu (id, ad_en, ad_ar, ads, selectedId, kat_liste) VALUES (?,?,?,?,?,?)";
                    $cordovaSQLite.execute($rootScope.db, query, [value.id, value.ad_en, value.ad_ar, value.ads, selectedId, value.kat_liste]).then(function (res) {
                        var message = "INSERT ID -> " + res.insertId;
                        //console.log(message);
                    }, function (err) {
                        console.log(err);
                        //alert(err);
                    });
                }
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }

    $scope.goto = function () {
        //$state.transitionTo("tab.issue-steps");
        $state.go('tab.issue-steps', '{vertragsNr:1}')
        // $location.url("tab/issues/1/steps");
    }


}])