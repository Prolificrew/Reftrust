﻿angular.module('myApp').controller('PurchaseTransactionController', function ($scope, $translate, $rootScope, MyAccountServices, $ionicLoading, $ionicHistory) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $scope.PurchaseTransactionList = [];

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }

    function getAccountPurchaseTransactions() {
        $scope.isResponse = false;
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.GetAccountPurchaseTransactions().then(function (response) {
            $ionicLoading.hide();
            $scope.isResponse = true;
            $scope.PurchaseTransactionList = response;
        }, function (error) { $ionicLoading.hide(); console.log(error); $scope.isResponse = true; })
    }
    getAccountPurchaseTransactions();
})