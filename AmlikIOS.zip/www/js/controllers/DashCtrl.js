﻿angular.module('myApp').filter('split', function () {
    return function (input, splitChar, splitIndex) {
        // do some bounds checking here to ensure it has that index
        return input.split(splitChar)[splitIndex];
    }
});

angular.module('myApp').controller('DashCtrl', function ($scope, $rootScope, $translate, $ionicLoading, StoreService, $state, $ionicScrollDelegate) {
    $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/adv";
    $rootScope.language = $translate.use();
    $scope.pageNo = "1";
    $scope.isScrolldown = false;
    $rootScope.isCountShow = false;
    $scope.storeData = [];
    $rootScope.isShownMapButton = false;
    $rootScope.isShownMapsButton = false;
    $rootScope.isShownListingButton = false;
    $scope.noMoreItemsAvailable = false;

    $scope.loadMore = function () {
        if ($scope.storeData.length == 0) {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
        }

        StoreService.getStore($scope.pageNo).then(function (res) {
            if (res.data.length > 0) {
                $scope.storeData.push.apply($scope.storeData, res.data);
                $scope.pageNo++;
            }
            else {
                $scope.noMoreItemsAvailable = true;
            }

            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });


    };

    $scope.getProductDetail = function (product) {
        if (product.type == "Store") {
            $state.go('tab.store-detail', { url: product.url, logo: product.logo, ilan_resim: product.ilan_resim, id: product.ilan_no });
        }
        else {
            $state.go('product-detail', { url: product.url, logo: product.logo, ilan_resim: product.ilan_resim, id: product.ilan_no });
        }
    }

});