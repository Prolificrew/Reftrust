﻿

angular.module('myApp').controller('uploadImagesCtrl', function ($scope, $translate, $rootScope, $ionicHistory, PostDetailServices, $stateParams, $ionicLoading, $ionicPopup, $compile, baseUrl, AuthService, $cordovaImagePicker, $state, $ionicPlatform) {
    var token = AuthService.GetAccessToken();
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isFooterBarShown = true;
    $rootScope.currentStep++;
    $scope.DataArray = [];
    $scope.isShowError = false;
    $scope.uploadedIamgeURL = "https://www.amlik.com/img_post/thumb/";
    $scope.errorMessage = '';
    //if ($rootScope.totalSteps == 2) {
    //    $('.bar-footer').find('.progress-bar').width('100%')
    //} else if ($rootScope.totalSteps == 3 && $rootScope.redirectToEcommerce == false) {
    //    $('.bar-footer').find('.progress-bar').width('100%')
    //} else {
    //    $('.bar-footer').find('.progress-bar').width('66.66%')
    //}
    function cameraSuccess(imageData) {
        $scope.buttonDistabled = false;
        if ($scope.DataArray.length === 0 && $rootScope.userUploadedImages.length===0) {
            $scope.DataArray.push({ ilanid: $rootScope.PostInsertedId, Image: imageData, ImageName: 'Capture' + $rootScope.PostInsertedId + '-' + new Date().getMilliseconds() + '.jpeg', selected: true });
        } else {
            $scope.DataArray.push({ ilanid: $rootScope.PostInsertedId, Image: imageData, ImageName: 'Capture' + $rootScope.PostInsertedId + '-' + new Date().getMilliseconds() + '.jpeg', selected: false });
        }
        
        $scope.$apply();
        //var html = "<div class='img-container' id='image" + Images.indexOf(imageData) + "'><span class='remove-image-button'><button ng-click='RemoveImage(" + Images.indexOf(imageData) + ")'><i class='fa fa-trash-o'></i></button></span><img src='data:image/jpeg;base64," + imageData + "'/> </div>";

        //angular.element(document.getElementById("imagePreview")).append($compile(html)($scope));
    }
    function cameraError(error) {
        navigator.camera.cleanup();
        console.log(error);
        alert(JSON.stringify(error));
    }
    var cameraOptions = {
        quality: 50,
        destinationType: Camera.DestinationType.DATA_URL,
        sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
        allowEdit: true,
        encodingType: Camera.EncodingType.JPEG,
        popoverOptions: CameraPopoverOptions,
        saveToPhotoAlbum: false
    }
    var ImagePickerOptions = {
        maximumImagesCount: 10,
        width: 800,
        height: 800,
        quality: 80
    }
    var uploadedImageCount = 0;
    if ($rootScope.userUploadedImages) {
        if ($rootScope.userUploadedImages.length > 0) {
            uploadedImageCount = $rootScope.userUploadedImages.length;
            ImagePickerOptions.maximumImagesCount = 10 - uploadedImageCount;
        }
    }
    $scope.checkDisabled = function () {
        if ($rootScope.userUploadedImages.length > 0) {
            $scope.buttonDistabled = false;
        } else if ($scope.DataArray.length > 0) {
            $scope.buttonDistabled = false;
        } else {
            $scope.buttonDistabled = true;
        }
    }
    $scope.checkDisabled();

    $ionicPlatform.ready(function () {        
        if ($rootScope.totalSteps == 3 && $rootScope.currentStep == 3) {
            $('.bar-footer').find('.progress-bar').width('100%')
        }
        else if ($rootScope.totalSteps == 4 && $rootScope.currentStep == 3) {
            $('.bar-footer').find('.progress-bar').width('75%')
        }
        else {
            //$('.bar-footer').find('.progress-bar').width('66.66%')
        }

    });

    $scope.getPictureFromPhoneLibrary = function () {
        $scope.isShowError = false;
        //cameraOptions.sourceType = Camera.PictureSourceType.PHOTOLIBRARY;
        //navigator.camera.getPicture(cameraSuccess, cameraError, cameraOptions);
        if ($scope.DataArray.length + uploadedImageCount < 10) {
            ImagePickerOptions.maximumImagesCount = 10 - $scope.DataArray.length - uploadedImageCount;
            $cordovaImagePicker.getPictures(ImagePickerOptions).then(function (result) {

                for (var i = 0; i < result.length; i++) {
                    
                    $scope.buttonDistabled = false;
                    window.plugins.Base64.encodeFile(result[i], function (base64) {
                        if ($scope.DataArray.length === 0 && $rootScope.userUploadedImages.length === 0) {
                            $scope.DataArray.push({ ilanid: $rootScope.PostInsertedId, Image: base64.substring(base64.lastIndexOf(',') + 1), ImageName: "upload" + $rootScope.PostInsertedId + '-' + new Date().getMilliseconds() + '.jpeg', selected: true });
                        } else {
                            $scope.DataArray.push({ ilanid: $rootScope.PostInsertedId, Image: base64.substring(base64.lastIndexOf(',') + 1), ImageName: "upload" + $rootScope.PostInsertedId + '-' + new Date().getMilliseconds() + '.jpeg', selected: false });
                        }
                        
                        $scope.$apply();
                    });
                }

            }, function (message) {
                $scope.isShowError = true;
                $scope.errorMessage = message;
            })
        } else {
            $scope.isShowError = true;
            $scope.errorMessage = $translate.instant('Youcanupload10Images');
        }
    }
    $scope.getPicture = function () {
        $scope.isShowError = false;
        if ($scope.DataArray.length + uploadedImageCount < 10) {
            cameraOptions.sourceType = Camera.PictureSourceType.CAMERA;
            navigator.camera.getPicture(cameraSuccess, cameraError, cameraOptions);
        } else {
            $scope.isShowError = true;
            $scope.errorMessage = $translate.instant('Youcanupload10Images');
        }
    }

    //function win(r) {
    //    console.log("Code = " + r.responseCode);
    //    console.log("Response = " + r.response);
    //    console.log("Sent = " + r.bytesSent);
    //}

    //function fail(error) {
    //    alert("An error has occurred: Code = " + error.code);
    //    console.log("upload error source " + error.source);
    //    console.log("upload error target " + error.target);
    //}

    //function filetransfer(id,fileURL) {

    //    var uri = encodeURI(baseUrl + "/api/Postadd/PostadImages");

    //    var options = new FileUploadOptions();
    //    options.fileKey = "file";
    //    options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
    //    options.mimeType = "image/jpeg";
    //    options.chunkedMode = false;
    //    options.httpMethod='POST'
    //    var params={id:id}
    //    var headers = {
    //        Connection: "close",
    //        'Content-Type': 'application/json',
    //        'Authorization': 'bearer ' + token.access_token
    //    };

    //    options.headers = headers;
    //    options.params = params;
    //    var ft = new FileTransfer();
    //    ft.onprogress = function (progressEvent) {
    //        console.log(progressEvent);
    //        if (progressEvent.lengthComputable) {
    //            //loadingStatus.setPercentage(progressEvent.loaded / progressEvent.total);
    //        } else {
    //            //loadingStatus.increment();
    //        }
    //    };
    //    ft.upload(fileURL, uri, win, fail, options);
    //}

    //if ($rootScope.userUploadedImages) {
    //    $scope.DataArray = $rootScope.userUploadedImages;
    //}

    $scope.PostUploadImages = function () {
        $scope.isShowError = false;

        if ($rootScope.userUploadedImages.length > 0 || $scope.DataArray.length > 0) {
            if ($scope.DataArray.length > 0) {
                $ionicLoading.show({
                    content: 'Loading...',
                    animation: 'fade-in',
                    showBackdrop: true,
                    maxWidth: 200,
                    showDelay: 0
                });
                PostDetailServices.postAdImages($scope.DataArray).then(function (response) {
                    console.log(response);
                    $ionicLoading.hide();
                    if ($rootScope.redirectToEcommerce) {
                        $state.go('eCommerce');
                    } else {
                        $state.go("product-detail", { url: null, ilan_resim: null, logo: null, id: $rootScope.PostInsertedId });
                    }
                }, function (error) {
                    console.log(error)
                    $ionicLoading.hide();
                });
            }
            else {
                if ($rootScope.redirectToEcommerce) {
                    $state.go('eCommerce');
                } else {
                    $state.go("product-detail", { url: null, ilan_resim: null, logo: null, id: $rootScope.PostInsertedId });
                }
            }
        } else {
            $scope.isShowError = true;
            $scope.errorMessage = 'Please select Image';
        }
    }

    $scope.RemoveImage = function (index, title) {
        if (title == 'new') {
            $scope.DataArray.splice(index, 1);
        }
        else {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            PostDetailServices.deleteUploadedImageById($rootScope.userUploadedImages[index].id).then(function (res) {
                if (res.data == true) {
                    uploadedImageCount--;
                    $rootScope.userUploadedImages.splice(index, 1);
                }
                //$rootScope.userUploadedImages[index].selected = true;
                $ionicLoading.hide();
            }, function (error) {
                console.log(error)
                $ionicLoading.hide();
            });

        }


    }
    $scope.SelectImage = function (index, title) {
        angular.forEach($scope.DataArray, function (obj) {
            obj.selected = false;
        });
        angular.forEach($rootScope.userUploadedImages, function (obj) {
            obj.selected = false;
        });
        if (title == 'new') {
            $scope.DataArray[index].selected = true;
        }
        else {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            PostDetailServices.updateSelectedImage($rootScope.userUploadedImages[index].id, $rootScope.userUploadedImages[index].ilanid).then(function (res) {
                if (res.data == true) {
                    $rootScope.userUploadedImages[index].selected = true;
                }
                //$rootScope.userUploadedImages[index].selected = true;
                $ionicLoading.hide();
            }, function (error) {
                console.log(error)
                $ionicLoading.hide();
            });

            
        }


    }
});