﻿angular.module('myApp').controller('MySentMessagesCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, $ionicLoading, MyAccountServices) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;


    // $scope.sentMessageList = [
    //    { baslik: 'title', Date:new Date(), isRead: 0 },
    //    { baslik: 'title1', Date:new Date(), isRead: 0 },
    //    { baslik: 'title2', Date:new Date(), isRead: 0 },
    //    { baslik: 'title3', Date:new Date(), isRead: 0 },
    //    { baslik: 'title4', Date:new Date(), isRead: 0 },
    //    { baslik: 'title5', Date:new Date(), isRead: 1 },
    //    { baslik: 'title6', Date:new Date(), isRead: 1 },
    //    { baslik: 'title7', Date:new Date(), isRead: 1 },
    //    { baslik: 'title8', Date:new Date(), isRead: 1 },
    //    { baslik: 'title9', Date:new Date(), isRead: 0 },
    //    { baslik: 'title10', Date:new Date(), isRead: 1 },
    //    { baslik: 'title11', Date:new Date(), isRead: 1 },
    //    { baslik: 'title12', Date:new Date(), isRead: 1 },
    //    { baslik: 'title13', Date:new Date(), isRead: 1 },

    //]
    function getSentMessages() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getSentMessages().then(function (res) {
            $scope.sentMessageList = res;
            $ionicLoading.hide();
        }, function (error) {
            $ionicLoading.hide();
        });
    }
    getSentMessages();

})