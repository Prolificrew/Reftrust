﻿angular.module('myApp').controller('CartConfirmationCtrl', function ($scope, $state, CartService, $translate, $ionicLoading, $ionicHistory, $rootScope, MyAccountServices, paytab, paytabsService, $ionicPopup) {
    $scope.CurrentLanguage = $translate.use();
    $scope.ConfirmationList = [];
    $scope.ConfirmationListLoaded=false;
    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }
    var ipaddress = "";
    var payTabPayPageOptions = {
        merchant_email: paytab.merchant_email,
        secret_key: paytab.secret_key,
        site_url: "https://www.amlik.com",
        return_url: "https://www.amlik.com/api/api/paytabs/PaymentReturn/" + paytab.merchant_email + "/" + paytab.secret_key + "/" + $rootScope.userId,
        msg_lang: $translate.use() == 'en' ? "English" : "Arabic",
        cms_with_version: "API",
    }
    paytabsService.getClientIp().then(function (response) {
        ipaddress = response.ip;
    }, function (error) {
        console, log(error);
    })
    function errorAlert(message) {
        var alertPopup = $ionicPopup.alert({
            title: 'Error!',
            template: "Unable to proceed. Try later...."
        });

        alertPopup.then(function (res) {
        });
    };
    function getConfirmationList() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.getConfirmList().then(function (response) {
            $scope.ConfirmationList = response;
            $scope.ConfirmationListLoaded = true;
            $ionicLoading.hide();
        }, function (error) {
            errorAlert(error);
            $ionicLoading.hide();
        });
    };
    function CreatePayTabPage() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        paytabsService.createPayPage(payTabPayPageOptions).then(function (response) {
            $ionicLoading.hide();
            if (response.response_code == "4012") {
                MyAccountServices.UpdatePayTabStatus(response.p_id, payTabPayPageOptions.reference_no).then(function (response) {
                    console.log(response);
                }, function (error) {
                    console.log(error);
                })
                var options ="location=no,toolbar=no";
                var win = cordova.InAppBrowser.open(response.payment_url, '_blank', options)
                win.addEventListener("loadstart", function (event) { });
                win.addEventListener("loadstop", function (event) {
                    if (event.url.indexOf('www.amlik.com/api/api') >= 0) {
                        win.executeScript({ code: '(function(){return document.body.innerText;})()' }, function (PaymentReference) {
                            var payRef = PaymentReference[0].replace(/['"]+/g, '');
                            win.close();
                            setTimeout(function () {
                                $state.go('tab.purchaseTransactions');
                            }, 1000)
                        });
                    }
                })
            } else {
                errorAlert(response.result);
            }
        }, function (error) {
            errorAlert(error);
            $ionicLoading.hide();
        });
    };
    $scope.Confirm = function () {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        var options = {
            location: 'no',
            clearcache: 'yes',
            toolbar: 'no'
        };
        MyAccountServices.GetPaytabInfo($rootScope.SelectedAddressID, ipaddress).then(function (response) {
            angular.forEach(response, function (value, key) {
                if (key != "$id") {
                    payTabPayPageOptions[key] = value;
                }
            })
            $ionicLoading.hide();
            CreatePayTabPage();
        }, function (error) {
            console.log(error);
            $ionicLoading.hide();
        })
    }
    getConfirmationList();
});