﻿angular.module('myApp').controller('PostAdController', function ($scope, $translate, $rootScope, $state, Search, $cordovaSQLite, $ionicLoading, AuthService) {
    $scope.curlang = $translate.use();
    $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
    $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS MenuTable (id integer, ad_en text, ad_ar text, ads integer, selectedId integer, kat_liste float)");
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    $rootScope.isMainMenuContainer = true;
    $rootScope.isSubMenuContainer = false;
    $rootScope.isCustomBackButton = false;
    //$rootScope.isAuthorizedUser = false;
    //if (AuthService.GetAccessToken()) {
    //    $rootScope.isAuthorizedUser = true;
    //}
    //else {
    //    $rootScope.isAuthorizedUser = false;
    //}

    $rootScope.goBackCategories = function () {
        if ($rootScope.selectedMenusSubMenusId.length == 1) {
            $rootScope.isMainMenuContainer = true;
            $rootScope.isSubMenuContainer = false;
            $rootScope.selectedMenusSubMenusId.length = 0;
            $rootScope.isCustomBackButton = false;
        }
        else {
            var selectedId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
            $rootScope.selectedMenusSubMenusId.splice(-1, 1);
            $scope.select(selectedId, null);
        }
    }

    $scope.clearText = function () {
        $("#categorySearch").val('');
        $scope.searchedData.length = 0;
    }

    $scope.SearchByText = function (category) {
        if (category != "") {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            Search.searchByText(category, $rootScope.language).then(function (res) {
                if (res.data.length > 0) {
                    $scope.searchedData = res.data;
                }
                $ionicLoading.hide();
            }, function (error) {
                console.log(error)
                $ionicLoading.hide();
            });
        }
        else {
            $scope.searchedData.length = 0;
        }

    }




    $scope.getChildMenu = function (id, title_en, kat_liste, title_ar) {
        console.log(id, title_en, kat_liste, title_ar);
        $rootScope.selectedMenusSubMenusId.push(id);
        $rootScope.userUploadedImages = [];
        $rootScope.userLocationLatLng = '';
        $scope.select(id, kat_liste);
    }

    $scope.insert = function (selectedId, menuList) {
        try {
            angular.forEach(menuList, function (value, index) {
                var query = "INSERT INTO MenuTable (id, ad_en, ad_ar, ads, selectedId, kat_liste) VALUES (?,?,?,?,?,?)";
                $cordovaSQLite.execute($rootScope.db, query, [value.id, value.ad_en, value.ad_ar, value.ads, selectedId, value.kat_liste]).then(function (res) {
                    var message = "INSERT ID -> " + res.insertId;
                    console.log(message);

                }, function (err) {
                    console.log(err);
                    //alert(err);
                });
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }

    $scope.getNewCommonSubMainMenu = function (selectedId, title, kat_Id) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        Search.commonMenu(selectedId).then(function (res) {
            try {
                if (res.data.length > 0) {
                    $scope.insert(selectedId, res.data);
                    //submenu
                    //$rootScope.isShownMapButton = false;
                    $scope.select(selectedId, kat_Id);
                    $rootScope.selectedMenusSubMenusId.push(selectedId);
                    //$state.go('tab.issue-detail', { id: selectedId, title: title, kat_liste: kat_Id });
                }
                else {
                    //var parentId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 1];
                    $rootScope.isCustomBackButton = false;
                    $state.go('postDetail', { categoryId: selectedId, kat_Id: kat_Id });
                }
                $ionicLoading.hide();
            }
            catch (e) {
                console.log(e.message);
            }

        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.selectCount = function (selectedId, title, kat_Id) {
        //$rootScope.MenuSelectedId = selectedId;
        try {
            var query = "SELECT id, ad_en, ad_ar, ads, kat_liste FROM MenuTable WHERE selectedId = ?";
            $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {
                if (res.rows.length > 0) {                    //submenu 
                    //$state.go('tab.issue-detail', { id: selectedId, title: title, kat_liste: kat_Id });
                    $rootScope.selectedMenusSubMenusId.push(selectedId);
                    $scope.select(selectedId, kat_Id);
                } else {
                    $scope.getNewCommonSubMainMenu(selectedId, title, kat_Id);
                }
            }, function (err) {
                //alert(err);
                console.log(err);
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }

    $scope.getCommonSubMainMenu = function (selectedId, kat_Id) {
        $scope.results = [];
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        Search.commonMenu(selectedId).then(function (res) {
            //debugger
            try {
                if (res.data.length > 0) {
                    //$scope.results = res.data;                   
                    //$rootScope.locations = res.data;
                    $scope.insert(selectedId, res.data);
                    setTimeout(function () {
                        $scope.select(selectedId, kat_Id);
                    }, 500);
                    $rootScope.isMainMenuContainer = false;
                    $rootScope.isSubMenuContainer = true;
                    $rootScope.isCustomBackButton = true;
                }
                else {
                    var parentId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 1];
                    $rootScope.isCustomBackButton = false;
                    $state.go('postDetail', { categoryId: parentId, kat_Id: kat_Id });
                }
                $ionicLoading.hide();
            }
            catch (e) {
                console.log(e.message);
            }

        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.select = function (selectedId, kat_Id) {
        $rootScope.MenuSelectedId = selectedId;
        try {
            var query = "SELECT id, ad_en, ad_ar, ads, kat_liste FROM MenuTable WHERE selectedId = ?";
            $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {
                $scope.results = [];
                if (res.rows.length > 0) {
                    $rootScope.isMainMenuContainer = false;
                    $rootScope.isSubMenuContainer = true;
                    $rootScope.isCustomBackButton = true;
                    for (var i = 0; i < res.rows.length; i++) {
                        $scope.results.push(res.rows.item(i));
                    }
                } else {
                    $scope.getCommonSubMainMenu(selectedId, kat_Id);
                }
            }, function (err) {
                console.log(err);
            });
        }
        catch (e) {
            console.log(e.message);
        }
    }

    $scope.setTitle = function (id, title, kat_Id) {
        $scope.selectCount(id, title, kat_Id);
    }
})