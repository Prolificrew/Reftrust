﻿angular.module('myApp').directive("compareTo",function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}).controller('ChangePasswordCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, MyAccountServices) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    $scope.ChangePasswordObject = {
        OldPassword: "",
        NewPassword: "",
        confirmNewPassword: ""
    }
    $scope.errorMessage = '';

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }

    
    $scope.ChangePassword = function () {
        $scope.errorMessage = ''
        MyAccountServices.ChangePassword($scope.ChangePasswordObject).then(function (response) {
            console.log(response);
            $scope.isSuccess = true;
            $scope.errorMessage = $translate.instant('PasswordChangeSuccessfullPleaselogin');
            setTimeout(function () {
                $('.Error-messages.success').fadeOut("slow");
                $rootScope.logout();
            }, 3000)

        }, function (error) {
            console.log(error);
            setTimeout(function () {
                $('.Error-messages').fadeOut("slow");
            }, 5000)
            $scope.errorMessage = error.message;
        })
    }

})