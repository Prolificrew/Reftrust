﻿angular.module('myApp').controller('MyMessagesAdsCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }
       

})