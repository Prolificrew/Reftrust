﻿angular.module('myApp').controller('SpecialMeCtrl', function ($scope, $translate, $rootScope, AuthService, $state) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;

    $scope.LogoutUser=function()
    {
        AuthService.logout();
        $rootScope.CartCount = 0;
        $state.go('tab.search', {});
    }

})