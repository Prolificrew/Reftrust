﻿/// <reference path="../../templates/sort.html" />

angular.module('myApp').controller('SearchDataController', function ($scope, $translate, $rootScope, $stateParams, $ionicHistory, StoreService, $ionicLoading, $ionicScrollDelegate, $ionicPopup, $timeout, $ionicModal, $filter, $state, $window, $ionicSideMenuDelegate) {
    $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/adv";
    $rootScope.cateImageUrlList = "https://www.amlik.com/img_post/adv";
    $rootScope.cateGalleryImageUrlList = "https://www.amlik.com/img_post/large"
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isMainBackButtonShow = true;
    $scope.pageNo = "1";
    //$scope.setLocalStorageView = "";
    //$scope.setLocalStorageViewIndex = "";
    //$scope.setLocalStorageSort = "";
    //$scope.setLocalStorageSortIndex = "";
    $scope.isNoRecord = false;
   
    $rootScope.totalRecord = "0";
    $scope.isCurrentPage = true;
    $scope.searchedRecords = [];
    $scope.filterRecords = [];
    $scope.LocationsData = [];
    $scope.locations = [];
    $scope.viewMap = false;
    $scope.data = {
        title: ''
    };
    $scope.refine = {};

    $scope.mainDataContainer = true;
    $scope.mainMapContainer = false;
    $scope.List = false;
    $scope.Gallery = false;
    $scope.DetailedList = false;
    $scope.isShowLocationDetail = false;

    $rootScope.isShownMapButton = true;
    $rootScope.isShownMapsButton = true;
    $(function () {
        $(".masterfab").click(function () {
            if ($(".backdrop").is(":visible")) {
                $(".backdrop").fadeOut(125);
                $(".masterfab").removeClass('active');
                $(".fab.child")
                    .stop()
                    .animate({
                        bottom: $(".masterfab").css("bottom"),
                        opacity: 0
                    }, 125, function () {
                        $(this).hide();
                    });
            } else {
                $(".backdrop").fadeIn(125);
                $(".masterfab").addClass('active');
                $(".fab.child").each(function () {
                    $(this)
                        .stop()
                        .show()
                        .animate({
                            bottom: (parseInt($(".masterfab").css("bottom")) + parseInt($(".masterfab").outerHeight()) + 60 * $(this).data("subitem") - $(".fab.child").outerHeight()) + "px",
                            opacity: 1
                        }, 125);
                });
            }
        });
    });

    $scope.filterData = function () {
        $(".masterfab").trigger('click');
        $scope.openDrawer();
        $(".drawer-background").addClass('active');
        $rootScope.isShownMapButton = false;
        setTimeout(function () {
            $rootScope.isShownOkButton = true;
        }, 50);
    }
    $ionicModal.fromTemplateUrl('popup-ShowSorting.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.ShowSortingPopUp = modal;
    });

    $scope.ShowSorting = function () {
        $(".masterfab").trigger('click');
        $scope.openSortingModal();
    }

    $scope.openSortingModal = function () {
        $scope.ShowSortingPopUp.show();
    };
    $scope.closeSortingModal = function () {
        $scope.ShowSortingPopUp.hide();
    };

    $scope.ShowView = function () {
        $(".masterfab").trigger('click');
        $scope.openModal();
    }

    $rootScope.myGoBack = function () {

        $rootScope.isShownMapButton = false;
        $rootScope.isShownListingButton = false;
        $rootScope.isShownMapsButton = false;
        if ($rootScope.getAllMenuProducts != undefined) {
            var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 1];
            var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
            $rootScope.selectedMenus = last_element;
            $rootScope.selectedMenusId = last_elementId;
            // $rootScope.selectedMenusSubMenus.splice(-1, 1);
            $rootScope.getAllMenuProducts = undefined;
        }
        else {

            var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 2];
            var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
            $rootScope.selectedMenus = last_element;
            $rootScope.selectedMenusId = last_elementId;
            $rootScope.selectedMenusSubMenus.splice(-1, 1);
            //}
        }
        $rootScope.isShownOkButton = false;
        //$rootScope.selectedMenusSubMenus.splice(-1, 1);        
        $rootScope.isLogoShown = false;
        $rootScope.isCountShow = false;
        $ionicHistory.goBack();
    };

    $scope.queryObj = {
        culture: '',
        CategorieID: '',
        SearchText: '',
        page_number: '',
        kategori_url: '',
        order_type: 'DateDesc',
        filterObjData: []
    }
    if (!$rootScope.filterObjData) {
        $rootScope.filterObjData = [];
    }
    

    $scope.filterObj = {
        culture: '',
        CategorieID: '',
        SearchText: '',
        kategori_url: '',
        filterObjData: []
    }

    $scope.locationObj = {
        culture: '',
        CategorieID: '',
        SearchText: '',
        kategori_url: '',
        filterObjData: []
    }
    $scope.isFilterDataLoaded = false;
    $scope.isLocationsDataLoaded = false;

    function loadLocations(categoryId) {

        //$scope.locationObj.culture = $translate.use();
        $scope.locationObj.culture = 'en';
        var newkatId = "";
        if ($stateParams.kat_liste) {
            if ($stateParams.kat_liste.split('.').length > 2) {
                for (var i = 0; i < $stateParams.kat_liste.split('.').length - 2; i++) {
                    newkatId += $stateParams.kat_liste.split('.')[i] + '.'
                }
                $scope.locationObj.CategorieID = newkatId + $stateParams.categoryId + '.';
            } else if ($stateParams.kat_liste.split('.').length == 2) {
                $scope.locationObj.CategorieID = $stateParams.kat_liste;
            }
            else {
                $scope.locationObj.CategorieID = '';
            }
        }
        else {
            $scope.locationObj.CategorieID = '';
        }

        if ($stateParams.url) {
            $scope.locationObj.kategori_url = $stateParams.url;
        }
        else {
            $scope.locationObj.kategori_url = "";
        }

        if ($stateParams.query) {
            $scope.locationObj.SearchText = $stateParams.query;
        }
        else {
            $scope.locationObj.SearchText = "";
        }
        if ($rootScope.filterObjData.length > 0) {
            $scope.locationObj.filterObjData = $rootScope.filterObjData;
        } else {
            $scope.locationObj.filterObjData = [];
        }

        StoreService.getAllLocations($scope.locationObj).then(function (res) {
            $scope.locations = res.data;
            $scope.isLocationsDataLoaded = true;

            if ($scope.isFilterDataLoaded == true && $scope.isLocationsDataLoaded == true) {
                $ionicLoading.hide();
            }

        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    function getFilterData(categoryId) {
        //$scope.filterObj.culture = $translate.use();
        $scope.filterObj.culture = 'en';

        if ($stateParams.url) {
            $scope.filterObj.kategori_url = $stateParams.url;
        }
        else {
            $scope.filterObj.kategori_url = "";
        }
        var newkatId = "";
        if ($stateParams.kat_liste) {
            if ($stateParams.kat_liste.split('.').length > 2) {
                for (var i = 0; i < $stateParams.kat_liste.split('.').length - 2; i++) {
                    newkatId += $stateParams.kat_liste.split('.')[i] + '.'
                }
                $scope.filterObj.CategorieID = newkatId + $stateParams.categoryId + '.';
            } else if ($stateParams.kat_liste.split('.').length == 2) {
                $scope.filterObj.CategorieID = $stateParams.kat_liste;
            }
            else {
                $scope.filterObj.CategorieID = '';
            }
        }
        else {
            $scope.filterObj.CategorieID = '';
        }
        if ($rootScope.filterObjData.length > 0) {
            $scope.filterObj.filterObjData = $rootScope.filterObjData;
        } else {
            $scope.filterObj.filterObjData = [];
        }
        StoreService.getFilterDetail($scope.filterObj).then(function (res) {
            $scope.filterRecords = res.data;

            setTimeout(function () {
                if ($rootScope.filterObjData.length > 0) {
                    for (var i = 0; i < $scope.filterRecords.locationmodel.length; i++) {
                        for (var j = 0; j < $rootScope.filterObjData.length; j++) {
                            if ($scope.filterRecords.locationmodel[i].id == $rootScope.filterObjData[j].id && $rootScope.filterObjData[j].Type==0) {
                                $scope.SetSelectedLocation($scope.filterRecords.locationmodel[i], $scope.filterRecords.locationmodel[i].id);
                            }
                        }
                    }
                    for (var i = 0; i < $scope.filterRecords.refinemodel.length; i++) {
                        for (var j = 0; j < $rootScope.filterObjData.length; j++) {
                            if ($scope.filterRecords.refinemodel[i].id == $rootScope.filterObjData[j].id) {
                                if ($scope.filterRecords.refinemodel[i].refineTabDetailmodelList.length > 0) {
                                    for (var k = 0; k < $scope.filterRecords.refinemodel[i].refineTabDetailmodelList.length; k++) {
                                        if ($scope.filterRecords.refinemodel[i].refineTabDetailmodelList[k].id == $rootScope.filterObjData[j].value) {
                                            $scope.SetSelectedRefineTabs($scope.filterRecords.refinemodel[i].refineTabDetailmodelList[k].id);
                                        }
                                    }
                                }

                            }
                        }
                    }

                }
            }, 500)
            $scope.isFilterDataLoaded = true;
            if ($scope.isFilterDataLoaded == true && $scope.isLocationsDataLoaded == true) {
                $ionicLoading.hide();
            }
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.SetSelectedLocation = function (location, radioindex) {
        $('.checkbox').find("input[name=filterlocation" + radioindex + "]").prop('checked', true);
        //console.log($rootScope.filterObjData);
        //FilterSeacrhData();
    }

    $scope.SetSelectedRefineTabs = function (radioindex) {
        $('.checkbox').find("input[name=refineYesNo" + radioindex + "]").prop('checked', true);
        //FilterSeacrhData();
    }

    $scope.noMoreDataAvailable = false;
    //debugger
    $scope.loadMoreData = function () {
        if ($scope.searchedRecords.length == 0) {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
        }
        $rootScope.isShownMapButton = true;
        $scope.queryObj.page_number = $scope.pageNo;
        //$scope.queryObj.culture = $translate.use();
        $scope.queryObj.culture = 'en';
        $scope.queryObj.SearchText = $stateParams.query;
        if ($stateParams.url) {
            $scope.queryObj.kategori_url = $stateParams.url;
        }
        else {
            $scope.queryObj.kategori_url = "";
        }

        var newkatId = ''
        if ($stateParams.kat_liste) {
            if ($stateParams.kat_liste.split('.').length > 2) {
                for (var i = 0; i < $stateParams.kat_liste.split('.').length - 2; i++) {
                    newkatId += $stateParams.kat_liste.split('.')[i] + '.'
                }
                $scope.queryObj.CategorieID = newkatId + $stateParams.categoryId + '.';
            } else if ($stateParams.kat_liste.split('.').length == 2) {
                $scope.queryObj.CategorieID = $stateParams.kat_liste;
            }
            else {
                $scope.queryObj.CategorieID = '';
            }
        }
        else {
            $scope.queryObj.CategorieID = '';
        }

        if ($rootScope.filterObjData.length > 0) {
            $scope.queryObj.filterObjData = $rootScope.filterObjData;
        } else {
            $scope.queryObj.filterObjData = [];
        }
        $scope.filterObj.SearchText = $stateParams.query;
        if ($scope.filterRecords.length == 0) {
            getFilterData();
        }

        $scope.locationObj.SearchText = $stateParams.query;
        if (!$stateParams.url) {
            if ($scope.locations.length == 0) {
                loadLocations();
            }
        }
        StoreService.getSearched($scope.queryObj).then(function (res) {
            $rootScope.isCountShow = true;

            if (res.data.length > 0) {
                $rootScope.totalRecord = res.data[0].total;
                $scope.searchedRecords.push.apply($scope.searchedRecords, res.data);
                if ($stateParams.url) {
                    if ($scope.locations.length == 0) {
                        $stateParams.kat_liste = $scope.searchedRecords[0].kat_liste;
                        $stateParams.categoryId = $scope.searchedRecords[0].kat_liste.split('.')[$scope.searchedRecords[0].kat_liste.split('.').length - 2]
                        loadLocations($scope.searchedRecords[0].kat_liste);
                    }
                }
            }
            else {
                $scope.noMoreDataAvailable = true;
            }
            if ($scope.searchedRecords.length == 0) {
                $scope.isNoRecord == true;
            }
            $scope.pageNo++;
            if ($scope.isFilterDataLoaded == true && $scope.isLocationsDataLoaded == true) {
                $ionicLoading.hide();
            }
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
        // }
        $rootScope.isShownMapListingButton = true;


    };

    function GetSortedData() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        StoreService.getSearched($scope.queryObj).then(function (res) {
            $rootScope.isCountShow = true;

            if ($scope.filterRecords.length == 0) {
                getFilterData($stateParams.kat_liste);
            }

            if (res.data.length > 0) {
                //$rootScope.locations = res.data;
                $rootScope.totalRecord = res.data[0].total;
                $scope.searchedRecords = res.data;
            }
            else {
                $scope.noMoreDataAvailable = true;
            }

            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
        $rootScope.isShownMapListingButton = true;
    }

    $scope.orderDate = function (predicate, radio) {

        //$scope.setLocalStorageSort = "Date";
        //$scope.setLocalStorageSortIndex = radio;

        $ionicScrollDelegate.$getByHandle('small').scrollTop();
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        if (predicate == '1') {
            //$scope.searchedRecords = $filter('orderBy')($scope.searchedRecords, 'duzenle_tarih');

            $scope.queryObj.culture = $translate.use();
            $scope.queryObj.SearchText = $stateParams.query;
            $scope.queryObj.CategorieID = $stateParams.categoryId;
            $scope.queryObj.order_type = 'DateDesc';
            $scope.queryObj.page_number = '1';
            GetSortedData();

        } else {
            //$scope.searchedRecords = $filter('orderBy')($scope.searchedRecords, '-duzenle_tarih');
            $scope.queryObj.culture = $translate.use();
            $scope.queryObj.SearchText = $stateParams.query;
            $scope.queryObj.CategorieID = $stateParams.categoryId;
            $scope.queryObj.order_type = 'DateAsc';
            $scope.queryObj.page_number = '1';
            GetSortedData();
        }
        $scope.closeSortingModal();
    };

    $scope.orderPrice = function (order, radio) {

        //$scope.setLocalStorageSort = "Price";
        //$scope.setLocalStorageSortIndex = radio;

        $ionicScrollDelegate.$getByHandle('small').scrollTop();
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        if (order == '1') {
            //$scope.searchedRecords = $filter('orderBy')($scope.searchedRecords, 'fiyat');
            $scope.queryObj.culture = $translate.use();
            $scope.queryObj.SearchText = $stateParams.query;
            $scope.queryObj.CategorieID = $stateParams.categoryId;
            $scope.queryObj.order_type = 'PriceAsc';
            $scope.queryObj.page_number = '1';
            GetSortedData();
        } else {
            //$scope.searchedRecords = $filter('orderBy')($scope.searchedRecords, '-fiyat');
            $scope.queryObj.culture = $translate.use();
            $scope.queryObj.SearchText = $stateParams.query;
            $scope.queryObj.CategorieID = $stateParams.categoryId;
            $scope.queryObj.order_type = 'PriceDesc';
            $scope.queryObj.page_number = '1';
            GetSortedData();
        }
        $scope.closeSortingModal();
    }

    $rootScope.ShowMapLocation = function (radio) {
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        $scope.closeModal();
        $('.flipper').toggleClass('flipped');
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = false;
            $rootScope.isShownListingButton = true;
            $scope.mainMapContainer = true;
        }
        else {
            $scope.mainMapContainer = false;
            $rootScope.isShownListingButton = false;
            $rootScope.isShownMapsButton = true;
            $scope.isShowLocationDetail = false;
        }

        //var lat = 24.266906;
        //var long = 45.1078489;
        //var latlng = new google.maps.LatLng(lat, long);

        //var map = new google.maps.Map(document.getElementById('mapSearchData'),
        //    {
        //        zoom: 10,
        //        center: latlng,
        //        mapTypeControl: false,
        //        streetViewControl: false,
        //        panControl: false,
        //        mapTypeControlOptions: { mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style'] },

        //    });
        //var infowindow = new google.maps.InfoWindow({
        //    content: 'Saudi Arabia'
        //});

        //var markers = new Array();

        //var iconCounter = 0;
        //for (var i = 0; i < $scope.locations.length; i++) {
        //    if ($scope.locations[i].harita != '') {
        //        var marker = new google.maps.Marker
        //        ({
        //            position: new google.maps.LatLng($scope.locations[i].harita.split(",")[0], $scope.locations[i].harita.split(",")[1]),
        //            map: map,
        //        });
        //        markers.push(marker);
        //        google.maps.event.addListener(marker, 'click', (function (marker, i) {
        //            return function () {
        //                $scope.maplocationdataSource = [];
        //                $scope.isShowLocationDetail = true;
        //                $scope.maplocationdataSource = $scope.locations[i];
        //                $scope.$apply();
        //                //infowindow.setContent($scope.locations[i].baslik);
        //                //infowindow.open(map, marker);
        //            }
        //        })
        //    (marker, i)
        //    );
        //    }

        //}
        //marker = new google.maps.Marker({
        //    position: latlng,
        //    map: map
        //});
        ////infowindow.open(map, marker);
        var mapOptions = {
            zoom: 8,
            center: new google.maps.LatLng(24.266906, 45.1078489),
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }

        $scope.map = new google.maps.Map(document.getElementById('mapSearchData'), mapOptions);

        $scope.markers = [];

        var infoWindow = new google.maps.InfoWindow();

        if ($scope.locations.length > 0) {
            for (i = 0; i < $scope.locations.length; i++) {
                if ($scope.locations[i].harita != '') {
                    var marker = new google.maps.Marker
                    ({
                        position: new google.maps.LatLng($scope.locations[i].harita.split(",")[0], $scope.locations[i].harita.split(",")[1]),
                        map: $scope.map,
                    });
                    $scope.markers.push(marker);
                    google.maps.event.addListener(marker, 'click', (function (marker, i) {
                        return function () {
                            $scope.maplocationdataSource = [];
                            $scope.isShowLocationDetail = true;
                            $scope.maplocationdataSource = $scope.locations[i];
                            $scope.$apply();
                            //infowindow.setContent($scope.locations[i].baslik);
                            //infowindow.open(map, marker);
                        }
                    })
                (marker, i)
                );
                }
            }
        }
    }

    $scope.$on('eventCloseFilterDrawer', function (event, args) {
        $rootScope.closeFilterDrawer();
        $rootScope.$apply();
    });

    $scope.$on('eventOpenFilterDrawer', function (event, args) {
        //$(".masterfab").trigger('click');
        $scope.openDrawer();
        $(".drawer-background").addClass('active');
        setTimeout(function () {
            $rootScope.isShownOkButton = true;
        }, 50);
        $rootScope.isShownMapButton = false;
        $rootScope.$apply();
    });

    $rootScope.ClickOnOkButton = function () {
        $scope.closeDrawer();
        $(".drawer-background").removeClass('active');
        $rootScope.isShownOkButton = false;
        $rootScope.isShownMapButton = true;
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = true;
            $rootScope.isShownListingButton = false;

        }
        else {
            $rootScope.isShownListingButton = true;
            $rootScope.isShownMapsButton = false;
        }
        //if ($rootScope.filterObjData.length > 0) {
        FilterSeacrhData();
        //}
    }

    $rootScope.closeFilterDrawer = function () {
        $scope.closeDrawer();
        $(".drawer-background").removeClass('active');
        $rootScope.isShownOkButton = false;
        $rootScope.isShownMapButton = true;
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = true;
            $rootScope.isShownListingButton = false;

        }
        else {
            $rootScope.isShownListingButton = true;
            $rootScope.isShownMapsButton = false;
        }
        //FilterSeacrhData();
    }

    $ionicModal.fromTemplateUrl('popup-SaveAndSearchPopup.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.ShowSaveAndSearchPopup = modal;
    });


    $scope.openSaveAndSearchPopupModal = function () {
        $scope.ShowSaveAndSearchPopup.show();
    };
    $scope.closeSaveAndSearchPopupModal = function () {
        $scope.ShowSaveAndSearchPopup.hide();
    };

    $scope.SaveAndSearchPopup = function () {
        $(".masterfab").trigger('click');
        $scope.openSaveAndSearchPopupModal();
    };



    $ionicModal.fromTemplateUrl('popup-ShowView.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });
    $scope.openModal = function () {
        $scope.modal.show();
    };
    $scope.closeModal = function () {
        $scope.modal.hide();
    };
    //Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hidden', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });

    $scope.saveTitle = function (text) {
        if (text) {
            var localStorageValues = [];
            localStorageValues = localStorage.getItem('savedSearchedRecord') == null ? [] : JSON.parse(localStorage.getItem('savedSearchedRecord'));
            localStorageValues.push({ saveSearchTitle: text, query: $scope.queryObj })
            localStorage.setItem('savedSearchedRecord', JSON.stringify(localStorageValues));
            $scope.ShowSaveAndSearchPopup.hide();
        }
        else {

        }
        
    }
    
    $scope.ShowList = function (radio) {
        //$scope.setLocalStorageView = "List";
        //$scope.setLocalStorageViewIndex = "6";
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        $scope.closeModal();
        $scope.mainDataContainer = false;
        $scope.Gallery = false;
        $scope.DetailedList = false;

        if ($scope.isShownMapsButton == false) {
            $('.flipper').toggleClass('flipped');
            $scope.mainMapContainer = false;
        }
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = true;
            $rootScope.isShownListingButton = false;

        }
        else {
            if ($rootScope.isShownMapButton == true) {
                $rootScope.isShownMapButton = true;
                $rootScope.isShownListingButton = false;
            } else {
                $rootScope.isShownMapButton = false;
                $rootScope.isShownListingButton = true;
            }
            $rootScope.isShownMapsButton = true;
        }

        $scope.mainMapContainer = false;
        $scope.List = true;
    }

    $scope.ShowDetailedList = function (radio) {
        //$scope.setLocalStorageView = "DetailedList";
        //$scope.setLocalStorageViewIndex = "7";
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        $scope.closeModal();
        $scope.mainDataContainer = false;
        $scope.Gallery = false;
        $scope.List = false;
        if ($scope.isShownMapsButton == false) {
            $('.flipper').toggleClass('flipped');
            $scope.mainMapContainer = false;
        }
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = true;
            $rootScope.isShownListingButton = false;

        }
        else {
            if ($rootScope.isShownMapButton == true) {
                $rootScope.isShownMapButton = true;
                $rootScope.isShownListingButton = false;
            } else {
                $rootScope.isShownMapButton = false;
                $rootScope.isShownListingButton = true;
            }
            $rootScope.isShownMapsButton = true;
        }
        $scope.DetailedList = true;
    }
    $scope.ShowGrid = function (radio) {
        //$scope.setLocalStorageView = "Grid";
        //$scope.setLocalStorageViewIndex = "8";
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        $scope.closeModal();
        $scope.List = false;
        $scope.DetailedList = false;
        $scope.Gallery = false;
        if ($scope.isShownMapsButton == false) {
            $('.flipper').toggleClass('flipped');
            $scope.mainMapContainer = false;
        }
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = true;
            $rootScope.isShownListingButton = false;

        }
        else {
            if ($rootScope.isShownMapButton == true) {
                $rootScope.isShownMapButton = true;
                $rootScope.isShownListingButton = false;
            } else {
                $rootScope.isShownMapButton = false;
                $rootScope.isShownListingButton = true;
            }
            $rootScope.isShownMapsButton = true;
        }
        $scope.mainDataContainer = true;
    }

    $scope.ShowGallery = function (radio) {

        //$scope.setLocalStorageView = "Gallery";
        //$scope.setLocalStorageViewIndex = "9";

        $("#Radio" + radio).find('input:radio').prop('checked', true);
        $scope.closeModal();
        $scope.mainDataContainer = false;
        $scope.List = false;
        $scope.DetailedList = false;
        if ($scope.isShownMapsButton == false) {
            $('.flipper').toggleClass('flipped');
            $scope.mainMapContainer = false;
        }
        if ($rootScope.isShownMapsButton == true) {
            $rootScope.isShownMapsButton = true;
            $rootScope.isShownListingButton = false;

        }
        else {
            if ($rootScope.isShownMapButton == true) {
                $rootScope.isShownMapButton = true;
                $rootScope.isShownListingButton = false;
            } else {
                $rootScope.isShownMapButton = false;
                $rootScope.isShownListingButton = true;
            }
            $rootScope.isShownMapsButton = true;
        }
        $scope.Gallery = true;
    }

    $scope.getProductDetail = function (url, logo, ilan_resim, ilan_no) {
        //product-detail({ url:'null',ilan_resim:record.ilan_resim,logo:'null',id:record.ilan_no})
        $state.go('product-detail', { url: url, logo: logo, ilan_resim: ilan_resim, id: ilan_no });

    }

    $scope.getCategoryFiltered = function (category) {
        $scope.queryObj.CategorieID = category.kat_liste;
        $scope.queryObj.page_number = '1';
        $stateParams.kat_liste = category.kat_liste;
        $stateParams.categoryId = category.id;
        FilterSeacrhData();
        $rootScope.closeFilterDrawer();
    }

    $scope.toggleGroup = function (group) {
        $scope.errorMessage.id = '';
        if ($scope.isGroupShown(group)) {
            $scope.shownGroup = null;
        } else {
            $scope.shownGroup = group;
        }
    };
    $scope.isGroupShown = function (group) {
        return $scope.shownGroup === group;
    };

    $scope.filterPrice = function (PriceMin, PriceMax, price) {
        var index = $rootScope.filterObjData.map(function (elem) { return elem.id }).indexOf(price);
        if (index >= 0) {
            $rootScope.filterObjData.splice(index, 1);
            FilterSeacrhData()
        }
        else {
            if (!PriceMin && !PriceMax) {
                $scope.errorMessage.id = price;
                $scope.errorMessage.error = $translate.instant('PleaseinputMinorMax');
            }
            else {
                if (PriceMin == "") {
                    PriceMin = '0';
                }
                if (PriceMax == "") {
                    PriceMax = '0';
                }

                if (parseInt(PriceMax) >= parseInt(PriceMin)) {
                    var index = $rootScope.filterObjData.map(function (elem) { return elem.id }).indexOf(price);
                    if (index >= 0) {
                        if (PriceMin == "0" && PriceMax == "0") {
                            $rootScope.filterObjData.splice(index, 1);
                            $rootScope.filterObjData.push({ Min: "", id: price, Max: "", value: '', Type: 2 });
                        }
                        else if (PriceMax == "0") {
                            $rootScope.filterObjData.splice(index, 1);
                            $rootScope.filterObjData.push({ Min: PriceMin, id: price, Max: "", value: '', Type: 2 });
                        }
                        else if (PriceMin == "0") {
                            $rootScope.filterObjData.splice(index, 1);
                            $rootScope.filterObjData.push({ Min: "", id: price, Max: PriceMax, value: '', Type: 2 });
                        }
                        else {
                            $rootScope.filterObjData.splice(index, 1);
                            $rootScope.filterObjData.push({ Min: PriceMin, id: price, Max: PriceMax, value: '', Type: 2 });
                        }
                    }
                    else {
                        if (PriceMin == "0" && PriceMax == "0") {
                            $rootScope.filterObjData.push({ Min: "", id: price, Max: "", value: '', Type: 2 });
                        }
                        else if (PriceMax == "0") {
                            $rootScope.filterObjData.push({ Min: PriceMin, id: price, Max: "", value: '', Type: 2 });
                        }
                        else if (PriceMin == "0") {
                            $rootScope.filterObjData.push({ Min: "", id: price, Max: PriceMax, value: '', Type: 2 });
                        }
                        else {
                            $rootScope.filterObjData.push({ Min: PriceMin, id: price, Max: PriceMax, value: '', Type: 2 });
                        }
                    }
                    //FilterSeacrhData();
                    $scope.toggleGroup('Price');
                }
                else {
                    $scope.errorMessage.id = price;
                    $scope.errorMessage.error = $translate.instant('MinMaxValueError');
                }
            }
        }
        console.log($rootScope.filterObjData);
    }

    $scope.errorMessage = { id: '', error: '' };
    $scope.filterGo = function (refineObj) {
        var inputMin = document.getElementById("InputMin" + refineObj.id).value;
        var inputMax = document.getElementById("InputMax" + refineObj.id).value;
        if (inputMin == "" && inputMax == "") {
            $scope.errorMessage.id = refineObj.id;
            $scope.errorMessage.error = $translate.instant('PleaseinputMinorMax');
        }
        else {
            $scope.errorMessage.id = '';
            if (inputMin == "") {
                inputMin = '0';
            }
            if (inputMax == "") {
                inputMax = '0';
            }
            if (parseInt(inputMax) >= parseInt(inputMin)) {
                var index = $rootScope.filterObjData.map(function (elem) { return elem.id }).indexOf(refineObj.id);
                if (index >= 0) {
                    if (inputMin == "0" && inputMax == "0") {
                        $rootScope.filterObjData.splice(index, 1);
                        $rootScope.filterObjData.push({ Min: "", id: refineObj.id, Max: "", value: '', Type: 1 });
                    }
                    else if (inputMax == "0") {
                        $rootScope.filterObjData.splice(index, 1);
                        $rootScope.filterObjData.push({ Min: inputMin, id: refineObj.id, Max: "", value: '', Type: 1 });
                    }
                    else if (inputMin == "0") {
                        $rootScope.filterObjData.splice(index, 1);
                        $rootScope.filterObjData.push({ Min: "", id: refineObj.id, Max: inputMax, value: '', Type: 1 });
                    }
                    else {
                        $rootScope.filterObjData.splice(index, 1);
                        $rootScope.filterObjData.push({ Min: inputMin, id: refineObj.id, Max: inputMax, value: '', Type: 1 });
                    }
                } else {
                    if (inputMin == "0" && inputMax == "0") {
                        $rootScope.filterObjData.push({ Min: "", id: refineObj.id, Max: "", value: '', Type: 1 });
                    }
                    else if (inputMax == "0") {
                        $rootScope.filterObjData.push({ Min: inputMin, id: refineObj.id, Max: "", value: '', Type: 1 });
                    }
                    else if (inputMin == "0") {
                        $rootScope.filterObjData.push({ Min: "", id: refineObj.id, Max: inputMax, value: '', Type: 1 });
                    }
                    else {
                        $rootScope.filterObjData.push({ Min: inputMin, id: refineObj.id, Max: inputMax, value: '', Type: 1 });
                    }
                }
                console.log($rootScope.filterObjData);
                $scope.errorMessage.id = '';
                // FilterSeacrhData()
                $scope.toggleGroup(refineObj);
            }
            else {
                $scope.errorMessage.id = refineObj.id;
                $scope.errorMessage.error = $translate.instant('MinMaxValueError');
            }
        }
    }

    //var selectedLoactionList = [];
    $scope.SelectLocation = function (location, radioindex) {

        var index = $rootScope.filterObjData.map(function (elem) { return elem.id + elem.value + elem.Type }).indexOf(location.id + location.ad_en + 0);
        if (index >= 0) {
            $('.checkbox').find("input[name=filterlocation" + radioindex + "]").prop('checked', false)
            $rootScope.filterObjData.splice(index, 1);
        } else {
            $('.checkbox').find("input[name=filterlocation" + radioindex + "]").prop('checked', true)
            $rootScope.filterObjData.push({ Min: "", id: location.id, Max: "", value: location.ad_en, Type: 0 });
        }
        console.log($rootScope.filterObjData);
        //FilterSeacrhData();
    }


    $scope.SelectRefineProperties = function (location, radioindex, parentElement) {
        var index = $rootScope.filterObjData.map(function (elem) { return elem.id + elem.value + elem.Type }).indexOf(parentElement.id + location.id + 1);
        if (index >= 0) {
            $('.checkbox').find("input[name=refineYesNo" + radioindex + "]").prop('checked', false)
            $rootScope.filterObjData.splice(index, 1);
        } else {
            $('.checkbox').find("input[name=refineYesNo" + radioindex + "]").prop('checked', true)
            $rootScope.filterObjData.push({ Min: "", id: parentElement.id, Max: "", value: location.id, Type: 1 });
        }
        console.log($rootScope.filterObjData);
        //FilterSeacrhData();
    }


    function FilterSeacrhData() {
        $scope.isFilterDataLoaded = false;
        $scope.isLocationsDataLoaded = false;
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        $scope.queryObj.filterObjData = $rootScope.filterObjData;

        $scope.filterObj.SearchText = $stateParams.query;
        getFilterData();
        loadLocations();
        StoreService.getSearched($scope.queryObj).then(function (res) {
            $rootScope.isCountShow = true;
            if (res.data.length > 0) {
                $rootScope.totalRecord = res.data[0].total;
                $scope.searchedRecords = res.data;
                if ($scope.isFilterDataLoaded == true && $scope.isLocationsDataLoaded == true) {
                    $ionicLoading.hide();
                }
                $scope.pageNo++;
            }
            else {
                $scope.noMoreDataAvailable = true;
            }


            if ($scope.searchedRecords.length == 0) {
                $scope.isNoRecord == true;
            }
            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
        $rootScope.isShownMapListingButton = true;
    }


});