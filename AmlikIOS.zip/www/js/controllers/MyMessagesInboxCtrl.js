﻿angular.module('myApp').controller('MyMessagesInboxCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, $ionicLoading, MyAccountServices) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    
    function loadInboxMessages()
    {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getInboxMessages().then(function (res) {
            $scope.inboxMessageList = res;
            $ionicLoading.hide();
        }, function (error) {
            $ionicLoading.hide();
        });
    }
    loadInboxMessages();
})