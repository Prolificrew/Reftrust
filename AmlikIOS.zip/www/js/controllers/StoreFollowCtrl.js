﻿angular.module('myApp').controller('StorefollowCtrl', function ($scope, $translate, $rootScope, $stateParams, $ionicHistory, StoreService, $ionicLoading, $timeout, $ionicSlideBoxDelegate, $ionicModal, $ionicActionSheet, $ionicScrollDelegate) {

    $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/adv";
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $scope.StoreDetail = [];
    $scope.storeData = [];
    //$scope.StoreIamgeURL = "https://www.amlik.com/img_post/xl/";   
    $scope.pageNo = "1";
   
    $scope.noMoreFollowAvailable = false;
  
    $scope.loadFollowMore = function () {
        StoreService.getStoreList($stateParams.url, $scope.pageNo).then(function (res) {
            if (res.data.length > 0) {
                $scope.storeData.push.apply($scope.storeData, res.data);
                $scope.pageNo++;
            }
            else {
                $scope.noMoreItemsAvailable = true;
            }

            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });


    };

})