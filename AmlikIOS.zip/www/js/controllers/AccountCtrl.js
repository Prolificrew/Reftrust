﻿angular.module('myApp').controller('AccountCtrl', function ($scope, $translate, $rootScope, $state) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = true;
    $rootScope.isShownMapButton = false;
    $scope.changeLanguage = function (key) {
        $rootScope.language = key;
        localStorage.setItem('UserLanguage', key);
        $translate.use(key);
        $scope.curlang = key;
    };

    $rootScope.selectedMenusSubMenus=[];
    $rootScope.selectedMenusSubMenusId=[];

    if (localStorage.getItem('savedSearchedRecord')) {
        $rootScope.savedSearchedRecord =JSON.parse(localStorage.getItem('savedSearchedRecord'));
    }

    $scope.getSavedSearchedData=function(data)
    {
        $rootScope.filterObjData = data.query.filterObjData;
        //$rootScope.$apply();
        if (data.query.CategorieID.split('.').length > 2) {
            $state.go('tab.search-data', { query: data.query.SearchText, categoryId: data.query.CategorieID.split('.')[data.query.CategorieID.split('.').length - 2], kat_liste: data.query.CategorieID });
        }
        else {
            $state.go('tab.search-data', { query: data.query.SearchText, categoryId: '', kat_liste: data.query.CategorieID });
        }
    }


})