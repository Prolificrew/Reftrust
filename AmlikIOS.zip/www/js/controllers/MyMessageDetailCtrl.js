﻿angular.module('myApp').controller('MyMessageDetailCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, $ionicLoading, MyAccountServices, $ionicScrollDelegate, $timeout, $stateParams) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    $scope.SenderId = $stateParams.senderId;
    $scope.RecipientUserId = $stateParams.recipientUserId;
    $scope.AdId = $stateParams.adId;
    $scope.productImageUrl = "https://www.amlik.com/img_post/thumb/";
    $scope.messages = { baslik: '', id: 0 };
    $scope.isResponse = false;
    $scope.data = {
        "baslik": $scope.messages.baslik,
        "konu": "",
        "tarih": "",
        "okundu": 0,
        "gonderen_id": $scope.SenderId,
        "alici_id": $scope.RecipientUserId,
        "ilan_id": $scope.AdId,
    };
    $scope.sendMessage = function () {
        $scope.data.baslik = $scope.messages.baslik;
        $scope.data.tarih = new Date();
        $scope.data.gonderen_id = $scope.SenderId;
        $scope.data.alici_id = $scope.RecipientUserId;
        $scope.data.ilan_id = $scope.AdId;
        MyAccountServices.SendMessage(angular.copy($scope.data)).then(function (response) {
            if (response) {
                $scope.messages.productMessages.push(response);
                $ionicScrollDelegate.scrollBottom(true);
            }
        }, function (error) {
            console.log(error);
        })
        delete $scope.data.konu;
       

    };


    $scope.inputUp = function () {
        if (isIOS) $scope.data.keyboardHeight = 216;
        $timeout(function () {
            $ionicScrollDelegate.scrollBottom(true);
        }, 300);

    };

    $scope.inputDown = function () {
        if (isIOS) $scope.data.keyboardHeight = 0;
        $ionicScrollDelegate.resize();
    };

    $scope.closeKeyboard = function () {
        // cordova.plugins.Keyboard.close();
    };


    $scope.data = {};
    function getMessagesDetail() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getMessagesDetail($scope.SenderId, $scope.RecipientUserId, $scope.AdId).then(function (res) {
            if (res) {
                $scope.myId = res.user_id;
                $scope.messages = res;
                $ionicScrollDelegate.scrollBottom(true);
            }

            $ionicLoading.hide();
        }, function (error) {
            $ionicLoading.hide();
        });
    }
    getMessagesDetail();
})