﻿angular.module('myApp').controller('PublishedAdsCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, MyAccountServices, $ionicLoading) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    $scope.PublishedAdsURL = 'https://www.amlik.com/img_post/thumb/';
    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }
    $scope.pubAdsPageNo = "1";
    $scope.PublishedAds = [];
    $scope.isResponse = false;
    $scope.noMorePubAdsAvailable = false;
    $scope.loadPubAds = function () {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getPublishedAds($scope.pubAdsPageNo).then(function (res) {
            if (res.length > 0) {
                $scope.PublishedAds.push.apply($scope.PublishedAds, res);
                $scope.pubAdsPageNo++;
                $ionicLoading.hide();
                $scope.isResponse = false;
            }
            else {
                $scope.noMorePubAdsAvailable = true;
                $ionicLoading.hide();

            }
            if ($scope.PublishedAds.length == 0) {
                $scope.isResponse = true;
            }

        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.editPublishedAds = function (ad)
    {
        $state.go("postDetail", { categoryId: ad.kat_liste.split('.')[ad.kat_liste.split('.').length - 2], kat_Id: ad.kat_liste, adID: ad.ilan_no });
    }

    //LoadPublishedAds();
})