﻿angular.module('myApp').controller('MyFavoriteAdsCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, $ionicLoading, MyAccountServices) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;

    $scope.favoriteAdsUrl = 'https://www.amlik.com/img_post/thumb/';

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }

    function LoadFavoriteAds() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getFavoriteAds().then(function (res) {
            $scope.favoriteAds = res;
            $ionicLoading.hide();
        }, function (error) {
            $ionicLoading.hide();
        });
    }


    LoadFavoriteAds();

})