﻿angular.module('myApp').controller('SearchCtrl', ['$scope', '$translate', '$rootScope', '$stateParams', 'Search', '$state', '$location', '$ionicLoading', '$ionicHistory', 'AuthService', 'CartService'
            , function ($scope, $translate, $rootScope, $stateParams, Search, $state, $location, $ionicLoading, $ionicHistory, AuthService, CartService) {
                $rootScope.language = $translate.use();
                $("#toast-container").removeClass('toast-top-right');
                $rootScope.selectedMenusSubMenus = [];
                $rootScope.selectedMenusSubMenusId = [];
                $rootScope.isLogoShown = true;
                $scope.isSearchedRecord = true;
                $scope.query = '';
                $rootScope.userUploadedImages = [];
                $rootScope.userLocationLatLng = '';
                $rootScope.isShownMapButton = false;
                $rootScope.CartCount = 0;
                //debugger
                $scope.doSearch = function (query) {
                    //debugger
                    $rootScope.isLogoShown = false;
                    if (query != "") {
                        $state.go('tab.search-data', { query: query, categoryId: '' });
                    }
                };
                              

                $scope.getProducts = function (record) {
                    if (record.type == 'Categorydata') {
                        $state.go('tab.search-url', { url: record.url });
                    }
                    if (record.type == 'Ads') {
                        $state.go('product-detail', { url: null, ilan_resim: null, logo: null, id: record.ilan_no });
                    }
                    if (record.type == 'Stores') {
                        $state.go('tab.store-detail', { url: record.url, ilan_resim: null, logo: null, id: record.ilan_no });
                    }
                    if (record.type == 'SearcQuarry') {
                        $scope.doSearch($("#txtSearchBar").val());
                    }

                }

                $scope.pageNo = "1";
                $scope.searchingData = function (query) {
                    if (query.length > 2) {
                        $ionicLoading.show({
                            content: 'Loading...',
                            animation: 'fade-in',
                            showBackdrop: true,
                            maxWidth: 200,
                            showDelay: 0
                        });
                        $scope.isSearchedRecord = false;
                        $rootScope.isLogoShown = false;
                        Search.getSearch(query, $rootScope.language).then(function (res) {
                            if (res.data.data.length > 0) {
                                $scope.results = res.data.data;
                                $scope.list = [];
                                var lastChar = '';
                                for (var i = 0, len = $scope.results.length; i < len; i++) {
                                    var item = $scope.results[i];

                                    if (item.type != lastChar) {
                                        $scope.list.push({ n: item.type, letter: true });
                                        lastChar = item.type;
                                    }
                                    $scope.list.push(item);

                                }


                            }

                            $ionicLoading.hide();
                        }, function (error) {
                            console.log(error)
                            $ionicLoading.hide();
                        });


                        //$state.go('tab.search-data', { query: query });
                    }
                    else {
                        $scope.isSearchedRecord = true;
                        $rootScope.isLogoShown = true;
                    }
                }

                $rootScope.showHideLogoImage = function (url, isShown) {
                    $rootScope.isCountShow = false;
                    $rootScope.selectedMenusSubMenus = [];
                    $rootScope.selectedMenusSubMenusId = [];
                    $rootScope.isLogoShown = isShown;
                    $rootScope.isShownMapsButton = false;
                    $rootScope.isShownListingButton = false;
                    $scope.noMoreItemsAvailable = false;

                    if (url == 'postAdupload') {
                        $rootScope.ClosePostAd = true;
                        $rootScope.MainMenuCategories = true;
                        $rootScope.isMainMenuContainer = true;
                        $rootScope.isSubMenuContainer = false;
                        $rootScope.isCustomBackButton = false;
                    }

                    $state.go(url, {});
                }

                $scope.setHeaderText = function (title_en, title_ar) {
                    $rootScope.isLogoShown = false;
                    $rootScope.menuMainTitle = '';
                    if ($rootScope.language == 'en') {
                        $rootScope.menuMainTitle = title_en;
                        $rootScope.selectedMenus = title_en;
                        $rootScope.selectedMenusSubMenus.push(title_en);
                    }
                    else {
                        $rootScope.menuMainTitle = title_ar;
                        $rootScope.selectedMenus = title_ar;
                        $rootScope.selectedMenusSubMenus.push(title_ar);
                    }


                }

                $scope.getRealEstateMainMenu = function () {
                    $scope.results = [];
                    $ionicLoading.show({
                        content: 'Loading...',
                        animation: 'fade-in',
                        showBackdrop: true,
                        maxWidth: 200,
                        showDelay: 0
                    });
                    Search.getAllMenu().then(function (res) {
                        $scope.results = res.data;
                        $ionicLoading.hide();
                    }, function (error) {
                        console.log(error)
                        $ionicLoading.hide();
                    });
                }
                //$scope.getRealEstateMainMenu();
                //var token = AuthService.GetAccessToken();
                //if (token) {
                //    $rootScope.isAuthorizedUser = true;
                //    console.log(CartService);
                //    CartService.getCartCount().then(function (response) {
                //        console.log(response)
                //        $rootScope.CartCount = response.cartItemsCount;
                //    }, function (error) { })
                //}

            }])