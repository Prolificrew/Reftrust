﻿angular.module('myApp').controller('CartDetailCtrl', function ($scope, $translate, $stateParams, $rootScope, $ionicLoading, $ionicModal, $ionicListDelegate, CartService,$ionicHistory) {
    $scope.editCartItem = {};
    $scope.CurrentLanguage= $translate.use()
    $scope.totalAmount = 0;

    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }

    $scope.delete = function (item) {
        $ionicListDelegate.closeOptionButtons();
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.deleteCart(item.id).then(function (response) {
            if (response == true) {
                var index = $scope.CartItems.map(function (elem) { return elem.id }).indexOf(item.id);
                $scope.CartItems.splice(index, 1);
                $rootScope.CartCount = $scope.CartItems.length;
                calculateTotalAmount();
            }
            $ionicLoading.hide();
        }, function (error) {
            $ionicLoading.hide();
        })
    };
    $scope.edit = function (item) {
        $scope.editCartItem = angular.copy(item);
        $ionicListDelegate.closeOptionButtons();
        $ionicModal.fromTemplateUrl('edit-popup-template.html', {
            // Use our scope for the scope of the modal to keep it simple
            scope: $scope,
            // The animation we want to use for the modal entrance
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.editCartItemModal = modal;
            $scope.editCartItemModal.show();
        });

    }
    $scope.editCancel = function () {
        $scope.editCartItemModal.hide();
        $scope.editCartItem = {}
    }
    $scope.updateCartItem = function () {
        //console.log($scope.editCartItem)

        CartService.updateCart($scope.editCartItem).then(function (response) {
            if (response == true) {
                var index = $scope.CartItems.map(function (elem) { return elem.id }).indexOf($scope.editCartItem.id);
                $scope.CartItems[index] = $scope.editCartItem;
                calculateTotalAmount();
                $scope.editCartItemModal.hide();
            }
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });

       
        
    }
    function getCartList() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.getCartList().then(function (response) {
           // console.log(response);
            $scope.CartItems = response;
            calculateTotalAmount();
            $ionicLoading.hide();
        }, function (error) {
            console.log(error);
            $ionicLoading.hide();
        })
    }
    function calculateTotalAmount() {
        $scope.totalAmount = 0;
        angular.forEach($scope.CartItems, function (obj) {
            $scope.totalAmount += obj.adet * obj.birim_fiyat;
        })
    }
    //calculateTotalAmount();
    //getCartList();
    if ($stateParams.id) {
        CartService.addCart($stateParams.id).then(function (response) {
            $scope.CartItems = response;
            $rootScope.CartCount = response.length;
            calculateTotalAmount();
        }, function (error) {
            console.log(error);
        })
    } else {
        getCartList();
    }
})