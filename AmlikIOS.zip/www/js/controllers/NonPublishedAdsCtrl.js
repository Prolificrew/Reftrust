﻿angular.module('myApp').controller('NonPublishedAdsCtrl', function ($scope, $translate, $rootScope, AuthService, $state, $ionicHistory, $ionicLoading, MyAccountServices, $ionicModal, $filter, $ionicScrollDelegate) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    $scope.nonPublishedAdsURL = 'https://www.amlik.com/img_post/thumb/';
    $rootScope.myGoBack = function () {
        $ionicHistory.goBack(-1);
    }
    $scope.queryObj = {
        page_number: '',
        order_type: 'DateDesc'
    }

    $scope.nonPubAdsPageNo = "1";
    $scope.noMoreNonPubAdsAvailable = false;
    $scope.NonPublishedAds = [];
    $scope.isResponse = false;
    $scope.loadNonPubAds = function () {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getNonPublishedAds($scope.nonPubAdsPageNo, $scope.queryObj.order_type).then(function (res) {
            if (res.length > 0) {
                //$scope.finterList = $scope.NonPublishedAds = res;
                $scope.NonPublishedAds.push.apply($scope.NonPublishedAds, res);
                $scope.nonPubAdsPageNo++;
                $ionicLoading.hide();
            }
            else {
                $scope.noMoreNonPubAdsAvailable = true;
                $ionicLoading.hide();
            }
            $scope.isResponse = true;
        }, function (error) {
            $ionicLoading.hide();
        });
    }
    $scope.clickCount = 1;
    $scope.goToProductDetail=function(ad, title)
    {
        if (title == 'product' && $scope.clickCount == 1) {
            $scope.clickCount++;
            $state.go('product-detail', { url: 'null', ilan_resim: ad.ilan_resim, logo: 'null', id: ad.ilan_no });
        }

        if (title == 'edit' && $scope.clickCount == 1) {
            $scope.clickCount++;
            $state.go("postDetail", { categoryId: ad.kat_liste.split('.')[ad.kat_liste.split('.').length - 2], kat_Id: ad.kat_liste, adID: ad.ilan_no });
        }
        
    }

    $ionicModal.fromTemplateUrl('popup-OrderBy.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.OrderByPopUp = modal;
    });

    $scope.ShowOrderByPopUp = function () {
        $scope.openOrderByModal();
    }

    $scope.openOrderByModal = function () {
        $scope.OrderByPopUp.show();
    };
    $scope.closeOrderByModal = function () {
        $scope.OrderByPopUp.hide();
    };


    $ionicModal.fromTemplateUrl('popup-FindPopup.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.ShowFindPopup = modal;
    });


    $scope.openFindPopupModal = function () {
        $scope.ShowFindPopup.show();
    };
    $scope.closeFindPopupModal = function () {
        $scope.ShowFindPopup.hide();
    };

    $scope.findData = function (data) {
        $scope.ShowFindPopup.hide();
    }

    function GetSortedData(pageNo, OrderType) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountServices.getNonPublishedAds(pageNo, OrderType).then(function (res) {
            //$rootScope.isCountShow = true;
            $scope.NonPublishedAds.length = 0;
            if (res.length > 0) {
                $scope.NonPublishedAds = res;
                $scope.nonPubAdsPageNo++;
            }
            else {
                $scope.noMoreNonPubAdsAvailable = true;
            }

            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
        $rootScope.isShownMapListingButton = true;
    }

    $scope.orderDate = function (predicate, radio) {
        $ionicScrollDelegate.$getByHandle('small').scrollTop();
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        if (predicate == '1') {
            $scope.queryObj.order_type = 'DateDesc';
            $scope.nonPubAdsPageNo = '1';
        } else {
            $scope.queryObj.order_type = 'DateAsc';
            $scope.nonPubAdsPageNo = '1';
        }
        GetSortedData($scope.nonPubAdsPageNo, $scope.queryObj.order_type);
        $scope.OrderByPopUp.hide();
    };

    $scope.orderPrice = function (order, radio) {
        $ionicScrollDelegate.$getByHandle('small').scrollTop();
        $("#Radio" + radio).find('input:radio').prop('checked', true);
        if (order == '1') {
            $scope.queryObj.order_type = 'PriceAsc';
            $scope.nonPubAdsPageNo = '1';

        } else {
            $scope.queryObj.order_type = 'PriceDesc';
            $scope.nonPubAdsPageNo = '1';
        }
        GetSortedData($scope.nonPubAdsPageNo, $scope.queryObj.order_type);
        $scope.OrderByPopUp.hide();
    }

    $scope.findData = function (filterText) {

        if (filterText == "") {
            $scope.nonPubAdsPageNo = "1";
            $scope.queryObj.order_type = "DateAsc";
            $scope.NonPublishedAds = [];
            $scope.loadNonPubAds();
            $scope.ShowFindPopup.hide();
        }
        else {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            $scope.nonPubAdsPageNo = '1';
            MyAccountServices.getNonPublishedAdsByText($scope.nonPubAdsPageNo, filterText).then(function (res) {
                //$rootScope.isCountShow = true;
                //$scope.NonPublishedAds.length = 0;
                if (res.length > 0) {
                    $scope.NonPublishedAds = res;
                    $scope.nonPubAdsPageNo++;
                }
                else {
                    $scope.noMoreNonPubAdsAvailable = true;
                }

                $ionicLoading.hide();
                $ionicScrollDelegate.resize()
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }, function (error) {
                console.log(error)
                $ionicLoading.hide();
            });
            $scope.ShowFindPopup.hide();
        }
    }

    $scope.editNonPublishedAds = function (ad)
    {
        $state.go("postDetail", { categoryId: ad.kat_liste.split('.')[ad.kat_liste.split('.').length - 2], kat_Id: ad.kat_liste, adID: ad.ilan_no });
    }


    //LoadNonPublishedAds();
})