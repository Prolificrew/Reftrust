﻿angular.module('myApp').controller('StoreDetailCtrl', function ($scope, $translate, $rootScope, $stateParams, $ionicHistory, StoreService, $ionicLoading, $timeout, $ionicSlideBoxDelegate, $ionicModal, $ionicActionSheet, $ionicScrollDelegate, $state) {

    $rootScope.BannerURL = 'https://amlik.com/img_shop/back/';
    $rootScope.logoURl = 'https://amlik.com/img_shop/logo/';

    $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/adv";
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $scope.StoreDetail = [];
    $scope.storeData = [];
    $scope.StoreIamgeURL = "https://www.amlik.com/img_post/xl/";

    $rootScope.myGoBack = function () {

        $scope.$emit('$locationChangeSuccess', {});
        $ionicHistory.goBack(-1);
        if ($state.current.name == 'tab.issue-detail' || $state.current.name == 'tab.search-data') {
            if ($rootScope.getAllMenuProducts != undefined) {
                var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 1];
                var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
                $rootScope.selectedMenus = last_element;
                $rootScope.selectedMenusId = last_elementId;
                // $rootScope.selectedMenusSubMenus.splice(-1, 1);
                $rootScope.getAllMenuProducts = undefined;
            }
            else {

                var last_element = $rootScope.selectedMenusSubMenus[$rootScope.selectedMenusSubMenus.length - 2];
                var last_elementId = $rootScope.selectedMenusSubMenusId[$rootScope.selectedMenusSubMenusId.length - 2];
                $rootScope.selectedMenus = last_element;
                $rootScope.selectedMenusId = last_elementId;
                $rootScope.selectedMenusSubMenus.splice(-1, 1);
                //}
            }
        }
    };

    $scope.pageNo = "1";
    $scope.getStoreDetail = function (url) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        StoreService.storeDetail(url).then(function (res) {
            $scope.StoreDetailBanner = res.data.storedeailModel;
            $scope.noMoreItemsAvailable = false;
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    }

    $scope.getStoreDetail($stateParams.url);



    $scope.loadMore = function () {
        StoreService.getStoreList($stateParams.url, $scope.pageNo).then(function (res) {
            if (res.data.length > 0) {
                $scope.storeData.push.apply($scope.storeData, res.data);
                $scope.pageNo++;
            }
            else {
                $scope.noMoreItemsAvailable = true;
            }

            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });


    };

})