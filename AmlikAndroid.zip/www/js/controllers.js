//// Scroll fix directive
//(function () {
//    var HorizontalScrollFix = (function () {
//        function HorizontalScrollFix($timeout, $ionicScrollDelegate) {
//            return {
//                restrict: 'A',
//                link: function (scope, element, attrs) {
//                    var mainScrollID = attrs.horizontalScrollFix,
//                        scrollID = attrs.delegateHandle;

//                    var getEventTouches = function (e) {
//                        return e.touches && (e.touches.length ? e.touches : [
//                          {
//                              pageX: e.pageX,
//                              pageY: e.pageY
//                          }
//                        ]);
//                    };

//                    var fixHorizontalAndVerticalScroll = function () {
//                        var mainScroll, scroll;
//                        mainScroll = $ionicScrollDelegate.$getByHandle(mainScrollID).getScrollView();
//                        scroll = $ionicScrollDelegate.$getByHandle(scrollID).getScrollView();

//                        // patch touchstart
//                        scroll.__container.removeEventListener('touchstart', scroll.touchStart);
//                        scroll.touchStart = function (e) {
//                            var startY;
//                            scroll.startCoordinates = ionic.tap.pointerCoord(e);
//                            if (ionic.tap.ignoreScrollStart(e)) {
//                                return;
//                            }
//                            scroll.__isDown = true;
//                            if (ionic.tap.containsOrIsTextInput(e.target) || e.target.tagName === 'SELECT') {
//                                scroll.__hasStarted = false;
//                                return;
//                            }
//                            scroll.__isSelectable = true;
//                            scroll.__enableScrollY = true;
//                            scroll.__hasStarted = true;
//                            scroll.doTouchStart(getEventTouches(e), e.timeStamp);
//                            startY = mainScroll.__scrollTop;

//                            // below is our changes to this method
//                            // e.preventDefault();

//                            // lock main scroll if scrolling horizontal
//                            //$timeout((function () {
//                            //    var animate, yMovement;
//                            //    yMovement = startY - mainScroll.__scrollTop;
//                            //    if (scroll.__isDragging && yMovement < 2.0 && yMovement > -2.0) {
//                            //        mainScroll.__isTracking = false;
//                            //        mainScroll.doTouchEnd();
//                            //        animate = false;
//                            //        return mainScroll.scrollTo(0, startY, animate);
//                            //    } else {
//                            //        return scroll.doTouchEnd();
//                            //    }
//                            //}), 100);
//                        };
//                        scroll.__container.addEventListener('touchstart', scroll.touchStart);
//                    };
//                    $timeout(function () { fixHorizontalAndVerticalScroll(); });
//                }
//            };
//        }

//        return HorizontalScrollFix;

//    })();

//    angular.module('AmlikAndroid').directive('horizontalScrollFix', ['$timeout', '$ionicScrollDelegate', HorizontalScrollFix]);

//}).call(this);
angular.module('AmlikAndroid.controllers', ['pascalprecht.translate'])
       .controller('AppCtrl', ['$scope', '$rootScope', '$state', '$stateParams', '$translate', 'Search', '$ionicLoading', 'AuthService', 'CartService', 'toaster', function ($scope, $rootScope, $state, $stateParams, $translate, Search, $ionicLoading, AuthService, CartService, toaster) {

           $scope.curlang = $translate.use();
           $rootScope.language = $translate.use();
           $scope.SlideSide = $rootScope.language == "en" ? "left" : "right"
           $rootScope.isShownMapButton = false;
           $rootScope.isShownMapsButton = false;
           $rootScope.isShownListingButton = false;
           $rootScope.isShowSearchButton = false;
           $rootScope.isLogoShown = true;
           $rootScope.isSearchedRecord = true;
           $scope.query = '';
           $rootScope.showsearchtext = false;
           $rootScope.ProductInCart = [];
           $scope.doSearch = function (query) {

               $rootScope.isLogoShown = false;
               if (!$rootScope.showsearchtext) {
                   query = "";
               }
               if (query != "") {
                   $state.go('app.search-data', {
                       query: query, categoryId: ''
                   });
               }
               else {

                   $scope.query = "";
                   $rootScope.showsearchtext = $rootScope.showsearchtext ? false : true;
                   $rootScope.isShowSearchButton = true;
               }
           };
           $("#toast-container").removeClass('toast-top-right');
           $scope.pageNo = "1";
           $scope.searchingData = function (query) {

               if (query != "") {
                   $ionicLoading.show({
                       content: 'Loading...',
                       animation: 'fade-in',
                       showBackdrop: true,
                       maxWidth: 200,
                       showDelay: 0
                   });
                   $rootScope.isSearchedRecord = false;
                   $rootScope.isLogoShown = false;
                   Search.getSearch(query, $rootScope.language).then(function (res) {
                       if (res.data.data.length > 0) {
                           $scope.results = res.data.data;

                           $rootScope.list = [];
                           var lastChar = '';
                           for (var i = 0, len = $scope.results.length; i < len; i++) {
                               var item = $scope.results[i];

                               if (item.type != lastChar) {
                                   $rootScope.list.push({
                                       n: item.type, letter: true
                                   });
                                   lastChar = item.type;
                               }
                               $rootScope.list.push(item);
                           }
                       }
                       $ionicLoading.hide();
                   });
                   //$state.go('tab.search-data', { query: query });
               }
               else {
                   $rootScope.isSearchedRecord = true;
                   $rootScope.isLogoShown = true;
               }
           }
           function changevariablelanguage() {
               if (!$rootScope.isLoggedin) {
                   $rootScope.fullName = $translate.instant('member_Login');
               }
               $rootScope.categoryHeader = $translate.instant('categories');

           };
           var ch = true;
           $rootScope.changeLanguage = function (key) {
               if (ch) {
                   ch = false;
                   $rootScope.language = key;
                   localStorage.setItem('UserLanguage', key);
                   $translate.use(key);

                   //if (key == 'en') {
                   //    if ($("#MenuDrawer").hasClass('right')) {
                   //        $("#MenuDrawer").removeClass('right');
                   //        $("#MenuDrawer").addClass('left').attr("style","transform: translate3d(-100%, 0px, 0px) !important; background: rgb(49, 60, 82);");

                   //    }
                   //    $rootScope.drawerSide = "left";
                   //}
                   //else {
                   //    if ($("#MenuDrawer").hasClass('left')) {
                   //        $("#MenuDrawer").removeClass('left');
                   //        $("#MenuDrawer").addClass('right');
                   //    }
                   //    $rootScope.drawerSide = "right";
                   //}

                   $scope.curlang = key;
                   $scope.closeDrawer();
                   setTimeout(function () {
                       changevariablelanguage();
                   }, 500)
               }
               setTimeout(function () {
                   ch = true;
               }, 5000)

           };

           $scope.clearArray = function () {
               $scope.closeDrawer();
           }

           $rootScope.logout = function () {
               //alert("sgdfg");
               $rootScope.fullName = $translate.instant('member_Login');
               $rootScope.userId = 0;
               $scope.closeDrawer();
               AuthService.logout();
               $rootScope.CartCount = 0;
               $state.go('app.home')
           }
           function closeDrawer() {
               $scope.closeDrawer();
           };
           var token = AuthService.GetAccessToken();
           if (token) {
               //console.log(CartService);
               CartService.getCartCount().then(function (response) {
                   //console.log(response)
                   $rootScope.CartCount = response.cartItemsCount;
               }, function (error) {
               })
           } else {
               $rootScope.CartCount = 0;
           }

       }])

        .controller('HomeCtrl', function ($scope, $translate, $rootScope, $ionicLoading, StoreService, CategoriesService, $ionicScrollDelegate, $timeout, $state, $cordovaSQLite) {
            $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
            $rootScope.cateImageUrl = "https://www.amlik.com/img_post/adv";
            $scope.curlang = $translate.use();
            $rootScope.language = $translate.use();
            $rootScope.isShownOnHomePage = true;
            $scope.storeData = [];

            $rootScope.drawerSide = "left";

            $rootScope.isShowSearchButton = true;
            $rootScope.isInSubMenu = false;
            $rootScope.isShownMapButton = false;
            $rootScope.isShownMapsButton = false;
            $rootScope.isShownListingButton = false;
            $rootScope.Selected = undefined;
            $rootScope.userUploadedImages = [];
            $rootScope.userLocationLatLng = '';

            $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
            $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS tbHomePageCategories (advID integer, category_en text, category_ar text)");
            $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS tbHomePageStore (id integer,ad text, logo text, url text)");
            $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS tbHomePageAdvs (advID integer,ilan_no integer,ilan_resim text, kat_liste text, baslik text,fiyat integer,url text,logo text)");
            $scope.pageNo = "1";

            $scope.noMoreDataAvailable = false;
            function storeLocalDataStoreDetail(data) {
                angular.forEach(data, function (obj) {
                    var query = "INSERT INTO tbHomePageStore (id, ad, logo,url) VALUES (?,?,?,?)";
                    $cordovaSQLite.execute($rootScope.db, query, [obj.id, obj.ad, obj.logo, obj.url]).then(function (res) {
                        var message = "INSERT ID -> " + res.insertId;
                        //console.log(message);

                    }, function (err) {
                        console.log(err);
                        //alert(err);
                    });

                });
            };
            function loadData() {
                StoreService.getStoreDetail(1).then(function (res) {
                    if (res.data.length > 0) {
                        $scope.storeData.push.apply($scope.storeData, res.data);
                        storeLocalDataStoreDetail(res.data)
                    }
                    else {
                        $scope.noMoreDataAvailable = true;
                    }
                    $ionicScrollDelegate.resize();
                });
            }
            function loadDataFromLocal() {
                var query = "select * from tbHomePageStore";
                $cordovaSQLite.execute($rootScope.db, query, []).then(function (res) {
                    if (res.rows.length > 0) {
                        for (var i = 0; i < res.rows.length; i++) {
                            $scope.storeData.push(res.rows.item(i))
                        }
                    } else {
                        loadData();
                    }
                }, function (err) {
                    console.log(err);
                    //alert(err);
                });

            }
            $scope.loadMoreData = function () {
                //alert($scope.pageNo)
                if ($scope.pageNo == '1') {
                    loadDataFromLocal();
                    $scope.pageNo++;
                }
                else {
                    StoreService.getStoreDetail($scope.pageNo).then(function (res) {
                        if (res.data.length > 0) {
                            $scope.storeData.push.apply($scope.storeData, res.data);
                            if ($scope.pageNo == '1') {
                                storeLocalDataStoreDetail(res.data)
                            }
                            $scope.pageNo++;
                        }
                        else {
                            $scope.noMoreDataAvailable = true;
                        }
                        $ionicScrollDelegate.resize()
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    });
                }

            };
            if ($scope.curlang == "ar") {
                $scope.loadMoreData();
            }
            $rootScope.loadMoreData = $scope.loadMoreData;
            $scope.categoriesData = [];
            function storeLocal(data) {
                angular.forEach(data, function (obj) {
                    var query = "INSERT INTO tbHomePageCategories (advID, category_en, category_ar, page_no) VALUES (?,?,?,?)";
                    $cordovaSQLite.execute($rootScope.db, query, [obj.advID, obj.category_en, obj.category_ar, obj.page_no]).then(function (res) {
                        var message = "INSERT ID -> " + res.insertId;
                        //console.log(message);

                    }, function (err) {
                        console.log(err);
                        //alert(err);
                    });
                    angular.forEach(obj.homePageAdvs, function (objAdv) {
                        var query = "INSERT INTO tbHomePageAdvs (advID, ilan_no, ilan_resim,kat_liste,baslik,fiyat,url,logo) VALUES (?,?,?,?,?,?,?,?)";
                        $cordovaSQLite.execute($rootScope.db, query, [obj.advID, objAdv.ilan_no, objAdv.ilan_resim, objAdv.kat_liste, objAdv.baslik, objAdv.fiyat, objAdv.url, objAdv.logo]).then(function (res) {
                            var message = "INSERT ID -> " + res.insertId;
                            //console.log(message);

                        }, function (err) {
                            console.log(err);
                            //alert(err);
                        });
                    })

                })

            }
            $scope.noMoreCateDataAvailable = [];
            function loadCategories() {
                $ionicLoading.show({
                    content: 'Loading...', animation: 'fade-in', showBackdrop: true, maxWidth: 200, showDelay: 0
                });
                CategoriesService.getCategories().then(function (res) {
                    if (res.data.length > 0) {
                        $scope.categoriesData = res.data;
                        storeLocal(res.data);
                        angular.forEach(res.data, function (value, index) {
                            $scope.noMoreCateDataAvailable[value.advID]=false;
                            //$scope.isDisabledScrollId = value.advID;
                        });
                        
                    }
                    $ionicLoading.hide();
                });
            }

            //loadCategories();
            function getDataFromLocal() {
                var query = "select * from tbHomePageCategories";
                $cordovaSQLite.execute($rootScope.db, query, []).then(function (res) {
                    if (res.rows.length > 0) {
                        for (var i = 0; i < res.rows.length; i++) {
                            $scope.categoriesData.push(res.rows.item(i))

                            var query = "select * from tbHomePageAdvs where advID=?";
                            $cordovaSQLite.execute($rootScope.db, query, [res.rows.item(i).advID]).then(function (res1) {
                                if (res1.rows.length > 0) {
                                    for (var i = 0; i < res1.rows.length; i++) {
                                        var index = $scope.categoriesData.map(function (elem) { return elem.advID }).indexOf(res1.rows.item(i).advID)
                                        if (!$scope.categoriesData[index].homePageAdvs) {
                                            $scope.categoriesData[index].homePageAdvs = [];
                                        }
                                        $scope.categoriesData[index].homePageAdvs.push(res1.rows.item(i))
                                    }
                                }
                            }, function (err) {
                                console.log(err);
                                //alert(err);
                            });
                        }
                    } else {
                        loadCategories();
                    }
                }, function (err) {
                    console.log(err);
                    //alert(err);
                });
            }
            getDataFromLocal();
            $rootScope.loadCategories = loadCategories;
            $scope.loadMoreCategoryData = function (data) {
                data.page_no++;
                CategoriesService.getPageWiseCategories(data.page_no, data.advID).then(function (res) {
                    if (res.data.length > 0) {
                        for (var i = 0; i < $scope.categoriesData.length; i++) {
                            if ($scope.categoriesData[i].category_en == data.category_en) {
                                $scope.categoriesData[i].homePageAdvs.push.apply($scope.categoriesData[i].homePageAdvs, res.data);
                            }
                        }
                        //$scope.pageNo++;
                    }
                    else {
                        //$scope.noMoreCateDataAvailable = true;
                        $scope.noMoreCateDataAvailable[data.advID] = true;
                    }
                    $ionicScrollDelegate.resize()
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });


            };

            $scope.getStoreDetail = function (Store) {
                $rootScope.isShowSearchButton = false;
                $state.go('app.store-detail', {
                    url: Store.url, logo: Store.logo, ilan_resim: '', id: Store.ilan_no
                });
            }

            $scope.getProductDetail = function (product) {
                $rootScope.isShowSearchButton = false;
                $state.go('app.product-detail', {
                    url: product.url, logo: product.logo, ilan_resim: product.ilan_resim, id: product.ilan_no
                });
            }

            $scope.onDrag = function (e) {
                var distance = -1 * e.gesture.deltaY;
                $ionicScrollDelegate.$getByHandle('horizontal').scrollBy(0, distance, true);
                console.log(distance);
            };

        })
        .controller('PlaylistCtrl', function ($scope, $stateParams) {
            $scope.closeDrawer();
        })
    //get commom menu controller
    .controller('MenuCommonCtrl', function ($scope, $rootScope, $stateParams, commonMenusServices, $ionicLoading, $ionicSlideBoxDelegate, $timeout, $state, $cordovaSQLite, $ionicPlatform, $ionicHistory) {
        $scope.closeDrawer();

        $rootScope.isShowSearchButton = false;
        $rootScope.isShownMapButton = false;
        $rootScope.isShownMapsButton = false;
        $rootScope.isShownListingButton = false;
        $scope.results = [];
        $scope.results1 = [];
        $scope.Selected = [];
        $scope.menuSelectedId = [];
        $scope.menuKatList = [];
        $rootScope.isInSubMenu = false;
        $rootScope.selectedMenusId = $stateParams.id;
        $rootScope.selectedMenuskat_liste = $stateParams.kat_liste;
        $rootScope.selectedMenus = $stateParams.selectedMenu;
        var subMenuTriger = false;
        if ($stateParams.selectedMenu) {
            $rootScope.isInSubMenu = true;
        }
        $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
        $cordovaSQLite.execute($rootScope.db, "CREATE TABLE IF NOT EXISTS tblMenu (id integer, ad_en text, ad_ar text, ads integer, selectedId integer, kat_liste float )");

        $scope.getAllProducts = function (query, id, kat_Id) {
            $rootScope.getAllMenuProducts = true;
            $rootScope.mainMenuTitle = $stateParams.selectedMenu;
            $state.go('app.search-data', { query: query, categoryId: $rootScope.selectedMenusId, kat_liste: $rootScope.selectedMenuskat_liste });
        }

        $scope.deleteData = function (selectedId) {
            $rootScope.db = openDatabase('Amlik.db', '1.0', 'populated', 5 * 1024 * 1024);
            var query = "DELETE FROM Menu tblMenu selectedId=?";
            $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {
                console.log(res);
            }, function (err) {
                console.log(err);
            });
        };




        $scope.getCateCommonSubMainMenu = function (menuId) {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });


            commonMenusServices.commonMenu(menuId).then(function (res) {
                //$scope.results = [];
                if ($scope.results == undefined) {
                    $scope.results.push(res.data);
                }
                else {
                    $scope.results.push(res.data);
                    setTimeout(function () {
                        $ionicSlideBoxDelegate.next();
                        subMenuTriger = false;
                        $scope.$apply();
                    });
                }
                $scope.insert(menuId, res.data);
                // $scope.select(menuId);
                $ionicLoading.hide();
            });
        }


        $scope.getCateCommonSubMainMenuFromLocalDb = function (selectedId) {
            $rootScope.isShownMapButton = false;
            $rootScope.isShownMapsButton = false;
            $rootScope.isShownListingButton = false;
            $rootScope.isShowSearchButton = false;
            $rootScope.MenuSelectedId = selectedId;
            try {

                var query = "SELECT id, ad_en, ad_ar, ads, kat_liste FROM tblMenu WHERE selectedId = ?";
                $cordovaSQLite.execute($rootScope.db, query, [selectedId]).then(function (res) {

                    if (res.rows.length > 0) {
                        $scope.results1 = [];
                        for (var i = 0; i < res.rows.length; i++) {
                            $scope.results1.push(res.rows.item(i));
                        }
                        $scope.results.push($scope.results1);
                        setTimeout(function () {
                            $ionicSlideBoxDelegate.next();
                            subMenuTriger = false;
                            $scope.$apply();
                        }, 200);


                    } else {
                        $scope.getCateCommonSubMainMenu(selectedId);
                    }
                }, function (err) {
                    //alert(err);
                    console.log(err);
                });
            }
            catch (e) {
                console.log(e.message);
            }
        }



        //$scope.getCateCommonSubMainMenuFromLocalDb($stateParams.id);


        $scope.getCommonSubMainMenu = function (menu) {

            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            commonMenusServices.commonMenu(menu.id).then(function (res) {

                if (res.data.length > 0) {
                    if ($scope.results.length == 0) {
                        $scope.results.push(res.data);
                        $ionicLoading.hide();
                    }
                    else {
                        $scope.results.push(res.data);
                        if ($rootScope.language == 'ar') {
                            $scope.Selected.push(menu.ad_ar);
                        }
                        else {
                            $scope.Selected.push(menu.ad_en);
                        }
                        $scope.menuSelectedId.push(menu.id);
                        $scope.menuKatList.push(menu.kat_liste);
                        $rootScope.selectedMenuskat_liste = menu.kat_liste;
                        setTimeout(function () {
                            $ionicLoading.hide();
                            $ionicSlideBoxDelegate.next();
                            subMenuTriger = false;
                            $scope.$apply();
                        });
                        //$ionicLoading.hide();
                    }
                    $scope.insert(menu.id, res.data);
                }
                else {
                    subMenuTriger = false;
                    $rootScope.isShownMapButton = true;
                    $rootScope.isShownMapsButton = true;
                    $rootScope.mainMenuTitle = $stateParams.selectedMenu;

                    //var kat_liste = '';
                    //if (menu.kat_liste.split('.').length > 2) {
                    //    for (var i = 0; i < menu.kat_liste.split('.').length - 2; i++) {
                    //        kat_liste += menu.kat_liste.split('.')[i] + '.'
                    //    }
                    //}
                    //else {
                    //    kat_liste = menu.kat_liste;
                    //}

                    $state.go('app.search-data', {
                        query: "", categoryId: menu.id, kat_liste: menu.kat_liste
                    });
                    $ionicLoading.hide();
                }

            });
        }
        $scope.getCommonSubMainMenuFromLocalDb = function (menu) {

            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });

            try {

                var query = "SELECT id, ad_en, ad_ar, ads, kat_liste FROM tblMenu WHERE selectedId = ?";
                $cordovaSQLite.execute($rootScope.db, query, [menu.id]).then(function (res) {

                    $scope.results1 = [];
                    if (res.rows.length > 0) {

                        for (var i = 0; i < res.rows.length; i++) {
                            $scope.results1.push(res.rows.item(i));
                        }
                        $scope.results.push($scope.results1);
                        setTimeout(function () {
                            $ionicSlideBoxDelegate.next();
                            subMenuTriger = false;
                            $scope.$apply();
                            $ionicLoading.hide();
                        });
                        if ($rootScope.language == 'ar') {
                            $scope.Selected.push(menu.ad_ar);
                        }
                        else {
                            $scope.Selected.push(menu.ad_en);
                        }
                        $scope.menuSelectedId.push(menu.id);
                        $scope.menuKatList.push(menu.kat_liste);
                        $rootScope.selectedMenuskat_liste = menu.kat_liste;

                    } else {
                        $scope.getCommonSubMainMenu(menu);
                        //$ionicLoading.hide();
                    }
                    //$ionicLoading.hide();
                }, function (err) {
                    //alert(err);
                    console.log(err);
                    $ionicLoading.hide();
                });
            }
            catch (e) {
                console.log(e.message);
                $ionicLoading.hide();
            }




        }

        if ($scope.Selected.length == 0) {
            try {



                if ($rootScope.menuSelectedId.length > 0) {
                    $scope.Selected = $rootScope.Selected;
                    $scope.menuSelectedId = $rootScope.menuSelectedId;
                    $scope.menuKatList = $rootScope.menuKatList;
                    FillData();
                } else {
                    $scope.Selected.push($stateParams.selectedMenu);
                    $scope.menuSelectedId.push($stateParams.id);
                    $scope.menuKatList.push($stateParams.kat_liste);
                    $scope.getCateCommonSubMainMenuFromLocalDb($stateParams.id);
                }
            }
            catch (ex) {
                $scope.Selected.push($stateParams.selectedMenu);
                $scope.menuSelectedId.push($stateParams.id);
                $scope.menuKatList.push($stateParams.kat_liste);
                $scope.getCateCommonSubMainMenuFromLocalDb($stateParams.id);
            }


        } else {
            var index = $scope.menuSelectedId.map(function (elem) { return elem; }).indexOf($stateParams.id);
            $ionicSlideBoxDelegate.slide(index);
        }
        function FillData() {
            if ($rootScope.menuSelectedId.length > 0) {
                $ionicLoading.show({
                    content: 'Loading...',
                    animation: 'fade-in',
                    showBackdrop: true,
                    maxWidth: 200,
                    showDelay: 0
                });
                for (var i = 0; i < $rootScope.menuSelectedId.length; i++) {
                    $scope.getCateCommonSubMainMenuFromLocalDb($rootScope.menuSelectedId[i]);
                }
                setTimeout(function () {
                    $rootScope.Selected = [];
                    $rootScope.menuSelectedId = [];
                    $rootScope.menuKatList = [];
                    $ionicLoading.hide();
                }, 3000)
            }
        }

        $scope.getSubMenus = function (menu) {
            if (subMenuTriger === false) {
                $rootScope.selectedMenusId = menu.id;
                $rootScope.selectedMenus = menu.ad_en;

                if ($rootScope.language == 'ar') {
                    $rootScope.selectedMenus = menu.ad_ar;
                }

                subMenuTriger = true;
                if ($scope.Selected.indexOf(menu.ad_en) !== -1 && $scope.menuSelectedId.indexOf(menu.id) !== -1) {
                    $ionicSlideBoxDelegate.next();

                    subMenuTriger = false;

                } else {
                    var slideCount = $ionicSlideBoxDelegate.slidesCount()
                    var currentIndex = $ionicSlideBoxDelegate.currentIndex();
                    if (currentIndex == 0) {
                        if ($scope.results.length > 1) {
                            for (var i = 1; i <= $scope.results.length; i++) {
                                $scope.results.splice(-1, 1);
                                $scope.Selected.splice(-1, 1);
                            }
                        }
                    } else {
                        currentIndex++;
                        $scope.results.splice(currentIndex, 1);
                        $scope.Selected.splice(currentIndex, 1);
                    }
                    $scope.getCommonSubMainMenuFromLocalDb(menu);

                }
            }
        }

        $scope.next = function () {
            $ionicSlideBoxDelegate.next();
            subMenuTriger = false;
        };

        $scope.slideChanged = function (index) {
            $ionicSlideBoxDelegate.slide(index);
            //$rootScope.$broadcast('slideBox.slideChanged',index);
            $rootScope.selectedMenusId = $scope.menuSelectedId[index];
            $rootScope.selectedMenuskat_liste = $scope.menuKatList[index];
            $rootScope.selectedMenus = $scope.Selected[index];
            $rootScope.$apply();
            console.log('Handler in Controller: ' + index);
        };
        $scope.$on('slideChanged', function (event, index) {
            $rootScope.selectedMenusId = $scope.menuSelectedId[index];
            $rootScope.selectedMenuskat_liste = $scope.menuKatList[index];
            $rootScope.selectedMenus = $scope.Selected[index];
        })
        $scope.insert = function (selectedId, menuList) {
            try {
                angular.forEach(menuList, function (value, index) {
                    var query = "INSERT INTO tblMenu (id, ad_en, ad_ar, ads, selectedId, kat_liste) VALUES (?,?,?,?,?,?)";
                    $cordovaSQLite.execute($rootScope.db, query, [value.id, value.ad_en, value.ad_ar, value.ads, selectedId, value.kat_liste]).then(function (res) {
                        var message = "INSERT ID -> " + res.insertId;
                        //console.log(message);

                    }, function (err) {
                        console.log(err);
                        //alert(err);
                    });
                });
            }
            catch (e) {
                console.log(e.message);
            }
        };

        //$scope.deleteData($stateParams.id);
        $scope.reloadData = function () {
            Search.commonMenu($stateParams.id).then(function (res) {
                try {
                    // $scope.results = [];
                    if (res.data.length > 0) {
                        $scope.results = res.data;

                        $scope.insert($stateParams.id, res.data);
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                    $ionicLoading.hide();
                }
                catch (e) {
                    console.log(e.message);
                }

            });
        }


        $scope.doRefresh = function () {
            $scope.deleteData($stateParams.id);
            $scope.reloadData();
        };
    })




