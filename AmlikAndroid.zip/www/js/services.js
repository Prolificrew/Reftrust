angular.module('AmlikAndroid.services', [])
        /**
         * A simple example service that returns some data.
         */
        .factory('Friends', function ($http, $translate,baseUrl) {
            //            // Might use a resource here that returns a JSON array
            //
            //            // Some fake testing data
            var friends = [];
            return {
                all: function () {
                    var lists = [];
                    $http.get('assets/friendlist.json').success(
                            function (data) {
                                friends = data;
                                for (var i = 0; i < friends.length; i++) {
                                    if (friends[i].lang === $translate.use()) {
                                        lists.push(friends[i]);
                                    }
                                }
                            }
                    );
                    return lists;
                },
                get: function (friendId) {
                    // Simple index lookup
                    return friends[friendId - 1];
                }
            };


        })
        .factory('StoreService', function ($http, $translate, baseUrl) {
            var storeData = [];
            var baseURL = baseUrl+"homepages/stores/";
            return {
                getStore: function (pageNo) {

                    return $http.get(baseURL + pageNo).then(function (response) {
                        storeData = response;
                        return storeData;
                    });
                }
            };
        })
        .factory('CategoriesService', function ($http, $translate, baseUrl) {
            return {
                getCategories: function () {

                    return $http.get(baseUrl + "homePages/HomePageAllAds").then(function (response) {
                        return response;
                    });
                },
                getPageWiseCategories: function (PageNo, AdTypeId) {
                    return $http.get(baseUrl + "homePages/HomePageAds/" + PageNo + "/" + AdTypeId).then(function (response) {
                        return response;
                    });
                }
            };
        })
        .factory('commonMenusServices', function ($http, $translate, baseUrl) {
            var realStateMenu = [];
            var baseURL = baseUrl+"Navigations/menu/";
            return {
                realStateSubMenus: function () {

                    return $http.get(baseURL + "5").then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                vehicleMenus: function () {

                    return $http.get(baseURL + "1").then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                commonMenu: function (id) {

                    return $http.get(baseURL + id).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                resSubMenus: function (id) {

                    return $http.get(baseURL + id).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                },
                estateOtherSubMenus: function (id) {
                    return $http.get(baseURL + id).then(function (response) {
                        realStateMenu = response;
                        return realStateMenu;
                    });
                }
            };
        });
