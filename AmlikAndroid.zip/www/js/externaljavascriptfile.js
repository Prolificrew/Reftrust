﻿//onDeviceReady = function () {
//alert("external js load");
//}
alert("external js load");
