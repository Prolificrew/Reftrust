﻿
window.common = (function () {
    var common = {};

    common.show = function ($ionicLoading) {
        $ionicLoading.show({
            template: 'Loading...'
        });
    };
    common.hide = function () {
        $ionicLoading.hide();
    };

    

    return common;
})();