﻿angular.module('AmlikAndroid').directive('slideWatcher', [function (rootScope) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.$on('slideBox.slideChanged', function (e, index) {
                scope.$emit('slideChanged', index)
                console.log('Handler in Directive: ' + index);
            });
        }
    };
}]).directive('bindMap', [function (rootScope) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var mapId = attrs.id;
            scope.$emit("BindMap", mapId);
        }
    };
}]).directive('fallbackSrc', function () {
    var fallbackSrc = {
        link: function postLink(scope, iElement, iAttrs) {
            iElement.bind('error', function () {
                angular.element(this).attr("src", iAttrs.fallbackSrc);
            });
        }
    }
    return fallbackSrc;
}).directive('bindMap', [function (rootScope) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var mapId = attrs.id;
            scope.$emit("BindMap", mapId);
        }
    };
}]).directive('reverseScroll', [function () {
    return {
        restrict: 'E',
        scope: { onInfinite: '&onInfinite', distance: '=distance' },
        link: function (scope, element, attrs) {
            var row = element[0];
            var distance = 25;
            if (!isNaN(scope.distance)) {
                var distance = parseInt(scope.distance);
            } else {
                console.error("value of distance should be a number")
            }
            var sendRequest = true;
            element.bind('scroll', function () {
                if (row.scrollLeft <= (row.offsetWidth * distance) / 100) {
                    console.log("Distance left :" + distance)
                    if (sendRequest) {
                        sendRequest = false;
                        scope.onInfinite();
                    }
                } else {
                    sendRequest = true;
                }
            });
        }
    }
}]);