﻿angular.module('AmlikAndroid').controller("AdManagementController", function ($scope, $rootScope, AuthService, $state, $ionicSlideBoxDelegate, $ionicPopup, $ionicModal, MyAccountService, $ionicLoading, $filter) {

    var nonPubAdsPageNo = 1;
    var pubAdsPageNo = 1;

    $scope.currentSlider = 0;
    $scope.publishAdList = []
    $scope.NonPublishAdList = []
    $scope.publishAdFilterList = []
    $scope.NonPublishAdFilterList = []
    $scope.detailFilter = '';
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/thumb";
    $scope.date = new Date();
    $scope.slideChanged = function (index) {
        $scope.currentSlider = index;
        $ionicSlideBoxDelegate.slide(index);
    };
    $scope.myActiveSlide = 0;
    //debugger;
    var orderType = "DateDesc";
    var listofTabs = $(".management-tab-container").children();
    var width = 0;
    for (var i = 0; i < listofTabs.length; i++) {
        width += $(listofTabs[i]).width();
    }
    $(".management-tab-container").css("width", width + 'px');



    $scope.showDetailModal = function () {
        var detailPopup = $ionicPopup.show({
            templateUrl: 'detail-popup-template.html',
            title: 'Detail',
            cssClass: 'PublishAdDetail',
            subTitle: '',
            scope: $scope,
            buttons: [
              { text: 'Cancel' },
              {
                  text: 'OK',
                  type: 'button-default',
                  onTap: function (e) {
                      if ($scope.detailFilter) {
                          if ($scope.currentSlider == 1) {
                              $scope.NonPublishAdFilterList = $scope.NonPublishAdList.filter(function (elem) {
                                  return (elem.baslik.toLowerCase().indexOf($scope.detailFilter.toLowerCase()) >= 0)
                              })
                          } else {
                              $scope.PublishAdFilterList = $scope.PublishAdList.filter(function (elem) {
                                  return (elem.baslik.toLowerCase().indexOf($scope.detailFilter.toLowerCase()) >= 0)
                              })
                          }
                      } else {
                          if ($scope.currentSlider == 1) {
                              $scope.NonPublishAdFilterList = $scope.NonPublishAdList;
                          } else {
                              $scope.PublishAdFilterList = $scope.PublishAdList;
                          }
                      }
                  }
              }
            ]
        });
        detailPopup.then(function (response) {
            detailPopup.close();

        })
    };
    $ionicModal.fromTemplateUrl('sort-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.sortmodal = modal;
    }, function (error) { console.log(error) });
    $scope.Opensortmodal = function (address) {
        $scope.selectedAddress = address;
        $scope.sortmodal.show()
    };
    $scope.SortPublishAd = function (SortBy) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        if ($scope.currentSlider == 1) {
            nonPubAdsPageNo = 1;
            orderType = SortBy;
            $scope.NonPublishAdFilterList = [];
            loadNonPublishData();
        }
        else{
            $ionicLoading.hide();
        }
        $scope.sortmodal.hide();
    };

    function loadNonPublishData() {
        MyAccountService.getNonPublishedAd(nonPubAdsPageNo, orderType).then(function (response) {
            nonPubAdsPageNo++;
            $scope.NonPublishAdFilterList.push.apply($scope.NonPublishAdFilterList,response);
            $ionicLoading.hide();
        }, function (error) {
            console.log(error);
            $ionicLoading.hide();
        });
    };
    function loadPublishData() {
        MyAccountService.getPublishedAd(pubAdsPageNo).then(function (response) {
            pubAdsPageNo++;
            $scope.publishAdList.push.apply($scope.publishAdList,response);
            $scope.publishAdFilterList.push.apply($scope.publishAdFilterList, response);
            $ionicLoading.hide();
        }, function (error) {
            $ionicLoading.hide();
            console.log(error);
        });
    };

    function init() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        //loadPublishData();
        //loadNonPublishData();
    };


    $scope.loadPubAds = function () {
        loadPublishData();
    };
    $scope.loadNonPubAds = function () {
        loadNonPublishData();
    };

    $scope.clickCount = 1;
    $scope.goToProductDetail=function(ad, title)
    {
        if (title == 'product' && $scope.clickCount == 1) {
            $scope.clickCount++;
            $state.go('app.product-detail', { url: 'null', ilan_resim: ad.ilan_resim, logo: 'null', id: ad.ilan_no });
        }

        if (title == 'edit' && $scope.clickCount == 1) {
            $scope.clickCount++;
            $state.go("post.postDetail", { categoryId: ad.kat_liste.split('.')[ad.kat_liste.split('.').length - 2], kat_Id: ad.kat_liste, adID: ad.ilan_no });
        }
        
    }

    init();
});