﻿angular.module('AmlikAndroid').controller("PostAdEcommerceCtrl", function ($scope,$rootScope,PostDetailServices,$state,$ionicLoading) {
    $scope.eCommerce = {
        categoryId: $rootScope.categoryId,
        adPostId: $rootScope.PostInsertedId,
        IsEcommerce: '',
        parentCategory: $rootScope.parentCategory,
        return_policy: "0",
        return_text: '',
        shipping: 0,
        cash_on_delivery: "0",
        quantity: 1,
        ec_type:"0",
    }
    $scope.isFooterBarShown = true;
    $rootScope.currentStep = $rootScope.totalSteps;
    $scope.PosteCommerce = function () {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        $scope.eCommerce.ec_type = parseInt($scope.eCommerce.ec_type);
        $scope.eCommerce.return_policy = parseInt($scope.eCommerce.return_policy);
        $scope.eCommerce.cash_on_delivery = parseInt($scope.eCommerce.cash_on_delivery);
        $scope.eCommerce.IsEcommerce = parseInt($scope.eCommerce.ec_type);
        console.log($scope.eCommerce)
        PostDetailServices.postAdEcommerce($scope.eCommerce).then(function (response) {
            $ionicLoading.hide();
            $state.go("app.product-detail", { url: null, ilan_resim: null, logo: null, id: $rootScope.PostInsertedId });
        })
    }
})