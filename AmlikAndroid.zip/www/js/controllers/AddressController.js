﻿angular.module('AmlikAndroid').controller("AddressController", function ($scope, $rootScope, AuthService, $ionicLoading, CartService, $ionicModal, $state, toaster,CartService) {
    $scope.AddressList = []
    $scope.isAddAddress = false;
    $scope.newAddress = {}
    $scope.cityList = [];
    $scope.isSaveButton = true;
    var markersArray = [];
    $scope.locationLatLng = "";
    function getAddress() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.getAddress().then(function (response) {
            $scope.AddressList = response;
            $ionicLoading.hide();
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    };
    function getCityList() {
         CartService.getCityList().then(function (response) {
            //console.log(response);
            $scope.cityList = response;
            $scope.newAddress.cityID = response[0].id;
        }, function (error) {
            console.log(error)
        });
    };
    $ionicModal.fromTemplateUrl('address-option-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.optionmodal = modal;
    }, function (error) { console.log(error) });
    $scope.Openoptionmodal = function (address) {
        console.log(address)
        $scope.newAddress.title = address.baslik;
        $scope.newAddress.address = address.adres;
        $scope.optionmodal.show()
    }
    $scope.EditAddress = function () {
       
        $scope.optionmodal.hide()
        $scope.isSaveButton = false;
        $scope.isAddAddress = true;
        setTimeout(function () {
         
            initMap();
        },500)
        
        //$state.go("app.EditAddress", { id: $scope.selectedAddress.id})
    }
    $scope.AddNewAddress = function () {
        $scope.isAddAddress = true;
        $scope.isSaveButton = true;
        getDeviceLocation();
    }
    $scope.addAddressCancel = function () {
        $scope.isAddAddress = false;
        $scope.isSaveButton = true;
        setTimeout(function () {
            $scope.newAddress = {};
        }, 500)
        

    };
    $scope.add = function () {
        $scope.newAddress.LngLat = $scope.locationLatLng;
        CartService.SaveAddress($scope.newAddress).then(function (response) {
            $rootScope.SelectedAddressID = response;
            $scope.newAddres.id = response;
            $scope.AddressList.push($scope.newAddres)

        }, function (error) {

        })
    }
    function initMap(_lat, _lng) {
        var mapDiv = angular.element(document.getElementById("mapdiv"));
        if (mapDiv[0].innerHTML == "") {

            if (!_lng && !_lat) {
                var latlng = new google.maps.LatLng(24.266906, 45.1078489);
                $rootScope.locationLatLng = "24.266906,45.1078489";
            }
            else {
                var latlng = new google.maps.LatLng(_lat, _lng);
            }
            var myOptions = {
                zoom: 10,
                center: latlng,
                mapTypeControl: true,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            map = new google.maps.Map(document.getElementById("mapdiv"), myOptions);

            // add a click event handler to the map object
            google.maps.event.addListener(map, "click", function (event) {
                // place a marker
                placeMarker(event.latLng);

                $scope.locationLatLng = event.latLng.lat() + "," + event.latLng.lng();
                //// display the lat/lng in your form's lat/lng fields
                //document.getElementById("latFld").value = event.latLng.lat();
                //document.getElementById("lngFld").value = event.latLng.lng();
            });
            placeMarker(latlng);
        }
    }
    function placeMarker(location) {
        // first remove all markers if there are any
        deleteOverlays();

        var marker = new google.maps.Marker({
            position: location,
            map: map
        });

        // add marker in markers array
        markersArray.push(marker);
    }

    // Deletes all markers in the array by removing references to them
    function deleteOverlays() {
        if (markersArray) {
            for (i in markersArray) {
                markersArray[i].setMap(null);
            }
            markersArray.length = 0;
        }
    }

    function getDeviceLocation() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        navigator.geolocation.getCurrentPosition(function (res) {
            initMap(res.coords.latitude, res.coords.longitude)
            $rootScope.locationLatLng = res.coords.latitude + "," + res.coords.longitude;
            $ionicLoading.hide();
        }, function (error) {
            initMap();
            toaster.pop({ type: 'warning', title: "", body: "unable to find your location", showCloseButton: true })
            $ionicLoading.hide();
        }, { timeout: 20000 })

    }
  

    getAddress();
    getCityList();
});