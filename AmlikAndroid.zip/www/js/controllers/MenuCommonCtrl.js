﻿//get commom menu controller
angular.module('AmlikAndroid', ['pascalprecht.translate']).controller('MenuCommonCtrl', function ($scope, $rootScope, $stateParams, commonMenusServices, $ionicLoading, $ionicSlideBoxDelegate, $timeout, $state) {
    $scope.closeDrawer();
    //$scope.curlang = $translate.use();
    $scope.results = [];
    $scope.Selected = [];
    $rootScope.isInSubMenu = false;
    $rootScope.selectedMenusId = $stateParams.id;
    $rootScope.selectedMenuskat_liste = $stateParams.kat_liste;
    $rootScope.selectedMenus = $stateParams.selectedMenu;
    if ($stateParams.selectedMenu)
    {
        $rootScope.isInSubMenu = true;
    }
    $scope.getCommonSubMainMenu = function (menuId) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        commonMenusServices.commonMenu(menuId).then(function (res) {
            if (res.data.length > 0) {
                if ($scope.results.length == 0) {
                    $scope.results.push(res.data);
                }
                else {
                    $scope.results.push(res.data);
                    setTimeout(function () {
                        $ionicSlideBoxDelegate.next();
                        $scope.$apply();
                    });
                }
            }
            else {
                $rootScope.isShownMapButton = true;
                $rootScope.isShownMapsButton = true;
                $state.go('app.search-data', { query: "", categoryId: menuId });

            }
            $ionicLoading.hide();
        });
    }
    $scope.getAllProducts = function (query, id, kat_Id) {
        $rootScope.getAllMenuProducts = true;
        //$state.go('app.search-data', { query: query, categoryId: id, kat_liste: $rootScope.selectedMenuskat_liste });
        $state.go('app.search-data', { query: query, categoryId: id, kat_liste: kat_Id });
    }
    //$scope.getCommonSubMainMenu($stateParams.id);
    //debugger
    $scope.getCateCommonSubMainMenu = function (menuId) {
        //debugger
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        commonMenusServices.commonMenu(menuId).then(function (res) {
            if ($scope.results == undefined) {
                $scope.results.push(res.data);
            }
            else {
                $scope.results.push(res.data);
                setTimeout(function () {
                    $ionicSlideBoxDelegate.next();
                    $scope.$apply();
                });
            }

            $ionicLoading.hide();
        });
    }
    $scope.getCateCommonSubMainMenu($stateParams.id);

    if ($scope.Selected.length == 0) {
        $scope.Selected.push($stateParams.selectedMenu);
    }

    $scope.getSubMenus = function (menu) {
        debugger;
        if ($scope.Selected.indexOf(menu.ad_en) !== -1) {
            $ionicSlideBoxDelegate.next();
        } else {
            var slideCount = $ionicSlideBoxDelegate.slidesCount()
            var currentIndex = $ionicSlideBoxDelegate.currentIndex();
            if (currentIndex == 0) {
                if ($scope.results.length > 1) {
                    for (var i = 1; i <= $scope.results.length; i++) {
                        $scope.results.splice(-1, 1);
                        $scope.Selected.splice(-1, 1);
                    }
                }
            } else {
                currentIndex++;
                $scope.results.splice(currentIndex, 1);
                $scope.Selected.splice(currentIndex, 1);
            }
            $scope.getCommonSubMainMenu(menu.id);
            $scope.Selected.push(menu.ad_en);
        }
    }

    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.slideChanged = function (index) {
        //debugger
        $ionicSlideBoxDelegate.slide(index);
        //$rootScope.$broadcast('slideBox.slideChanged',index);
        console.log('Handler in Controller: ' + index);
    };


})
