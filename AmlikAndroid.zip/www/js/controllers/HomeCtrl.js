﻿angular.module('AmlikAndroid', ['pascalprecht.translate']).controller('HomeCtrl', function ($scope, $translate, $rootScope, $ionicLoading, StoreService, CategoriesService, $ionicScrollDelegate, $timeout) {
    $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/thumb";
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isShowSearchButton = true;
    $scope.storeData = [];
    $rootScope.Selected = undefined;
    $scope.changeLanguage = function (key) {
        $rootScope.language = key;
        $translate.use(key);
        $scope.curlang = key;
        $scope.closeDrawer();
    };
    $scope.pageNo = "1";

    $scope.noMoreDataAvailable = false;

    $scope.loadMoreData = function () {
        //if ($scope.storeData.length == 0) {
        //    $ionicLoading.show({
        //        content: 'Loading...',
        //        animation: 'fade-in',
        //        showBackdrop: true,
        //        maxWidth: 200,
        //        showDelay: 0
        //    });
        //}

        StoreService.getStore($scope.pageNo).then(function (res) {
            if (res.data.length > 0) {
                $scope.storeData.push.apply($scope.storeData, res.data);
                $scope.pageNo++;
            }
            else {
                $scope.noMoreDataAvailable = true;
            }

            //$ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        });


    };





    $scope.categoriesData = [];
    function loadCategories() {
        $ionicLoading.show({ content: 'Loading...', animation: 'fade-in', showBackdrop: true, maxWidth: 200, showDelay: 0 });
        CategoriesService.getCategories().then(function (res) {
            if (res.data.length > 0) {
                debugger
                $scope.categoriesData = res.data;
                $scope.noMoreCateDataAvailable = false;
            }

            $ionicLoading.hide();
        });
    }

    loadCategories();




    $scope.loadMoreCategoryData = function (data) {
        debugger
        CategoriesService.getPageWiseCategories($scope.pageNo, data.advID).then(function (res) {
            if (res.data.length > 0) {
                for (var i = 0; i < $scope.categoriesData.length; i++) {
                    if ($scope.categoriesData[i].category_en == data.category_en) {
                        $scope.categoriesData[i].homePageAdvs.push.apply($scope.categoriesData[i].homePageAdvs, res.data);
                    }
                }
                $scope.pageNo++;
            }
            else {
                $scope.noMoreDataAvailable = true;
            }

            // $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        });


    };

})