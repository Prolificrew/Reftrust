﻿angular.module('AmlikAndroid').directive("compareTo",function() {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function(scope, element, attributes, ngModel) {
             
            ngModel.$validators.compareTo = function(modelValue) {
                return modelValue == scope.otherModelValue;
            };
 
            scope.$watch("otherModelValue", function() {
                ngModel.$validate();
            });
        }
    };
}).controller("ChangePasswordController", function ($scope, $rootScope, AuthService, $state, $ionicSlideBoxDelegate, $ionicPopup, $ionicModal, MyAccountService, $ionicLoading,$translate) {
    //$scope.oldPasword = $scope.newPassword = $scope.confirmNewPassword = null;
    $scope.ChangePasswordObject = {
        OldPassword: "",
        NewPassword: "",
        confirmNewPassword: ""
    }
    $scope.isSuccess = false;
    $scope.errorMessage=''
    $scope.ChangePassword = function () {
        $scope.errorMessage = ''
        $scope.isSuccess = false;
        MyAccountService.ChangePassword($scope.ChangePasswordObject).then(function (response) {
            console.log(response);
            $scope.isSuccess = true;
            $scope.errorMessage = $translate.instant('PasswordChangeSuccessfullPleaselogin');
            setTimeout(function () {
                $rootScope.logout();
            },1500)
            
        }, function (error) {
            console.log(error);
            $scope.isSuccess = false;
            $scope.errorMessage = error.message;
        })
    }
});