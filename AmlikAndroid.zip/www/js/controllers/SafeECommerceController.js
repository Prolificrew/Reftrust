﻿angular.module('AmlikAndroid').controller('SafeECommerceController', function ($state, $scope, $rootScope, MyAccountService, $ionicSlideBoxDelegate, $ionicLoading) {
    $scope.PurchaseTransactionList = [];
    $scope.SoldTransactionList = [];
    $scope.currentSlider = 0;
    $scope.myActiveSlide = 0;
    $scope.isResponse = false;
    $scope.slideChanged = function (index) {
        $scope.currentSlider = index;
        $ionicSlideBoxDelegate.slide(index);
    };
    var listofTabs = $(".management-tab-container").children();
    var width = 0;
    for (var i = 0; i < listofTabs.length; i++) {
        width += $(listofTabs[i]).width();
    }
    $(".management-tab-container").css("width", width + 'px');

    function getPurchaseTransactionList() {
    $scope.isResponse = false;
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountService.GetAccountPurchaseTransactions().then(function (response) {
            $ionicLoading.hide();
            $scope.isResponse = true;
            $scope.PurchaseTransactionList = response;
            console.log(response);
        }, function (error) { $ionicLoading.hide(); console.log(error); $scope.isResponse = true; })
        MyAccountService.GetAccountSoldTransactions().then(function (response) {
            $ionicLoading.hide();
            $scope.isResponse = true;
            $scope.SoldTransactionList = response;
            console.log(response);
        }, function (error) { $ionicLoading.hide(); console.log(error); $scope.isResponse = true;})
    }
    getPurchaseTransactionList();
})