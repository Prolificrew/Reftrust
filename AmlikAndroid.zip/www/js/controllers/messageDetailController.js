﻿angular.module('AmlikAndroid').controller("MessageDetailController", function ($scope, $rootScope, AuthService, $ionicLoading, CartService, $ionicModal, $state, toaster, CartService, $ionicScrollDelegate, $stateParams, MyAccountService) {
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/thumb";
    $scope.messages = { baslik: '', id: 0 };
    $scope.isResponse = false;
    $scope.data = {
        "baslik": $scope.messages.baslik,
        "konu": "", 
        "tarih": "",
        "okundu": 0,
        "gonderen_id": $stateParams.SenderId,
        "alici_id": $stateParams.receiverId,
        "ilan_id": $stateParams.AdId,
    };


    $scope.myId = $stateParams.gonderen_id;
    $scope.isWait=false;
    $scope.sendMessage = function () {
        $scope.isWait = true;
        $scope.data.baslik = $scope.messages.baslik;
        $scope.data.tarih = new Date();
       
        //$scope.messages.productMessages.push(angular.copy($scope.data));
        MyAccountService.SendMessage(angular.copy($scope.data)).then(function (response) {
            $scope.isWait = false;
            if (response) { 
                $scope.messages.productMessages.push(response);
            }
        }, function (error) {
            console.log(error);
        })
        delete $scope.data.konu;
        $ionicScrollDelegate.scrollBottom(true);


    };


    $scope.inputUp = function () {
        if (isIOS) $scope.data.keyboardHeight = 216;
        $timeout(function () {
            $ionicScrollDelegate.scrollBottom(true);
        }, 300);

    };

    $scope.inputDown = function () {
        if (isIOS) $scope.data.keyboardHeight = 0;
        $ionicScrollDelegate.resize();
    };

    $scope.closeKeyboard = function () {
        // cordova.plugins.Keyboard.close();
    };



    function GetMessageDetails(Adid, SenderId, ReceiverId) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });

        MyAccountService.GetMessageDetails(Adid, SenderId, ReceiverId).then(function (response) {
            if (response) {
                $scope.messages = response;
                $scope.myId = response.user_id;
            }
            $scope.isResponse = true;
            //console.log(response);
            $ionicLoading.hide();
        }, function (error) { console.log(error); $ionicLoading.hide(); $scope.isResponse = true; })

    }
    if ($stateParams.AdId) {
        GetMessageDetails($stateParams.AdId, $stateParams.SenderId,$stateParams.receiverId);
    }
    //window.addEventListener('native.keyboardshow', function () {
    //   // $('.message-content-container').css('max-height', '220px');
    //});
    //window.addEventListener('native.keyboardhide', function () {
    //    //$('.message-content-container').css('max-height', '75%');
    //    //$('.message-list-container').animate({ scrollTop: $('.message-list-container').height() }, 'slow');
    //    ionic.Platform.fullScreen(true, false);
    //});
});