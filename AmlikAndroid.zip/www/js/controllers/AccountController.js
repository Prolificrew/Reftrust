﻿angular.module('AmlikAndroid').filter("checkCount",function(){
    return function (input) {
        if (parseInt(input) > 9) {
            return "9+"
        } else {
            return input;
        }
    }
}).controller("AccountController", function ($scope, $rootScope, AuthService,$state) {
    $scope.Accountlogout = function () {
        $rootScope.logout();
        $state.go('app.home')
    }
});