﻿angular.module('AmlikAndroid').controller('StoreDetailCtrl', function ($scope, $translate, $rootScope, $stateParams, $ionicHistory, StoreService, $ionicLoading, $timeout, $ionicSlideBoxDelegate, $ionicModal, $ionicActionSheet, $ionicScrollDelegate) {

    $rootScope.BannerURL = 'https://amlik.com/img_shop/back/';
    $rootScope.logoURl = 'https://amlik.com/img_shop/logo/';

    $rootScope.storeImageUrl = "https://www.amlik.com/img_shop/logo";
    $rootScope.cateImageUrl = "https://www.amlik.com/img_post/adv";
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $scope.StoreDetail = [];
    $scope.storeData = [];
    $rootScope.isShowSearchButton = false;
    $scope.StoreIamgeURL = "https://www.amlik.com/img_post/xl/";
    $rootScope.myGoBack = function () {
        $scope.$emit('$locationChangeSuccess', {});
        $ionicHistory.goBack();
    };

    $scope.pageNo = "1";
    $scope.getStoreDetail = function (url) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        StoreService.storeDetail(url).then(function (res) {
            $scope.StoreDetailBanner = res.data.storedeailModel;
            $scope.noMoreItemsAvailable = false;
            $rootScope.isShowSearchButton = false;
        });
    }

    $scope.getStoreDetail($stateParams.url);



    $scope.loadMore = function () {
        StoreService.getStoreList($stateParams.url, $scope.pageNo).then(function (res) {
            if (res.data.length > 0) {
                $scope.storeData.push.apply($scope.storeData, res.data);
                $scope.pageNo++;
            }
            else {
                $scope.noMoreItemsAvailable = true;
            }

            $ionicLoading.hide();
            $ionicScrollDelegate.resize()
            $scope.$broadcast('scroll.infiniteScrollComplete');
        });


    };

})