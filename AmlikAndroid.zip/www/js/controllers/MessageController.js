﻿angular.module('AmlikAndroid').controller("MessageController", function ($scope, $rootScope, AuthService, $state, $ionicSlideBoxDelegate, $ionicPopup, $ionicModal, MyAccountService, $ionicLoading) {
    $scope.currentSlider = 0;
    $scope.myActiveSlide = 0;
    $scope.slideChanged = function (index) {
        $scope.currentSlider = index;
        $ionicSlideBoxDelegate.slide(index);
    };
    $scope.inboxMessageList = [];
    $scope.outboxMessageList = [];
    function getInboxMessage() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountService.GetInboxMessages().then(function (response) {
            $scope.inboxMessageList = response;
            console.log(response);
            $ionicLoading.hide();
        }, function (error) { console.log(error); $ionicLoading.hide(); })
    };
    function getOutboxMessage() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountService.GetOutboxMessages().then(function (response) {
            $scope.outboxMessageList = response;
            console.log(response);
            $ionicLoading.hide();
        }, function (error) { console.log(error); $ionicLoading.hide(); })
    }
    getInboxMessage();
    getOutboxMessage();
});