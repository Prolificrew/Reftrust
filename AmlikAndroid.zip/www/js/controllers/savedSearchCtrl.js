﻿angular.module('AmlikAndroid').controller('savedSearchCtrl', ['$scope', '$rootScope', '$state', '$stateParams', '$translate', function ($scope, $rootScope, $state, $stateParams, $translate) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();

    $scope.closeDrawer();

    if (localStorage.getItem('savedSearchedRecord')) {
        $rootScope.savedSearchedRecord = JSON.parse(localStorage.getItem('savedSearchedRecord'));
    }

    $scope.getSavedSearchedData = function (data) {
        $rootScope.filterObjData = data.query.filterObjData;
        //$rootScope.$apply();
        if (data.query.CategorieID.split('.').length > 2) {
            $state.go('app.search-data', { query: data.query.SearchText, categoryId: data.query.CategorieID.split('.')[data.query.CategorieID.split('.').length - 2], kat_liste: data.query.CategorieID, title: data.saveSearchTitle });
        }
        else {
            $state.go('app.search-data', { query: data.query.SearchText, categoryId: '', kat_liste: data.query.CategorieID, title: data.saveSearchTitle });
        }
    }
}])