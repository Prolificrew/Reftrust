﻿
angular.module('AmlikAndroid').controller('ProductDetailCtrl', function ($scope, $translate, $rootScope, $stateParams, $ionicHistory, StoreService, $ionicLoading, $timeout, $ionicSlideBoxDelegate, $ionicModal, $ionicActionSheet, $state, $ionicPlatform, $sce) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $scope.locationMapView = '';
    $scope.ProductDetail = [];
    $rootScope.isShowSearchButton = false;
    $scope.ProductIamgeURL = "https://www.amlik.com/img_post/xl/";
    $scope.location_longlat = '';
    //Hide Map Buttons fron header
    $rootScope.isShownMapsButton = false;
    $rootScope.isShownMapButton = false;
    //end Hide Map Buttons fron header

    $scope.trustAsHtml = function (string) {
        return $sce.trustAsHtml(string);
    };

    $rootScope.myGoBack = function () {
        $scope.$emit('$locationChangeSuccess', {});
        $ionicHistory.goBack();
    };
    $scope.$on('$viewContentLoaded', function () {
        console.log("sdgf");
    });
    $scope.$on("BindMap", function (event, data) {
        var city = '';
        if ($translate.use() == 'en') {
            city = $scope.adDetail.city_en
        }
        else {
            city = $scope.adDetail.city_ar
        }
        var lat = $scope.location_longlat.split(",")[0];
        var long = $scope.location_longlat.split(",")[1];
        if ($scope.location_longlat != '') {
            var latlng = new google.maps.LatLng(lat, long);
            var map = new google.maps.Map(document.getElementById('MapDetail'),
                {
                    zoom: 12,
                    center: latlng,
                    mapTypeControl: false,
                    streetViewControl: false,
                    panControl: false,
                    mapTypeControlOptions: { mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style'] },

                });
            var infowindow = new google.maps.InfoWindow({
                content: city
            });

            var marker = new google.maps.Marker({
                position: latlng,
                map: map
            });

            var mkID = document.getElementById('MapDetail');

            google.maps.event.addListener(marker, 'click', (function (marker, infowindow, mkID) {
                return function () {
                    if (infowindow) {
                        infowindow.close();
                    }
                    infowindow.open(map, marker);
                    infoWindowAjax(mkID, function (data) {
                        infowindow.setContent(data);
                    });
                };
            })(marker, infowindow, mkID));

            infowindow.open(map, marker);
        } else {
            document.getElementById('MapDetail').innerHTML = "No Location Found";
        }
    });

    $scope.getProductDetail = function (productId) {

        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        StoreService.productDetail(productId).then(function (res) {
            $scope.breadcrumbs = res.data.breadcrumb;
            $scope.location_longlat = res.data.adDetail.location_longlat;
            $scope.adDetail = res.data.adDetail;
            $scope.addetailstore = res.data.addetailstore;
            $scope.ProductContactNumber = res.data.adDetail.gsm;
            $scope.productDetailMainProperties = res.data.detailPageHeaderValues;
            $scope.productDetailproperties = res.data.productDetailproperties;
            $ionicSlideBoxDelegate.update();
            $scope.ProductDetail = res.data;
            $ionicLoading.hide();
            $rootScope.isShowSearchButton = false;
            //$scope.ShowDetailMapLocation();
        });
    }

    $scope.followSeller = function (addetailstore, adDetail) {
        if (addetailstore != null) {
            $state.go('app.store-follow', { url: addetailstore.url });
        }
    }

    $ionicModal.fromTemplateUrl('image-modal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function (modal) {
        $scope.modal = modal;
    });

    $scope.openModal = function (index) {
        $ionicSlideBoxDelegate.slide(index);
        $scope.modal.show();
    };

    $scope.closeModal = function () {
        $scope.modal.hide();
    };

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function () {
        $scope.modal.remove();
    });
    // Execute action on hide modal
    $scope.$on('modal.hide', function () {
        // Execute action
    });
    // Execute action on remove modal
    $scope.$on('modal.removed', function () {
        // Execute action
    });
    $scope.$on('modal.shown', function () {
        console.log('Modal is shown!');
    });

    // Call this functions if you need to manually control the slides
    $scope.next = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.previous = function () {
        $ionicSlideBoxDelegate.previous();
    };

    $scope.goToSlide = function (index) {
        $scope.modal.show();
        $ionicSlideBoxDelegate.slide(index);
    }

    $scope.pagerClick = function (index) {
        $ionicSlideBoxDelegate.slide(index);
    }

    // Called each time the slide changes
    $scope.slideChanged = function (index) {
        $scope.slideIndex = index;
    };

    function generateActionSheetButton() {
        var buttons = [];
        var button = {};
        var text = "";
        if ($translate.use() == 'en') {
            for (var i = 0; i < $scope.breadcrumbs.length; i++) {
                button = {
                    text: $scope.breadcrumbs[i].ad_en
                }
                buttons.push(button);
            }
        }
        else {
            for (var i = 0; i < $scope.breadcrumbs.length; i++) {
                button = {
                    text: $scope.breadcrumbs[i].ad_ar
                }
                buttons.push(button);
            }
        }
        return buttons;
    }

    $scope.showbreadcrumbsActionsheet = function () {
        var title = '';
        var cancelButton = '';
        if ($translate.use() == 'en') {
            title = translations_en.PickCategory;
            cancelButton = translations_en.Cancel;
        }
        else {
            title = translations_ar.PickCategory;
            cancelButton = translations_ar.Cancel;
        }
        $ionicActionSheet.show({
            titleText: title,
            buttons: generateActionSheetButton(),
            cancelText: cancelButton,
            cancel: function () {
                console.log('CANCELLED');
            },
            buttonClicked: function (index) {
                //console.log('BUTTON CLICKED', index);
                var kat_id = "";
                $rootScope.Selected = [];
                $rootScope.menuSelectedId = [];
                $rootScope.menuKatList = [];
                if ($rootScope.language == "en") {
                    for (var i = 0; i <= index; i++) {
                        kat_id += $scope.breadcrumbs[i].id + ".";

                        $rootScope.menuSelectedId.push($scope.breadcrumbs[i].id);
                        $rootScope.menuKatList.push(kat_id);
                        $rootScope.Selected.push($scope.breadcrumbs[i].ad_en);

                    }
                }
                else {
                    for (var i = 0; i <= index; i++) {
                        kat_id += $scope.breadcrumbs[i].id + ".";
                        $rootScope.menuKatList.push(kat_id);
                        $rootScope.menuSelectedId.push($scope.breadcrumbs[i].id);
                        $rootScope.Selected.push($scope.breadcrumbs[i].ad_ar);

                    }
                }
                var buttonData = $scope.breadcrumbs[index];
                if ($scope.breadcrumbs.length - 1 != index) {
                    if ($rootScope.language == "en") {
                        $rootScope.mainMenuSelected = $scope.breadcrumbs[0].ad_en;
                        $rootScope.menuMainTitle = $scope.breadcrumbs[0].ad_en;
                        $rootScope.selectedMenus = buttonData.ad_en;
                        $rootScope.selectedMenuskat_liste = kat_id;
                        $state.go("app.common-menu", { id: buttonData.id, selectedMenu: buttonData.ad_en })
                    }
                    else {
                        $rootScope.mainMenuSelected = $scope.breadcrumbs[0].ad_ar;
                        $rootScope.menuMainTitle = $scope.breadcrumbs[0].ad_ar;
                        $rootScope.selectedMenus = buttonData.ad_ar;
                        $rootScope.selectedMenuskat_liste = kat_id;
                        $state.go("app.common-menu", { id: buttonData.id, selectedMenu: buttonData.ad_ar })
                    }
                }
                else {
                    $state.go('app.search-data', { query: "", categoryId: buttonData.id, kat_liste: kat_id });
                }

                return true;
            }
        });
    };


    $scope.showActionsheet = function () {
        var title = '';
        var cancelButton = '';
        if ($translate.use() == 'en') {
            title = translations_en.CallNow;
            cancelButton = translations_en.Cancel;
        }
        else {
            title = translations_ar.CallNow;
            cancelButton = translations_ar.Cancel;
        }
        $ionicActionSheet.show({
            titleText: title,
            buttons: [
              { text: '<a href=tel:"' + $scope.ProductContactNumber + '"><i class="fa fa-phone" aria-hidden="true"></i> ' + $scope.ProductContactNumber + '</a>' },
              //{ text: '<i class="icon ion-arrow-move"></i> Move' },
            ],
            cancelText: cancelButton,
            cancel: function () {
                console.log('CANCELLED');
            },
            buttonClicked: function (index) {
                window.open('tel:' + $scope.ProductContactNumber, '_system');
            }
        });
    }

    $scope.getProductDetail($stateParams.id);

    //$ionicPlatform.onHardwareBackButton(function (event) {
    //    event.preventDefault();
    //    event.stopImmediatePropagation();

    //    //if ($state.current.name == 'app.search-data') {
    //    //    $ionicHistory.goBack(-1);
    //    //}
    //});

})