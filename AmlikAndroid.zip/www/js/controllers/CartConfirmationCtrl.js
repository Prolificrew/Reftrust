﻿
angular.module('AmlikAndroid').controller('CartConfirmationCtrl', function ($scope, $state, CartService, $translate, $ionicLoading, $cordovaInAppBrowser, $rootScope, paytabsService, MyAccountService,paytab) {
    $scope.CurrentLanguage = $translate.use();
    $scope.ConfirmationList = [];
    var ipaddress = "";
    var payTabPayPageOptions = {
        merchant_email: paytab.merchant_email,
        secret_key: paytab.secret_key,
        site_url: "https://www.amlik.com",
        return_url: "https://www.amlik.com/api/api/paytabs/PaymentReturn/" + paytab.merchant_email + "/" + paytab.secret_key + "/" + $rootScope.userId,
        msg_lang: $translate.use()=='en'?"English":"Arabic",
        cms_with_version: "API",
    }
    paytabsService.getClientIp().then(function (response) {
        ipaddress=response.ip;
    }, function (error) {
        console, log(error);
    })
    function getConfirmationList() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.getConfirmList().then(function (response) {
            console.log(response);
            $scope.ConfirmationList = response;
            $ionicLoading.hide();
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        });
    };
    function CreatePayTabPage() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        paytabsService.createPayPage(payTabPayPageOptions).then(function (response) {
            $ionicLoading.hide();
            if (response.response_code == "4012") {
                MyAccountService.UpdatePayTabStatus(response.p_id, payTabPayPageOptions.reference_no).then(function (response) {
                    console.log(response);
                }, function (error) {
                    console.log(error);
                })
                var win = window.open(response.payment_url, '_self', "location=no")
                win.addEventListener("loadstart", function (event) { });
                win.addEventListener("loadstop", function (event) {
                    if (event.url.indexOf('www.amlik.com/api/api') >= 0) {
                        win.executeScript({ code: '(function(){return document.body.innerText;})()' }, function (PaymentReference) {
                            var payRef = PaymentReference[0].replace(/['"]+/g, '');
                            win.close();
                            setTimeout(function () {
                                $state.go('app.SafeECommerce');
                            }, 1000)
                        });
                    }
                })
            } else {
                console.log(response);
            }
        }, function (error) {
            $ionicLoading.hide();
        });
    };
    function CheckPaymentConfirm(paymentReference) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        paytabsService.verifypayment(paymentReference).then(function (response) {
            console.log(response);
            $ionicLoading.hide();
            if (response.response_code == 100) {
                console.log(response.result);
                console.log(response.pt_invoice_id);
                console.log(response.amount);
                console.log(response.currency);
                console.log(response.transaction_id);
                alert("Result: " + response.result + " Invoice No.: " + response.pt_invoice_id + " Amount: " + response.amount + " currency: " + response.currency);
            }

        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        })

    }
    $scope.Confirm = function () {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        var options = {
            location: 'no',
            clearcache: 'yes',
            toolbar: 'no'
        };
        MyAccountService.GetPaytabInfo($rootScope.SelectedAddressID, ipaddress).then(function (response) {
            angular.forEach(response, function (value, key) {
                if (key != "$id") {
                    payTabPayPageOptions[key] = value;
                }
            })
            $ionicLoading.hide();
            CreatePayTabPage();
        }, function (error) {
            console.log(error);
            $ionicLoading.hide();
        })

        
    }

    getConfirmationList();
});
