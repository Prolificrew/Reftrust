﻿angular.module('AmlikAndroid').controller('mapViewDetailCtrl', function ($scope, $translate, $rootScope, $ionicHistory, PostDetailServices, $stateParams, $ionicLoading, $ionicPopup, $state, toaster) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isFooterBarShown = true;
    $rootScope.currentStep++;
    //$('.bar-footer').find('.progress-bar').width('50%')
    var map;
    var markersArray = [];
    $rootScope.locationLatLng = '';


    function initMap(_lat, _lng) {
        var latlng = null;
        if (!_lng && !_lat) {
            latlng = new google.maps.LatLng(24.266906, 45.1078489);
            $rootScope.locationLatLng = "24.266906,45.1078489";
        }
        else {
            latlng = new google.maps.LatLng(_lat, _lng);
        }
        var myOptions = {
            zoom: 14,
            center: latlng,
            mapTypeControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("mapdiv"), myOptions);

        // add a click event handler to the map object
        google.maps.event.addListener(map, "click", function (event) {
            // place a marker
            placeMarker(event.latLng);

            $rootScope.locationLatLng = event.latLng.lat() + "," + event.latLng.lng();
            //// display the lat/lng in your form's lat/lng fields
            //document.getElementById("latFld").value = event.latLng.lat();
            //document.getElementById("lngFld").value = event.latLng.lng();
        });

        placeMarker(latlng);
    }
    function placeMarker(location) {
        // first remove all markers if there are any
        deleteOverlays();

        var marker = new google.maps.Marker({
            position: location,
            map: map
        });

        // add marker in markers array
        markersArray.push(marker);
    }

    // Deletes all markers in the array by removing references to them
    function deleteOverlays() {
        if (markersArray) {
            for (i in markersArray) {
                markersArray[i].setMap(null);
            }
            markersArray.length = 0;
        }
    }

    //initMap();

    function getDeviceLocation() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        navigator.geolocation.getCurrentPosition(function (res) {
            initMap(res.coords.latitude, res.coords.longitude)
            $rootScope.locationLatLng = res.coords.latitude + "," + res.coords.longitude;
            $ionicLoading.hide();
        }, function (error) {
            initMap();
            toaster.pop({ type: 'warning', title: "", body: "unable to find your location", showCloseButton: true })
            $ionicLoading.hide();
        }, { timeout: 20000 })

    }
    if ($rootScope.userLocationLatLng) {
        var lat = $rootScope.userLocationLatLng.split(",")[0];
        var long = $rootScope.userLocationLatLng.split(",")[1];
        $rootScope.locationLatLng = $rootScope.userLocationLatLng;
        initMap(lat, long);
    }
    else {
        getDeviceLocation();
    }
    function showAlertPopup() {
        var alertPopup = $ionicPopup.alert({
            title: 'Location',
            template: 'Please select your location'
        });
        alertPopup.then(function (res) {

        });
    }

    $scope.PostLocationLatlng = function () {
        if ($rootScope.locationLatLng == '') {
            showAlertPopup();
        }
        else {
            $ionicLoading.show({
                content: 'Loading...',
                animation: 'fade-in',
                showBackdrop: true,
                maxWidth: 200,
                showDelay: 0
            });
            PostDetailServices.postAdLocation($rootScope.locationLatLng, $rootScope.PostInsertedId).then(function (res) {
                $ionicLoading.hide();
                if (res.data == true) {
                    $state.go('post.uploadImages', {});
                }

            });
        }
    }

});