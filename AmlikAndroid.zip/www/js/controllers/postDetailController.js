﻿angular.module('AmlikAndroid').directive('dynamicName', function ($compile, $parse) {
    return {
        restrict: 'A',
        terminal: true,
        priority: 100000,
        link: function (scope, elem) {
            var name = $parse(elem.attr('dynamic-name'))(scope);
            // $interpolate() will support things like 'skill'+skill.id where parse will not
            elem.removeAttr('dynamic-name');
            elem.attr('name', name);
            $compile(elem)(scope);
        }
    };
}).controller('postDetailController', function ($scope, $translate, $rootScope, $ionicHistory, PostDetailServices, $stateParams, $ionicLoading, $state) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $rootScope.isFooterBarShown = true;
    $rootScope.currentStep = 1;
    $rootScope.totalSteps = 2;
    $rootScope.PostInsertedId = '0';
    if ($stateParams.adID) {
        $rootScope.PostInsertedId = $stateParams.adID;
        $scope.formData = {
            Name: '',
            MobileNumber: '',
            AdTitle: '',
            Description: '',
            Price: '',
            isMapShown: '0'
        }
    }
    else {
        $rootScope.categoryId = parseInt($stateParams.categoryId);
        $rootScope.parentCategory = parseInt($stateParams.kat_Id.split('.')[1]);
        $rootScope.mainCategory = parseInt($stateParams.kat_Id.split('.')[0]);
    }
    $rootScope.redirectToEcommerce = false;
    $scope.formData = {
        parameters: {

        }
    };
    $scope.dynamicParamerters = {};

    $rootScope.myGoBack = function () {
        $scope.$emit('$locationChangeSuccess', {});
        $rootScope.isCustomBackButton = true;
        if ($rootScope.currentStep != 1) {
            $rootScope.currentStep--;
        }
        if ($rootScope.totalSteps == 3 && $rootScope.currentStep == 2) {
            $('.bar-footer').find('.progress-bar').width('66.66%')
        }
        else if ($rootScope.totalSteps == 3 && $rootScope.currentStep == 3) {
            $('.bar-footer').find('.progress-bar').width('100%')
        }
        else if ($rootScope.totalSteps == 3 && $rootScope.currentStep == 1) {
            $('.bar-footer').find('.progress-bar').width('33.33%')
        }
        else if ($rootScope.totalSteps == 4 && $rootScope.currentStep == 4) {
            $('.bar-footer').find('.progress-bar').width('100%')
        }
        else if ($rootScope.totalSteps == 4 && $rootScope.currentStep == 3) {
            $('.bar-footer').find('.progress-bar').width('75%')
        }
        else if ($rootScope.totalSteps == 4 && $rootScope.currentStep == 2) {
            $('.bar-footer').find('.progress-bar').width('50%')
        }
        else if ($rootScope.totalSteps == 4 && $rootScope.currentStep == 1) {
            $('.bar-footer').find('.progress-bar').width('25%')
        }
        else if ($rootScope.totalSteps == 2 && $rootScope.currentStep == 2) {
            $('.bar-footer').find('.progress-bar').width('100%')
        }
        else if ($rootScope.totalSteps == 2 && $rootScope.currentStep == 1) {
            $('.bar-footer').find('.progress-bar').width('50%')
        }
        else {
            //$('.bar-footer').find('.progress-bar').width('66.66%')
        }

        $ionicHistory.goBack(-1);
    };

    function loadPostDetailFields(categoryId, kat_Id) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        PostDetailServices.getAllPostDetailFields(categoryId, kat_Id).then(function (res) {
            $scope.postDetailFields = res.data;
            if ($stateParams.adID) {
                loadEditPostDetailFields($stateParams.adID);
            }
            if (res.data.storeModel != null) {
                $rootScope.IsEcommerce = res.data.storeModel.isEcommerce;
                $rootScope.IsCorporate = res.data.storeModel.isCorporate;
            }
            else {
                $rootScope.IsEcommerce = false;
                $rootScope.IsCorporate = true;
            }
            if (($rootScope.selectedMenusSubMenusId[0] == "6" || $rootScope.selectedMenusSubMenusId[0] == "9") && $rootScope.IsEcommerce == true && $rootScope.IsCorporate == true) {
                $rootScope.totalSteps++;
                $rootScope.redirectToEcommerce = true;
                $('.bar-footer').find('.progress-bar').width('33.33%')
            } else {
                $('.bar-footer').find('.progress-bar').width('50%')
            }
            if (!$stateParams.adID) {
                $ionicLoading.hide();
            }
        });
    }

    function loadEditPostDetailFields(adId) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        PostDetailServices.getAllEditPostDetailFields(adId).then(function (res) {
            $scope.formData.Name = res.data.surname;
            $scope.formData.MobileNumber = res.data.gsm;
            $scope.formData.AdTitle = res.data.adTitle;
            $scope.formData.Description = res.data.description;
            $scope.formData.Price = res.data.price;
            $scope.formData.Location = res.data.city;
            if (res.data.mapUsed == 1) {
                $rootScope.userLocationLatLng = res.data.map_input;
                $scope.formData.isMapShown = res.data.mapUsed;
                $rootScope.totalSteps++;
                $('.bar-footer').find('.progress-bar').width('33.33%')
            }
            else {
                $scope.formData.isMapShown = res.data.mapUsed;
            }
            $rootScope.userUploadedImages = res.data.images;
            for (var i = 0; i < $scope.postDetailFields.dynanicFields.length; i++) {
                if ($scope.postDetailFields.dynanicFields[i].tur == 1) {
                    $scope.formData.parameters[$scope.postDetailFields.dynanicFields[i].id] = parseInt(res.data.dynanicFields[i].value);
                } else {
                    $scope.formData.parameters[$scope.postDetailFields.dynanicFields[i].id] = res.data.dynanicFields[i].value;
                }
            }


            $ionicLoading.hide();
        });
    }

    $scope.postAdDetailFormData = function (data) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        var isMapUsed;
        if (data.isMapShown == true) {
            isMapUsed = 1;
        } else {
            isMapUsed = 0;
        }
        var dynanicFields = {
            kat_url: '',
            main_cat: parseInt($stateParams.kat_Id.split('.')[0]),
            kat_liste: $stateParams.kat_Id,
            parentCategory: parseInt($stateParams.kat_Id.split('.')[1]),
            categoryId: parseInt($stateParams.categoryId),
            adTitle: data.AdTitle,
            description: data.Description,
            price: parseInt(data.Price),
            surname: data.Name,
            gsm: data.MobileNumber,
            city: parseInt(data.Location),
            map_input: '',
            adPostId: parseInt($rootScope.PostInsertedId),
            mapUsed: isMapUsed,
            culture: $translate.use(),
            userId: '',
            IsEcommerce: 0,
            DynanicFields: []
        };

        if (data.parameters) {
            angular.forEach(data.parameters, function (value, key) {
                dynanicFields.DynanicFields.push({ id: parseInt(key), value: value.toString() });
            });
        }

        PostDetailServices.postAdInsertion(dynanicFields).then(function (res) {
            $rootScope.PostInsertedId = res.data.insertedid;
            if (data.isMapShown == true) {
                $state.go('post.mapViewDetail', {});
            }
            else {
                $state.go('post.uploadImages', {});
            }
            $ionicLoading.hide();
        });



    }

    $scope.UsedMapViewChanges = function (isMapShown) {
        if (isMapShown == true && $rootScope.redirectToEcommerce == true) {
            $('.bar-footer').find('.progress-bar').width('25%')
        } else if (isMapShown == true) {
            $('.bar-footer').find('.progress-bar').width('33.33%')
        }
        else if ($rootScope.redirectToEcommerce) {
            $('.bar-footer').find('.progress-bar').width('33.33%')
        } else {
            $('.bar-footer').find('.progress-bar').width('50%')
        }

        if (isMapShown) {
            $rootScope.totalSteps++;
        } else {
            $rootScope.totalSteps--;
        }
    }

    loadPostDetailFields($stateParams.categoryId, $stateParams.kat_Id);

});