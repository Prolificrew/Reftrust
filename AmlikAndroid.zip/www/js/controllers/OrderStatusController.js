﻿angular.module('AmlikAndroid').controller("OrderStatusController", function ($scope, $rootScope) {

})