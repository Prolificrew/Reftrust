﻿angular.module('AmlikAndroid').directive('swipeRight', ['$ionicGesture', function ($ionicGesture) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            $ionicGesture.on('swiperight', function (e) {
                var content = element[0].querySelector('.item-content');
                var buttons = element[0].querySelector('.item-options');
                var buttonsWidth = buttons.offsetWidth;

                $(buttons).parent().parent().find(".item-options").addClass('invisible');
                var contentList = $(content).parent().parent().find(".item-content");

                angular.forEach(contentList, function (obj) {
                    obj.style[ionic.CSS.TRANSFORM] = '';
                })
                //debugger;
                ionic.requestAnimationFrame(function () {
                    content.style[ionic.CSS.TRANSITION] = 'all ease-out .25s';

                    if (!buttons.classList.contains('invisible')) {
                        content.style[ionic.CSS.TRANSFORM] = '';
                        setTimeout(function () {
                            buttons.classList.add('invisible');
                        }, 250);
                    } else {
                        buttons.classList.remove('invisible');
                        content.style[ionic.CSS.TRANSFORM] = 'translate3d(' + buttonsWidth + 'px, 0, 0)';
                    }
                });

            }, element);
            $ionicGesture.on('swipeleft', function (e) {
                var content = element[0].querySelector('.item-content');
                var buttons = element[0].querySelector('.item-options');
                var buttonsWidth = buttons.offsetWidth;

               
                var contentList = $(content).parent().parent().find(".item-content");

                angular.forEach(contentList, function (obj) {
                    obj.style[ionic.CSS.TRANSFORM] = '';
                })
                $(buttons).parent().parent().find(".item-options").addClass('invisible');
                ////debugger;
                //ionic.requestAnimationFrame(function () {
                //    content.style[ionic.CSS.TRANSITION] = 'all ease-out .25s';

                //    if (!buttons.classList.contains('invisible')) {
                //        content.style[ionic.CSS.TRANSFORM] = '';
                //        setTimeout(function () {
                //            buttons.classList.add('invisible');
                //        }, 250);
                //    } else {
                //        buttons.classList.remove('invisible');
                //        content.style[ionic.CSS.TRANSFORM] = 'translate3d(' + buttonsWidth + 'px, 0, 0)';
                //    }
                //});

            }, element);
        }
    };
}]).controller('CartDetailCtrl', function ($scope, $translate, $stateParams, $rootScope, $ionicLoading, $ionicModal, $ionicListDelegate, CartService, $ionicPopup) {
    $scope.editCartItem = {};
    $scope.CurrentLanguage = $translate.use()
    $scope.totalAmount = 0;
    $scope.delete = function (item) {
        var confirmPopup = $ionicPopup.confirm({
            title: $translate.instant('Confirm'),
            template: $translate.instant('CartItemRemoveConfirmMessage'),
            cssClass: $translate.use() == 'ar' ? 'textDirection' : '',
            okText: $translate.instant('ConfirmOk'),
            cancelText: $translate.instant('ConfirmCancel')
        });
        $ionicListDelegate.closeOptionButtons();
        confirmPopup.then(function (res) {
            if (res) {

                $ionicLoading.show({
                    content: 'Loading...',
                    animation: 'fade-in',
                    showBackdrop: true,
                    maxWidth: 200,
                    showDelay: 0
                });
                CartService.deleteCart(item.id).then(function (response) {
                    if (response == true) {
                        var index = $scope.CartItems.map(function (elem) { return elem.id }).indexOf(item.id);
                        $scope.CartItems.splice(index, 1);
                        $rootScope.CartCount = $scope.CartItems.length;
                        calculateTotalAmount();
                    }
                    $ionicLoading.hide();
                }, function (error) {
                    $ionicLoading.hide();
                })
                console.log('You are sure');
            } else {
                console.log('You are not sure');
            }
        });
    };
   
    $scope.edit = function (item) {
        $scope.editCartItem = angular.copy(item);
        $ionicListDelegate.closeOptionButtons();
        $ionicModal.fromTemplateUrl('edit-popup-template.html', {
            // Use our scope for the scope of the modal to keep it simple
            scope: $scope,
            // The animation we want to use for the modal entrance
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.editCartItemModal = modal;
            $scope.editCartItemModal.show();
        });

    }
    $scope.editCancel = function () {
        $scope.editCartItemModal.hide();
        setTimeout(function () {
            $scope.editCartItem = {}
        }, 500);

    }
    $scope.updateCartItem = function () {
        //console.log($scope.editCartItem)

        CartService.updateCart($scope.editCartItem).then(function (response) {
            if (response == true) {
                var index = $scope.CartItems.map(function (elem) { return elem.id }).indexOf($scope.editCartItem.id);
                $scope.CartItems[index] = $scope.editCartItem;
                calculateTotalAmount();
                $scope.editCartItemModal.hide();
            }
        })



    }
    function getCartList() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        CartService.getCartList().then(function (response) {
            // console.log(response);
            $scope.CartItems = response;
            calculateTotalAmount();
            $ionicLoading.hide();
        }, function (error) {
            console.log(error);
            $ionicLoading.hide();
        })
    }
    function calculateTotalAmount() {
        $scope.totalAmount = 0;
        angular.forEach($scope.CartItems, function (obj) {
            $scope.totalAmount += obj.adet * obj.birim_fiyat;
        })
    }
    //calculateTotalAmount();
    //getCartList();
    if ($stateParams.id) {
        CartService.addCart($stateParams.id).then(function (response) {
            $scope.CartItems = response;
            $rootScope.CartCount = response.length;
            calculateTotalAmount();
        }, function (error) {
            console.log(error);
        })
    } else {
        getCartList();
    }
    $scope.testSwipeRight = function (index) {
        event.preventDefault();
        event.stopImmediatePropagation();
        var divContent = angular.element(document.getElementsByClassName('item-content'));
        var divOptionButtons = angular.element(document.getElementsByClassName('item-options'));
        $(divContent).css("transform", "translate3d(0px, 0px, 0px)").css("left", '0px');
        $(divOptionButtons).addClass("invisible").css({ "right": '0px', 'left': 'unset' });
        $(divOptionButtons[index]).removeClass("invisible").css({ "right": 'unset', 'left': '0px' });
        $(divContent[index]).css("transform", "translate3d(104px, 0px, 0px)").css("left", '104px');

    }
    $scope.testSwipeLeft = function (index) {

    }
})