﻿angular.module('AmlikAndroid').controller('PostAdCtrl', function ($scope, $state, $translate, $rootScope, AuthService, $ionicLoading, $ionicPopup, $cordovaOauth, $http, $ionicHistory, $stateParams, $ionicPlatform) {
    window.cordovaOauth = $cordovaOauth;
    $scope.curlang = $translate.use();
    $scope.ExternalHtml = '';
    $rootScope.language = $translate.use();
    $rootScope.isLogoShown = false;
    $rootScope.isShownMapButton = false;
    $rootScope.isShownListingButton = false;
    $rootScope.isShownMapsButton = false;
    $scope.isLoginShow = true;
    $scope.isRegisterShow = false;
    $scope.ShowErrorMessage = false;
    $scope.ShowErrorClass = 'has-error';
    $scope.errorMessage = '';
    $scope.data = {};
    $scope.Facebook = {email:''}
    $scope.loginStatus = 'disconnected';
    $scope.passwordType = 'password';
    $scope.registrationPasswordType = 'password';
    $scope.isShowPassword = false;
    $scope.isShowRegistrationPassword = false;
    $scope.facebookIsReady = false;
    $scope.user = null;
    $scope.register = { Gender: 'Mr.', Name: '', Email: '', Passowrd: '', isfirm: 'Individual', Culture: $translate.use() };
    $scope.isRegisterErrorMessageShow = false;
    $scope.registerErrorMessage = '';
    $scope.emptyRegister = function () {
        $scope.register = { Gender: 'Mr.', Name: '', Email: '', Passowrd: '', isfirm: 'Individual', Culture: $translate.use() };
    };
    $scope.closePostAd = function () {
        //$state.go('app.home');
        $state.go($stateParams.previousState,JSON.parse($stateParams.fromParams));
        //$ionicHistory.goBack(-1);
    }
    $scope.ShowPassword = function () {
        $scope.isShowPassword = !$scope.isShowPassword;
        if ($scope.isShowPassword) {
            $scope.passwordType = 'text';
        }
        else {
            $scope.passwordType = 'password';
        }
    }
    $scope.ShowRegistrationPassword = function () {
        $scope.isShowRegistrationPassword = !$scope.isShowRegistrationPassword;
        if ($scope.isShowRegistrationPassword) {
            $scope.registrationPasswordType = 'text';
        } else {
            $scope.registrationPasswordType = 'password';
        }
    }
    
    //facebook
    function displayData($http, access_token) {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        $http.get("https://graph.facebook.com/v2.2/me", { params: { access_token: access_token, fields: "name,email", format: "json" } }).then(function (result) {
            $rootScope.fullName==result.data.name;
            if (result.data.email == undefined) {
                $ionicLoading.hide()
                $scope.Facebook.email = "";
                var popup = $ionicPopup.show({
                    templateUrl: 'popup-template.html',
                    title: $translate.instant('EnterEmailid'),
                    cssClass: $translate.use()=="en"?'FacebookEmail':'FacebookEmail textDirection',
                    subTitle: $translate.instant('UnableToAccessYourEmailId'),
                    scope: $scope,
                    buttons: [
                      { text: 'Cancel' },
                      {
                          text: '<b>Save</b>',
                          type: 'button-positive',
                          onTap: function (e) {
                              if (!$scope.Facebook.email) {
                                  //don't allow the user to close unless he enters wifi password
                                  e.preventDefault();
                              } else {

                                  return $scope.Facebook.email;
                              }
                          }
                      }
                    ]
                });
                popup.then(function (response) {
                    popup.close();
                    AuthService.LoginWithFacebook({ ExternalAccessToken: access_token, UserName: response, Provider: 'Facebook', Email: response }).then(function (response) {
                        //$state.go('post.postAdupload');
                        console.log(response);
                        $ionicLoading.hide();
                        $state.go($stateParams.redirectState, JSON.parse($stateParams.params))
                    }, function (error) {
                        $scope.ShowErrorMessage = true;
                        $scope.errorMessage = error.message;
                        $scope.ShowErrorClass = 'has-error';
                        $ionicLoading.hide();
                    })
                })
            } else {
                AuthService.LoginWithFacebook({ ExternalAccessToken: access_token, UserName: result.data.email, Provider: 'Facebook', Email: result.data.email }).then(function (response) {
                    //$state.go('post.postAdupload');
                    $state.go($stateParams.redirectState, JSON.parse($stateParams.params))
                    $ionicLoading.hide();
                }, function (error) {
                    $scope.ShowErrorMessage = true;
                    $scope.errorMessage = error.message;
                    $scope.ShowErrorClass = 'has-error';
                    $ionicLoading.hide();
                })
            }
        }, function (error) {
            console.log("Error: " + error);

        });
    }
    $scope.loginWirhFB = function () {
        $scope.ShowErrorMessage = false;
        $scope.errorMessage = '';
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        $cordovaOauth.facebook("819578041436318", ["email", "public_profile"], { redirect_uri: "https://www.facebook.com/connect/login_success.html" }).then(function (result) {
           
            $ionicLoading.hide();
            displayData($http, result.access_token);

        }, function (error) {
            $ionicLoading.hide();
            console.log("Error: " + error);
        });
    };
    // end Facebook
    $scope.login = function () {
        $scope.ShowErrorMessage = false;
        $scope.errorMessage = '';
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        AuthService.Login($scope.data).then(function (response) {
            $ionicLoading.hide();
            //$state.go('post.postAdupload');
            $state.go($stateParams.redirectState, JSON.parse($stateParams.params))
            
        },
            function (error) {

                $scope.ShowErrorMessage = true;
                $scope.errorMessage = error.error_description;
                $ionicLoading.hide();
            })
    };
    $scope.RegisterUser = function () {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        $scope.isRegisterErrorMessageShow = false;
        $scope.registerErrorMessage = '';
        AuthService.Register($scope.register).then(function (response) {
            $scope.isLoginShow = true;
            $scope.isRegisterShow = false;
            $scope.ShowErrorMessage = true;
            $scope.errorMessage = $translate.instant('Success');
            $scope.ShowErrorClass = 'has-success';
            $scope.emptyRegister();
            $ionicLoading.hide();
        }, function (error) {
            $scope.isRegisterErrorMessageShow = true;
            $scope.registerErrorMessage = error.message;
            $ionicLoading.hide();
        })
    };
    $scope.ShowRegisterForm = function () {
        $scope.isLoginShow = false;
        $scope.isRegisterShow = true;
    }
    $scope.ShowLoginForm = function () {
        $scope.isLoginShow = true;
        $scope.isRegisterShow = false;
    }

})