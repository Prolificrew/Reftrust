﻿angular.module('AmlikAndroid').controller("MyFavoritesController", function ($scope, $rootScope, AuthService, $state, $ionicSlideBoxDelegate, $ionicPopup, $ionicModal, MyAccountService, $ionicLoading) {
    $scope.currentSlider = 0;
    $scope.favrotiesList = [];
    $scope.isDeleteShow = false;

    $scope.slideChanged = function (index) {
        $scope.currentSlider = index;
        $ionicSlideBoxDelegate.slide(index);
        moveScroll();
    };
    $scope.myActiveSlide = 0;

    $scope.DeleteOption = function () {
        if ($ionicSlideBoxDelegate.selected() === 0) {
            $scope.isDeleteShow = !$scope.isDeleteShow;
        }
    }

    //debugger;
    var listofTabs = $(".management-tab-container").children();
    var width = 0;
    for (var i = 0; i < listofTabs.length; i++) {
        width += $(listofTabs[i]).width();
    }
    $(".management-tab-container").css("width", width + 'px');

    function moveScroll() {
        if ($ionicSlideBoxDelegate.selected()) {
            var CurrentTab = $(".management-tab[rel=" + $ionicSlideBoxDelegate.selected() + "]").position();
            $('.management-Slider-tabs').scrollLeft(CurrentTab.left);
        } else {
            $('.management-Slider-tabs').scrollLeft(0);
        }

    }
    function init() {
        $ionicLoading.show({
            content: 'Loading...',
            animation: 'fade-in',
            showBackdrop: true,
            maxWidth: 200,
            showDelay: 0
        });
        MyAccountService.GetFavoriteAds().then(function (response) {
            console.log(response)
            $scope.favrotiesList = response;
            $ionicLoading.hide();
        }, function (error) {
            console.log(error)
            $ionicLoading.hide();
        })
    }
    init();

});