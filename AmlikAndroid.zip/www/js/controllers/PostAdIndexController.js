﻿angular.module('AmlikAndroid').controller("PostAdIndexController", function ($scope, $state, $ionicHistory) {
   
    $scope.closePostAd = function () {
        var historyId = $ionicHistory.currentHistoryId();
        var keyList = Object.keys($ionicHistory.viewHistory().histories);
        if (keyList.length > 1) {
            var index = keyList.map(function (elem) { return elem }).indexOf(historyId)
            keyList.splice(index, 1);
        }
        var history = $ionicHistory.viewHistory().histories[historyId];
        var targetViewIndex = history.stack.length - 1;
        if (history.stack[targetViewIndex].stateName != $ionicHistory.viewHistory().currentView.stateName) {
            $ionicHistory.backView(history.stack[targetViewIndex]);
        } else {
            var history = $ionicHistory.viewHistory().histories[keyList[0]];
            var targetViewIndex = history.stack.length - 1;
            $ionicHistory.backView(history.stack[targetViewIndex]);
        }
        $ionicHistory.goBack();
    }
});