﻿angular.module('AmlikAndroid', ['pascalprecht.translate']).controller('AppCtrl', ['$scope', '$rootScope', '$state', '$stateParams', '$translate', function ($scope, $rootScope, $state, $stateParams, $translate) {
    $scope.curlang = $translate.use();
    $rootScope.language = $translate.use();
    $scope.changeLanguage = function (key) {
        $rootScope.language = key;
        $translate.use(key);
        $scope.curlang = key;
        $scope.closeDrawer();
    };

    $scope.clearArray = function () {
        $scope.closeDrawer();
    }

}])