﻿angular.module('AmlikAndroid').controller("AdManagementProductDetailController", function ($scope, $rootScope, AuthService, $state, $ionicSlideBoxDelegate, $ionicPopup, $ionicModal, MyAccountService, $ionicLoading, $stateParams) {
    $scope.product = {
        title: 'Product Title',
        img: '/img/dummy-item.jpg',
        price: '10000',
        id: '222222',
        favourities: '5',
        messages: '3',
        views: '10',
        endDate:new Date('05/05/2017')
    };


});