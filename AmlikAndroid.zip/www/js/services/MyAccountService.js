﻿angular.module('AmlikAndroid').factory('MyAccountService', function ($http, $translate, $q, baseUrl, AuthService, $rootScope) {
    var token = AuthService.GetAccessToken();
    $rootScope.$on('tokenChange', function (event,newToken) {
        token = newToken;
    })
    return {
        getPublishedAd: function (pubAdsPageNo) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/PublishedAdds/'+pubAdsPageNo,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getNonPublishedAd: function (nonPubAdsPageNo, orderType) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/NonPublishedAdds/'+nonPubAdsPageNo+"/"+orderType,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetFavoriteAds: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetFavoriteAds',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetInboxMessages: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetInboxMessages',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetOutboxMessages: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetOutboxMessages',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetMessageDetails: function (Adid,SenderId,ReceiverId) {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetMessageDetails/' + SenderId + '/' + ReceiverId + '/' + Adid,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        SendMessage: function (_data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'UserAccount/SendMessage',
                data:_data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        GetAccountPurchaseTransactions: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetAccountTransactions',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
         GetAccountSoldTransactions: function () {
            var deferred = $q.defer();
            $http({
                method: 'GET',
                url: baseUrl + 'UserAccount/GetEcommerceTransactions',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
         },
         GetPaytabInfo: function (addressId,ipAddress) {
             var deferred = $q.defer();
             $http({
                 method: 'POST',
                 url: baseUrl + 'UserAccount/GetPayTabInfo',
                 data: { userIpAddress: ipAddress, addressId: addressId },
                 headers: {
                     'Content-Type': 'application/json',
                     'Authorization': 'bearer ' + token.access_token
                 }
             }).success(function (response) {
                 deferred.resolve(response);
             }).error(function (response) {
                 deferred.reject(response);
             })
             return deferred.promise;
         },
         UpdatePayTabStatus: function (paytabId, orderId) {
             var deferred = $q.defer();
             $http({
                 method: 'GET',
                 url: baseUrl + 'UserAccount/UpdatePayTabStatus/' + paytabId + '/' + orderId,
                 headers: {
                     'Content-Type': 'application/json',
                     'Authorization': 'bearer ' + token.access_token
                 }
             }).success(function (response) {
                 deferred.resolve(response);
             }).error(function (response) {
                 deferred.reject(response);
             })
             return deferred.promise;
         },
        ChangePassword: function (_data) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: baseUrl + 'UserAccount/ChangePassword',
                data:_data,
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
    }
})