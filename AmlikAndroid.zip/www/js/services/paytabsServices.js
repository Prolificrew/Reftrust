﻿angular.module('AmlikAndroid').factory('paytabsService', function ($http, $q, paytab) {
    var PayTabsApiURl = 'https://www.paytabs.com/apiv2/'
    return {
        checkSecretKey: function () {
            var _data = { merchant_email: paytab.merchant_email, secret_key: paytab.secret_key }
            //debugger;
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: PayTabsApiURl + 'validate_secret_key',
                data: $.param(_data),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        createPayPage: function (_data) {
            var deferred = $q.defer();
            $http.post(PayTabsApiURl + 'create_pay_page',
                $.param(_data),
                {headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        getClientIp: function () {
            var deferred = $q.defer();
            $http({
                method: 'get',
                url: 'http://ipv4.myexternalip.com/json',
            }).success(function (response) {
                deferred.resolve(response);
            }).error(function (response) {
                deferred.reject(response);
            })
            return deferred.promise;
        },
        verifypayment: function (refrenceNo) {
            var _data = { merchant_email: paytab.merchant_email, secret_key: paytab.secret_key, payment_reference: refrenceNo }
            var deferred = $q.defer();
            $http.post(PayTabsApiURl + 'verify_payment',
                $.param(_data),
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }).success(function (response) {
                    deferred.resolve(response);
                }).error(function (response) {
                    deferred.reject(response);
                })
            return deferred.promise;
        }
    }
});