﻿
angular.module('AmlikAndroid').factory('PostDetailServices', function ($http, $translate, AuthService, baseUrl,$rootScope) {
    var postAdDetails = [];
    var baseURL = baseUrl;
    var token = AuthService.GetAccessToken();
    $rootScope.$on('tokenChange', function (event,newToken) {
        token = newToken;
    })
    return {
        getAllPostDetailFields: function (categoryId, kat_id) {
            var data = {
                "id": categoryId,
                "kat_liste": kat_id
            }

            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }

            return $http.post(baseURL + "Postadd/PostaddDetail", data, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        postAdInsertion: function (dynanicFields) {

            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }

            return $http.post(baseURL + "Postadd/PostaddSubmitClick", dynanicFields, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        postAdLocation: function (locationLatLng, AdId) {
            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }
            var data = {
                "id": AdId,
                "location_longlat": locationLatLng
            }

            return $http.post(baseURL + "Postadd/PostaddMapSave", data, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        postAdImages:function(data){
            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }
            return $http.post(baseURL + "Postadd/PostaddSaveImages", data, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        postAdEcommerce:function(data){
            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }
            return $http.post(baseURL + "Postadd/IsEcommerceTab", data, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        getAllEditPostDetailFields: function (adId) {
            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }
            return $http.get(baseUrl + "Postadd/GetPostaddDetails/" + adId, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        deleteUploadedImageById: function (imageId) {
            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }
            return $http.get(baseUrl + "Postadd/DeleteUploadedImage/" + imageId, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        },
        updateSelectedImage: function (imageId, ilanId) {
            var config = {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'bearer ' + token.access_token
                }
            }
            return $http.get(baseUrl + "Postadd/UpdateSelectedImage/" + imageId + "/" + ilanId, config).then(function (response) {
                postAdDetails = response;
                return postAdDetails;
            });
        }
};
})