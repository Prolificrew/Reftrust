﻿angular.module('AmlikAndroid').factory('StoreService', function ($http, $translate,baseUrl) {
    var storeData = [];
    //var baseURL = "http://131.72.139.186:10143/api/homepages/HomeAllAdvs/";
    var baseURL =baseUrl;
    //var baseURL = "http://localhost:51814/api/";

    return {
        getStore: function (pageNo) {

            return $http.get(baseURL + "homepages/HomeAllAdvs/" + pageNo).then(function (response) {
                storeData = response;
                return storeData;
            });
        },
        getStoreDetail: function (pageNo) {

            return $http.get(baseURL + "homepages/Stores/" + pageNo).then(function (response) {
                storeData = response;
                return storeData;
            });
        },
        getSearched: function (obj) {
            return $http.post(baseURL + "Search/SearchPageDataList", obj).then(function (response) {
                storeData = response;
                return storeData;
            });
        },
        
        getURLbasedData: function (url, pageno) {
            return $http.get(baseURL + "Search/GetkategoriUrlData/" + url + "/" + pageno).then(function (response) {
                storeData = response;
                return storeData;
            });
        },
        storeDetail: function (url) {
            return $http.get(baseURL + "Store/StoreDetail/" + url).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getStoreList: function (url, pageno) {
            return $http.get(baseURL + "Store/StorePageData/" + url + "/" + pageno).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        productDetail: function (id) {
            return $http.get(baseURL + "AdvDetail/DetailPageDataByid/" + id).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getFilterDetail: function (filterObj) {
            return $http.post(baseURL + "Search/SearchPageAlltagsdata", filterObj).then(function (response) {
                storeData = response;
                return storeData;
            });

        },
        getAllLocations: function (locationObj) {
            return $http.post(baseURL + "Search/SearchPageDataListMap", locationObj).then(function (response) {
                storeData = response;
                return storeData;
            });

        }

    };
});