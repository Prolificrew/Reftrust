﻿
angular.module('AmlikAndroid').factory('Search', function ($http, $translate,baseUrl) {
    var realStateMenu = [];
    var baseURL = baseUrl + "Navigations/menu/";
    var menuURL = baseUrl+"Navigations/menu/0";
    var searchURL = baseUrl+"Search/GetSearchPopupData";
    return {
        realStateSubMenus: function () {

            return $http.get(baseURL + "5").then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        vehicleMenus: function () {

            return $http.get(baseURL + "1").then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        commonMenu: function (id) {

            return $http.get(baseURL + id).then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        resSubMenus: function (id) {

            return $http.get(baseURL + id).then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        estateOtherSubMenus: function (id) {
            return $http.get(baseURL + id).then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        getAllMenu: function () {
            return $http.get(menuURL).then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        getChildMenuCount: function () {
            //return $http.get(menuURL).then(function (response) {
            //    realStateMenu = response;
            //    return realStateMenu;
            //});
        },
        getSearch: function (searchtext, Culture) {
            return $http.get(searchURL + "/" + searchtext + "/" + Culture).then(function (response) {
                realStateMenu = response;
                return realStateMenu;
            });
        },
        searchByText: function (searchtext, Culture) {
            return $http.get(baseUrl + "Search/PostAddSearchCategory/" + searchtext + "/" + Culture).then(function (response) {
                data = response;
                return data;
            });
        }
    };
})