// Ionic Starter App, v0.9.20

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'AmlikAndroid.services' is found in services.js
// 'AmlikAndroid.controllers' is found in controllers.js


//var baseUrlForToken = 'http://131.72.139.186:10143';
//var baseUrl = "http://131.72.139.186:10143/api/";

//var baseUrlForToken = 'https://www.amlik.com/api';
//var baseUrl = "https://www.amlik.com/api/api/";

var baseUrlForToken = 'https://www.amlik.com/apitest';
var baseUrl = 'https://www.amlik.com/apitest/api/';

angular.module('AmlikAndroid', ['ionic', 'AmlikAndroid.controllers', 'AmlikAndroid.services', 'ionic.contrib.drawer', 'tabSlideBox', 'ngCordova', 'ngCordovaOauth', 'ngAnimate', 'toaster', 'ngSanitize'])

.run(function ($ionicPlatform, $cordovaSQLite, $rootScope, $window, toaster, $state) {

    $ionicPlatform.ready(function () {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
            ionic.Platform.fullScreen(true, false);
        }
        setTimeout(function () {
            navigator.splashscreen.hide();
        }, 100);


        window.addEventListener('native.keyboardhide', function () {
            //ionic.Platform.fullScreen(true, false);
        });
        window.addEventListener('native.keyboardshow', function () {
            //StatusBar.hide();
        });
        $rootScope.online = navigator.onLine;
        var isloadData = false;
        $window.addEventListener("offline", function () {
            $rootScope.$apply(function () {
                $("#toast-container").removeClass('toast-top-right');
                toaster.clear();
                toaster.wait({ title: "", body: "No Internet Connection, Try later.." });
            });
        }, false);

        var GoogleMapScript = document.createElement("script")
        GoogleMapScript.src = "http://maps.googleapis.com/maps/api/js?sensor=false"


        $window.addEventListener("online", function () {
            $rootScope.$apply(function () {
                toaster.clear();
                //debugger;
                if ($state.current.name == "app.home" && isloadData) {
                    $rootScope.loadMoreData();
                    $rootScope.loadCategories();
                    $rootScope.CartCountFunction();
                }
                //debugger;
                var link = document.querySelector('link[src="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"]')
                var script = document.querySelector('script[src="http://maps.googleapis.com/maps/api/js?sensor=false"]')
                if (!link) {
                    var createLink = document.createElement("link");
                    createLink.src = "http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css";
                    createLink.rel = "stylesheet";
                    document.getElementsByTagName("head")[0].appendChild(createLink);
                    document.getElementsByTagName("head")[0].appendChild(GoogleMapScript);
                }
            });
        }, false);
        if (Connection) {
            if (navigator.network.connection.type == Connection.NONE) {
                isloadData = true;
                $("#toast-container").removeClass('toast-top-right');
                toaster.clear();
                toaster.wait({ title: "", body: "No Internet Connection, Try later.." });
            } else {
                document.getElementsByTagName("head")[0].appendChild(GoogleMapScript);
            }
        }

    });
})
.constant('baseUrl', baseUrl)
    .constant('paytab', {
        merchant_email: 'i.alsanousi@amlik.com',
        secret_key: 'd0IVxPhyeZzE8S3pv3S0aqxBhn26cywpzek64CFiCeXL60bC43Cfu9RMxUTJsp92Eu8I7O1K2Yv9ZGL4Kojeyb155UPxkZzYuIHB'
    }).constant('baseUrlForToken', baseUrlForToken)
    .constant('ngAuthSetting', { clientId: 'Amlik' })
    .config(function ($ionicConfigProvider) {
        if (ionic.Platform.isAndroid())
            $ionicConfigProvider.scrolling.jsScrolling(false);
        // $ionicConfigProvider.views.maxCache(0);
    })
    .config(function ($translateProvider) {
        $translateProvider.translations('en', translations_en);
        $translateProvider.translations('ar', translations_ar);
        if (!localStorage.getItem('UserLanguage')) {
            $translateProvider.preferredLanguage('en');
        } else {
            $translateProvider.preferredLanguage(localStorage.getItem('UserLanguage'));
        }
        
        // console.log("$translateProvider initialized");
    })

.config(function ($stateProvider, $urlRouterProvider) {

    $stateProvider
      .state('app', {
          url: "/app",
          abstract: true,
          templateUrl: "templates/menu.html",
          controller: 'AppCtrl'
      })
     .state('post', {
         url: '/apppostAdd',
         abstract: true,
         templateUrl: "templates/PostAdIndex.html",
         controller: 'PostAdIndexController'
     })
      .state('app.search', {
          url: "/search",

          templateUrl: "templates/search.html",
          controller: 'SearchCtrl'


      })
        .state('post.postAdupload', {
            url: '/postAdupload',
            data: {
                required: true
            },
            reload: true,
            cache:false,
            views: {
                'PostAd': {
                    templateUrl: 'templates/postAd.html',
                    controller: 'PostAdController',

                }
            }

        })
        .state('post.postDetail', {
            url: '/postDetail/:categoryId/:kat_Id/:adID',
            data: {
                required: true
            },
            reload: true,
            cache: false,
            views: {
                'PostAd': {
                    templateUrl: 'templates/postDetail.html',
                    controller: 'postDetailController'
                }
            }
        }).state('post.uploadImages', {
            url: '/uploadImages',
            reload: true,
            cache: false,
            data: {
                required: true
            },
            views: {
                'PostAd': {
                    templateUrl: 'templates/uploadImages.html',
                    controller: 'uploadImagesCtrl'
                }
            }
        })
        .state('post.mapViewDetail', {
            url: '/mapViewDetail',
            data: {
                required: true
            },
            reload: true,
            cache: false,
            views: {
                'PostAd': {
                    templateUrl: 'templates/mapViewDetail.html',
                    controller: 'mapViewDetailCtrl'
                }
            }
        })
        .state('post.eCommerce', {
            url: '/eCommerce',
            data: {
                required: true
            },
            reload: true,
            cache: false,
            views: {
                'PostAd': {
                    templateUrl: 'templates/e-commerce.html',
                    controller: 'PostAdEcommerceCtrl'
                }
            }
        })
        .state('postAd', {
            url: "/postAd/:redirectState/:params/:previousState/:fromParams",
            templateUrl: "templates/app-postAd.html",
            controller: 'PostAdCtrl',
            reload: true,
            cache: false,

        })

        .state('app.savedSearch', {
            url: "/savedSearch",
            views: {
                'menuContent': {
                    templateUrl: "templates/savedSearch.html",
                    controller: 'savedSearchCtrl'
                }
            }
        })

        .state('app.menus', {
            url: "/menus/:id",
            views: {
                'menuContent': {
                    templateUrl: "templates/CommonMenus/commonMenus.html",
                    controller: 'MenuCommonCtrl'
                }
            }
        }).state('app.cart', {
            url: "/cart/:id",
            data: {
                required: true
            },
            views: {
                'menuContent': {
                    templateUrl: "templates/app-cartdetail.html",
                    controller: 'CartDetailCtrl'
                }
            }
        }).state('app.cartAddress', {
            url: "/cartAddress",
            data: {
                required: true
            },
            reload: true,
            views: {
                'menuContent': {
                    templateUrl: "templates/app-cartAddress.html",
                    controller: 'CartAddressCtrl',
                    reload: true
                }
            }
        }).state('app.cartConfirmation', {
            url: "/cartConfirmation",
            data: {
                required: true
            },
            views: {
                'menuContent': {
                    templateUrl: "templates/app-cartConfirmationList.html",
                    controller: 'CartConfirmationCtrl'
                }
            }
        })
        .state('app.common-menu', {
            url: "/common-menu/:id/:selectedMenu/:kat_liste",
            views: {
                'menuContent': {
                    templateUrl: "templates/common-menu.html",
                    controller: 'MenuCommonCtrl'
                }
            }
        })

      .state('app.home', {
          url: "/home",
          views: {
              'menuContent': {
                  templateUrl: "templates/home.html",
                  controller: 'HomeCtrl'
              }
          }
      })
        .state('app.search-data', {
            url: '/issues/:query/:categoryId/:kat_liste/:title',
            views: {
                'menuContent': {
                    templateUrl: 'templates/searchData.html',
                    controller: 'SearchDataController'
                }
            }
        })


        .state('app.store-follow', {
            url: '/store-follow/:url',
            views: {
                'menuContent': {
                    templateUrl: 'templates/app-store-detail.html',
                    controller: 'StoreDetailCtrl'
                }
            }
        })
        .state('app.store-detail', {
            url: '/store-detail/:url/:ilan_resim/:logo/:id',
            views: {
                'menuContent': {
                    templateUrl: 'templates/app-store-detail.html',
                    controller: 'StoreDetailCtrl'
                }
            }
        })
        .state('app.product-detail', {
            url: '/product-detail/:url/:ilan_resim/:logo/:id',
            reload: true,
            views: {
                'menuContent': {
                    templateUrl: 'templates/app-product-detail.html',
                    controller: 'ProductDetailCtrl',
                    reload: true
                }
            }
        })

        .state('app.search-url', {
            url: '/search/:url',
            views: {
                'menuContent': {
                    templateUrl: 'templates/searchData.html',
                    controller: 'SearchDataController'
                }
            }
        })

      .state('app.single', {
          url: "/playlists/:playlistId",
          views: {
              'menuContent': {
                  templateUrl: "templates/playlist.html",
                  controller: 'PlaylistCtrl'
              }
          }
      }).state('app.Account', {
          url: "/Account",
          data: {
              required: true
          },
          views: {
              'menuContent': {
                  templateUrl: "templates/MyAccount.html",
                  controller: 'AccountController'
              }
          }
      }).state('app.Address', {
          url: "/Address",
          data: {
              required: true
          },
          views: {
              'menuContent': {
                  templateUrl: "templates/app-Address.html",
                  controller: 'AddressController'
              }
          }
      }).state('app.AdManagement', {
          url: "/AdManagement",
          data: {
              required: true
          },
          reload: true,
          cache:false,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-AdManagement.html",
                  controller: 'AdManagementController',
              }
          }
      }).state('app.Message', {
          url: "/Message",
          data: {
              required: true
          },
          reload: true,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-message.html",
                  controller: 'MessageController'
              }
          }
      }).state('app.MessageDetail', {
          url: "/MessageDetail/:AdId/:SenderId/:receiverId/:SenderName",
          data: {
              required: true
          },
          reload: true,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-messageDetail.html",
                  controller: 'MessageDetailController'
              }
          }
      }).state('app.ChangePassword', {
          url: "/ChangePassword",
          data: {
              required: true
          },
          reload: true,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-changePassword.html",
                  controller: 'ChangePasswordController'
              }
          }
      }).state('app.MyFavorites', {
          url: "/MyFavorites",
          data: {
              required: true
          },
          reload: true,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-MyFavorites.html",
                  controller: 'MyFavoritesController'
              }
          }
      }).state('app.OrderStatus', {
          url: "/OrderStatus",
          data: {
              required: true
          },
          reload: true,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-OrderStatus.html",
                  controller: 'OrderStatusController'
              }
          }
      }).state('app.SafeECommerce', {
          url: "/SafeECommerce",
          data: {
              required: true
          },
          reload: true,
          views: {
              'menuContent': {
                  templateUrl: "templates/app-SafeECommerce.html",
                  controller: 'SafeECommerceController'
              }
          }
      });

    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/home');
}).run(function ($rootScope, AuthService, $state, CartService, $translate, toaster, $ionicHistory) {
    $ionicHistory.nextViewOptions({
        historyRoot: true
    });

    $rootScope.isShowSearchButton = false;
    $rootScope.CartCountFunction = function () {
        var token = AuthService.GetAccessToken();
        if (token) {
            $rootScope.fullName = token.fullName;
            $rootScope.userId = token.userId;
            $rootScope.isLoggedin = true
            CartService.getCartCount().then(function (response) {
                //console.log(response)
                $rootScope.CartCount = 0;
                if (response.cartItemsCount) {
                    $rootScope.CartCount = response.cartItemsCount;
                }
            }, function (error) {
                $rootScope.CartCount = 0;
            })
        } else {
            $rootScope.isLoggedin = false;
            $rootScope.fullName = $translate.instant('member_Login');
        }
    }
    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        $rootScope.selectedProductId = '';
        $rootScope.ProductDetailHomeButton = false;
        if (toState.name === 'app.home') {
            $rootScope.isShownOnHomePage = true;
            $rootScope.isInSubMenu = false;
            $rootScope.isShownMapButton = false;
            $rootScope.isShowSearchButton = false;
            $rootScope.isShownListingButton = false;
        } else {
            $rootScope.isShownOnHomePage = false;
            $rootScope.isInSubMenu = true;
        }
        var token = AuthService.GetAccessToken();
        $rootScope.CartCountFunction();
        if (toState.data) {
            if (toState.data.required) {

                if (token == null) {
                    event.preventDefault();
                    $state.transitionTo('postAd', { redirectState: toState.name, params: JSON.stringify(toParams), previousState: fromState.name, fromParams: JSON.stringify(fromParams) });
                }
            }
        }
        if (toState.name == 'postAd') {
            var token = AuthService.GetAccessToken()
            if (token != null) {
                event.preventDefault();
                $state.transitionTo('post.postAdupload');
            }
        }
        if (toState.name == 'postAd' || toState.name == 'post.postAdupload') {

            $rootScope.ClosePostAd = true;
            $rootScope.MainMenuCategories = true;
            $rootScope.isMainMenuContainer = true;
            $rootScope.isSubMenuContainer = false;
        }
        if (toState.name == 'app.product-detail') {
            if (toParams.id == $rootScope.PostInsertedId) {
                $rootScope.ProductDetailHomeButton = true;
            }

            $rootScope.selectedProductId = toParams.id;

        }
        if (toState.name == 'app.search-data') {
            $rootScope.isShownMapButton = true;
            $rootScope.isShownMapsButton = true;
        }
        if (toState.name == 'app.common-menu') {
            $rootScope.isShownMapButton = false;
        }
        if (toState.name == 'post.postAdupload') {
            $rootScope.categoryHeader = $translate.instant('categories');
        }

    });
}).run(function ($ionicPlatform, $ionicPopup, $ionicHistory, $state, $timeout, $rootScope, toaster) {
    var backCount = 0;
    // Disable BACK button on home
    $ionicPlatform.registerBackButtonAction(function (event) {
        if ($state.current.name == "app.home") {
            backCount++;
            if (backCount == 1) {
                $rootScope.$apply(function () {
                    $("#toast-container").removeClass('toast-top-right');
                    toaster.clear();
                    toaster.warning({ title: "", body: "press again for exit" });
                });
            }
            if (backCount == 2) {
                backCount = 0;
                toaster.clear();
                ionic.Platform.exitApp();
            }
            $timeout(function () {
                backCount = 0;
                toaster.clear();
            }, 10000)
            // your check here
            //$ionicPopup.confirm({
            //    title: 'System warning',
            //    template: 'are you sure you want to exit?'
            //}).then(function (res) {
            //    if (res) {
            //        ionic.Platform.exitApp();
            //    }
            //})
        } else {
            $ionicHistory.goBack();
        }
    }, 100);
});
